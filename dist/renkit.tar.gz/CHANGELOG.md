## Renkit 1.4.8 SavePulse 与插件菜单排序 — 2026-08-13

- 新增 SavePulse 安装入口，固定使用作者公开 GitHub Release v0.1.0-alpha.1，并校验 SHA256、ZIP 安全路径与插件目录后原子安装；SteamOS 与 Bazzite 均可使用。
- DeckRecall 与 SavePulse 一起移到插件第二页靠前位置；第一页保留官方插件浏览和常用项目，第二页的启动器入口合并为独立子菜单，保持触控按钮尺寸。
- SavePulse 使用每位用户自己的坚果云或标准 WebDAV，不依赖作者公共账号；云端存档包使用独立恢复口令加密。

## Renkit 1.4.7 FSR4 清单与主题美化安装修复 — 2026-08-13

- 修复 1.4.6 发布包虽然包含 683 款 FSR4 官方兼容游戏清单，但安装器未复制 `data` 目录，导致已更新用户仍提示“清单缺失或条目数异常”的问题。
- 安装器新增 FSR4 清单与 CSS Loader 中文前端运行文件复制，并加入真实安装目录回归测试；更新到 1.4.7 后重新安装或检测到 FSR4 会正常生成桌面清单。

## Renkit 1.4.6 新机初始化、常用插件与 FSR4 清单 — 2026-08-12

- 新机初始化扩展为 18 项客户交付流程：默认安装 Epic、FreeDeck、常用软件、Decky、常用插件、修改器所需 GE-Proton 7-55／8-25／9-27／10-29、虚拟内存与 Steamcommunity 302；战网、Ubisoft Connect、黑盒工坊可在开始前选择。
- 新机初始化彻底移除 ToDesk 安装及相关说明；独立 ToDesk 工具保持原样，不影响已有用户单独使用。
- 常用插件组合新增 SteamGridDB、CSS Loader、Friendeck 与 Decky Music：SteamGridDB 仅显示为“游戏封面更换”；Friendeck、Decky Music 仅显示为“文件传输助手”“音乐播放器”，不改前端、署名或其他文件。
- CSS Loader v2.1.2 显示为“主题美化”并叠加完整中文前端，官方后端保持原包；四款插件全部使用固定版本、SHA256、国内镜像优先、上游回退与原子安装。
- FSR4 安装后生成的桌面兼容清单改用 OptiScaler 官方 Wiki 2026-08-07 快照：记录上游 685 个可工作条目，去重并按既有要求排除《怪物猎人：荒野》后列出 683 款，同时写明 Steam Deck RDNA2、Proton/VKD3D、Mesa、DX11/Vulkan 与反作弊限制。
- Renkit 更新脚本新增只检测模式，供新机初始化真实联网核对版本，不下载或覆盖现有安装。

## Renkit 1.4.5 DeckRecall v0.3.2 下载与错误显示修复 — 2026-08-12

- DeckRecall 固定回退更新到官方 v0.3.2 轻量包，并使用 Release 提供的 SHA256；旧 v0.2.8／v0.3.1 默认配置会在 Renkit 更新时安全迁移。
- 取消 DeckRecall 的过期 Gitee v0.2.8 镜像清单路由，65 KB 插件包直接使用官方 GitHub Release 与既有线路回退，不再先显示“镜像清单校验值不一致”。
- 安装前读取实际插件目录中的版本并进行三段语义版本比较；同版或更高版本跳过重复下载，v0.2.8 会正确更新到 v0.3.1。
- 修复 Decky RPC 嵌套异常被统一显示为“发生了意外错误”；检测更新和虚拟内存现在会显示具体的中英双语失败原因。
- DeckRecall v0.3.1 起已内置新版下载与浏览器处理，Renkit 不再对新版套用只适用于旧前端的兼容补丁。

## Renkit 1.4.4 Decky Gitee 自动镜像修复 — 2026-08-12

- 修复定时任务把 GitHub `main` 直接推送到已分叉的旧 Gitee 仓库，持续触发 `non-fast-forward` 失败邮件的问题。
- Decky 自动镜像改为克隆当前 `zhoukeer-toolbox-v2` 的 Gitee 历史，只同步 `decky-installer-cn` 目录并创建普通提交；不 force push、不覆盖 Gitee 历史。
- 新增工作流静态回归检查，防止镜像地址退回旧仓库或再次直接推送分叉历史；Decky 稳定版与测试版安装逻辑不变。
- 同步修正运行时显示版本，使其与正式发布版本保持一致；自动更新继续兼容历史 `1.3.10` 用户。

## Renkit 1.4.3 启动器横向胶囊图比例修复 — 2026-08-11

- 修复 Epic、战网、育碧、黑盒工坊把 600×900 竖版封面同时写入 Steam `grid_l / Wide Capsule` 横向槽位，导致横屏封面被放大裁切的问题。
- 四张横向胶囊图改为由现有 1920×620 横幅素材无 AI 裁切生成的 920×430 图片；600×900 竖图只写入竖版胶囊槽位，Logo、Hero、背景、桌面图标和启动器入库逻辑均未修改。
- 封面缓存标记升级为 v8，镜像素材升级到 1.1.3；旧用户更新后运行“修复启动器封面”即可强制刷新横图。
- 自动更新验证覆盖 `1.3.10 → 1.4.0` 与 `1.3.10 → 1.4.3`。

## Renkit 1.4.2 DeckRecall Steam 浏览器调用修正 — 2026-08-11

- 纠正 1.4.1 把 DeckRecall 改用系统默认浏览器的错误方向；桌面模式已验证可下载的是 Steam 浏览器，本版改为直接调用与 Renkit 现有兜底链路一致的 `SteamClient.Browser.OpenUrl`。
- 已经执行过 1.4.1 DeckRecall 修复的用户再次安装时，会识别并迁移错误的 `OpenInSystemBrowser` 代码，不需要手动删除插件；官方 v0.2.8 原始调用和 1.4.1 错误调用都只进行一次精确替换。
- `Navigation.NavigateToExternalWeb` 仅在 Steam Browser API 缺失时作为兼容回退，修复完成后自动重载 Decky。
- 自动更新验证覆盖 `1.3.10 → 1.4.0` 与 `1.3.10 → 1.4.2`；游戏启动器入库、Steam 条目、封面代码及素材未改动。

## Renkit 1.4.1 DeckRecall 下载浏览器修复 — 2026-08-11

- DeckRecall 的“打开风灵月影官网”不再固定使用 Steam 游戏模式内置浏览器；安装时会对已核验的唯一调用点做原子兼容修复，优先使用 Decky/Steam 提供的系统默认浏览器接口，避免下载 EXE 或压缩包时一直卡住。
- 系统浏览器接口不可用时才保留原内置浏览器作为兼容回退；重复安装会识别已经修复的前端文件，不会反复改写。
- DeckRecall 首次安装和已有完整安装仍会重载 Decky，解决插件文件已下载但右侧菜单不显示的问题。
- 自动更新回归测试继续覆盖 `1.3.10 → 1.4.0`，并新增 `1.3.10 → 1.4.1` 直接升级，未先启动 1.4.0 的用户也能获取当前修复版。
- 游戏启动器入库、Steam 条目、封面代码及素材未改动。

## Renkit 1.4.0 DeckRecall 显示修复与版本规则 — 2026-08-11

- 修复 DeckRecall 安装完成后安装状态被子 Shell 隔离，外层未重启 Decky Loader，导致插件文件已经下载但右侧插件菜单不显示的问题。
- 已经下载过 DeckRecall 的用户可以再次执行安装；Renkit 会确认插件目录完整并强制重载 Decky，无需先删除插件。若系统服务无法自动重载，会明确提示完全退出再重新进入游戏模式。
- 正式版本补丁位今后严格限制为 0～9，`x.y.9` 的下一版必须进位为 `x.(y+1).0`；保留已发布的 `1.3.10` 作为历史兼容桥，并加入 `1.3.10 → 1.4.0` 自动更新回归测试。
- 游戏启动器入库、Steam 条目、封面代码及素材未改动。

## Renkit 1.3.10 Steam 加速有效性检测与主机加速入口 — 2026-08-11

- Steamcommunity 302 不再把“systemd 进程仍在运行”直接当成加速成功；现在会继续检查官方 `S302.run` 就绪标记，或本地 DNS 53 与代理 80/443 监听，未真正就绪时明确引导打开一次官方配置界面完成证书和 DNS 初始化。
- 安装或更新 302 后会显式重启Renkit托管的后台服务，避免旧进程仍显示 active、实际继续占用已替换程序的问题；重置与状态页也执行相同有效性检查。
- Steam 加速菜单新增奇游、迅游、网易UU主机加速入口。三家目前均无 SteamOS 原生客户端，因此只打开各自官方主机加速安装/配置页面，并说明使用手机 App、路由插件或加速盒；不会下载 Windows 安装包或通过 Wine 伪装安装成功。
- 游戏启动器入库、Steam 条目和封面代码及素材未改动。

## Renkit 1.3.9 微信桌面图标修复 — 2026-08-11

- 修复微信官方 AppImage 安装完成后桌面快捷方式使用不存在的 `wechat` 主题图标，导致 KDE 桌面只显示空白或通用图标的问题。
- Renkit 内置已核验的微信官方默认图标，快捷方式改用随更新包存在的绝对路径；新安装、重复安装和“修复桌面图标”都会补齐，不需要重复下载微信。
- 图标随 GitHub Release 和 Gitee v2 的 Renkit 更新包分发，不新增单独图标镜像；游戏启动器入库和封面代码及素材未改动。

## Renkit 1.3.8 一键安装模拟器与官方图标 — 2026-08-11

- SteamOS、Bazzite 触控菜单和桌面 GUI 新增“一键安装 6 款”，依次安装 Yuzu、Cemu、DuckStation、PCSX2、RPCS3、ShadPS4；已完整安装的项目会跳过，单项失败会汇总并继续后续安装。
- 一键安装继续复用各模拟器原有的 Gitee 分块镜像优先、GitHub 回退、固定 SHA256、ELF 格式校验、桌面入口和 Steam 入库流程；不包含游戏、BIOS、固件或密钥。
- 六张 AI 生成的模拟器图标全部替换为各项目官方默认图标，并固定来源提交与文件 SHA256；PPSSPP、mGBA 继续使用 Flatpak 官方图标，Azahar 继续使用用户本地程序图标。
- 游戏启动器入库、Steam 条目和封面代码及素材未改动。

## Renkit 1.3.7 新密码单次中文输入 — 2026-08-11

- 确认当前用户没有系统密码后，只显示一次中文新密码输入；Renkit通过本地伪终端自动完成系统 `passwd` 的两次确认，不再显示英文 `New password / Retype new password`。
- 密码只经标准输入和伪终端传递，不进入命令参数、环境变量或日志；系统拒绝密码时不生成桌面记录。
- 启动器入库、Steam 条目和封面代码及素材未改动。

## Renkit 1.3.6 管理员密码状态识别 — 2026-08-11

- “我还没有管理员密码”会先只读检查当前用户密码状态；只有确认无密码时才进入新密码设置，已有密码不再误入 `Current password` 英文失败流程。
- 已有密码时引导使用“我已有管理员密码”，密码锁定或忘记旧密码时停止操作并提供现有重置教程；不绕过 SteamOS 强制重置系统密码。
- 启动器入库、Steam 条目和封面写入代码未改动。

## Renkit 1.3.5 启动器封面安全修复 — 2026-08-11

- 启动器封面改为先完整准备六类新素材，再原子替换 Steam grid 文件；下载、素材或写入任一步失败时保留原有封面，不再先删除旧图留下空白。
- Epic、战网、育碧、黑盒工坊的 v2 公网封面包已复核，24 张素材、尺寸、包大小和 SHA256 均与清单一致。

## Renkit 1.3.4 强制刷新启动器封面缓存 — 2026-08-10

- 封面缓存标记升级为 `.covers-ready-v7`，旧安装更新后会自动重新下载已恢复的 v2 封面镜像，不需要手动删除缓存。
- 更新后重新执行“修复启动器封面”或重装战网启动器，桌面图标和 Steam 库封面会恢复。

## Renkit 1.3.3 恢复启动器封面镜像 — 2026-08-10

- 恢复 v2 自动更新仓库中缺失的 `launcher-covers` 镜像（版本 1.1.2），战网、Epic、育碧、黑盒工坊的桌面图标与 Steam 库封面重新可下载；该目录此前已从主仓库和 v2 丢失，本次重新纳入发布包和 v2 快照，避免下次同步再次丢失。
- 已安装用户更新后重新执行“修复启动器封面”或重装战网启动器即可刷新封面与图标。

## Renkit 1.3.2 镜像仓库恢复与 seed 修复 — 2026-08-10

- 修复 Gitee 分块镜像仓库 mirror-2/3/5/6/7 在推送模拟器分块时意外丢失旧插件与 GE-Proton 内容的问题；旧提交中的原文件已完整恢复，模拟器分块同时保留，所有 `latest.txt` 与分块已公网回读。
- `scripts/seed_gitee_local_asset.sh` 在部分克隆后先 `read-tree HEAD` 再添加新 id，后续镜像推送会保留仓库已有分块，不再覆盖其他镜像内容。
- Ally Center 等插件的 Gitee 镜像恢复可用；下载逻辑未改动，GitHub 回退行为保持不变。

## Renkit 1.3.1 模拟器 Gitee 分块镜像 — 2026-08-10

- 修复 ShadPS4（PS4 模拟器）无法从 GitHub Release 下载的问题；Yuzu、Cemu、DuckStation、PCSX2、RPCS3、ShadPS4 六款 AppImage 模拟器全部改为 Gitee 8MiB 分块镜像优先，镜像仓库按模拟器拆分到 mirror-2～mirror-7，SHA256、大小和 ELF 格式校验通过后才回退 GitHub Release。
- 模拟器安装仍只安装模拟器本体，不包含游戏、BIOS、固件或密钥；镜像文件保持上游未修改的固定 AppImage。
- License 清单同步更新六款模拟器的镜像授权说明；DuckStation 仅分发自有 Release 中未修改的固定 AppImage，保留 CC BY-NC-ND 署名与许可要求。

## Renkit 1.3.0 Bazzite 汉化插件与安装结果校验 — 2026-08-10

- Bazzite 的 Decky 菜单新增完整功能插件分页：除小黄鸭、FSR4 与 CheatDeck 外，还可安装 DeckRecall、Freedeck、NewFreedeck、ToMoon、Unifideck，以及现有掌机控制插件和 OneXPlayer Apex Tools；SteamOS 原菜单保持不变。
- DeckRecall 作者已明确授权 Renkit 建立国内镜像；DeckRecall 与 OneXPlayer Apex Tools 均使用 Gitee 镜像优先、固定版本与 SHA256 校验，失败才回退作者 GitHub Release。
- CheatDeck 固定基线更新到 v2.0.0，DeckRecall 固定回退版本更新到 v0.2.8；自动解析最新正式版的逻辑保持不变。
- 修复 Bazzite 菜单安装“掌机功耗控制”汉化版时被旧 SteamOS-only 版本检测误拦截的问题；汉化前端继续复用上游原生后端。
- Bazzite 缺少 Decky Loader 时只调用官方 `ujust setup-decky`；不会执行 SteamOS 的 Decky 服务替换、pacman 或只读系统操作。
- 官方 Decky 插件不再把“请求已排队”显示成安装成功：提交后轮询 Decky 已安装列表并核对目标版本，缺失、商店无版本或超时均明确返回失败，重新执行会跳过已经完成的插件。

## Renkit 1.2.9 Bazzite 旧 SteamOS 引导自动清理 — 2026-08-10

- Bazzite 的“安装/修复 Clover 双系统引导”会识别旧 `steamcl.efi`，先归档到 EFI 内的 Renkit 备份目录，再删除对应的旧 SteamOS NVRAM 项；不增加独立按钮，也不删除任何系统分区。
- Bazzite Clover 配置自动移除失效的 SteamOS 菜单项，只保留 Bazzite 与 Windows；SteamOS 版 Clover 流程保持原样。
- 清理只匹配指向 `steamcl.efi` 的启动项，最多处理 8 项；失败时尝试恢复启动文件与入口，重复安装会继承原备份记录，恢复 Clover 时也会还原被归档的 SteamOS 引导。
- 新增临时 EFI/NVRAM 模拟测试，验证 Windows、Bazzite、Clover 均不会被误删，并覆盖重复执行和恢复流程。

## Renkit 1.2.8 GPD WIN 3 Clover 横屏与默认启动修复 — 2026-08-10

- GPD WIN 3（G1618-03）安装 Clover 时单独请求 `1280x720` 横屏 GOP 模式，其他掌机继续使用自动分辨率。
- Bazzite 的 Clover 开机修复服务改为等待本地文件系统，并通过系统 Bash 启动脚本，规避 SELinux 对 systemd 配置目录脚本直接执行的限制。
- 保留 Windows 官方启动文件与 NVRAM 启动项；升级时自动修复旧版移走的 `bootmgfw.efi`，恢复桌面“切换至 Windows”。
- Clover 主题背景替换为当前 1536×1024 深色 Renkit 图；升级仍整体替换活动主题目录，不会残留旧背景。

## Renkit 1.2.7 Clover FAT32 文件名兼容 — 2026-08-10

- 修复 Linux 临时目录同时包含 `cloverx64.efi` 与 `CLOVERX64.efi`，复制到不区分大小写的 FAT32 EFI 时提示“文件已存在”的问题。
- Clover 启动文件改为通过临时名称安全改名，EFI 中只写入一个标准大写文件名。
- 新增回归测试，禁止准备阶段再次复制仅大小写不同的 Clover EFI 文件。

## Renkit 1.2.6 Clover FAT32 复制兼容 — 2026-08-10

- 修复向 FAT32 EFI 分区复制 Clover 时，`cp -a` 尝试保留 Linux 所有权和权限并连续报“不允许的操作”的问题。
- EFI 写入改为普通递归复制；仍保留临时目录、原 Clover 备份、失败清理和原启动文件不修改的保护流程。
- 模拟测试明确禁止 Clover 安装路径再次使用 `cp -a`。

## Renkit 1.2.5 Clover Linux 解压警告兼容 — 2026-08-10

- 修复 Linux `tar` 输出 macOS 扩展属性警告时，警告文字被误当成 Clover 临时目录并触发“文件名过长”的问题。
- Clover 临时目录改为使用Renkit已知的固定工作路径；解压真正失败时仍显示错误并保证 EFI 未修改。
- 模拟测试加入 `LIBARCHIVE.xattr` 警告，确认不会再污染安装路径。

## Renkit 1.2.4 Bazzite Clover 管理员验证 — 2026-08-10

- 修复 Bazzite 独立菜单未先准备管理员密码记录，导致 1.2.3 无法完成 root-only EFI 复核的问题。
- 安装、状态和恢复 Clover 前统一验证管理员权限；Bazzite 尚未录入或记录失效时，会明确要求输入一次当前账户密码，验证失败不修改 EFI。
- 新增完全模拟的 Bazzite 管理员密码录入测试；SteamOS 原有首次使用流程保持不变。

## Renkit 1.2.3 Bazzite EFI 权限兼容 — 2026-08-10

- 修复 Bazzite 将 `/boot/efi` 设为仅 root 可读取时，Clover 错误提示“挂载位置不含 EFI 目录”的问题；只读探测会通过Renkit现有管理员权限通道复核。
- Clover 安装、状态、Windows 启动文件识别和恢复流程统一兼容受保护的 EFI 目录；磁盘、分区、BootOrder、确认和回滚规则保持不变。
- 新增 root-only EFI 模拟测试；macOS 测试只调用模拟命令，不访问真实 EFI 或磁盘。

## Renkit 1.2.2 Clover 自动分辨率 — 2026-08-09

- SteamOS 与 Bazzite 安装 Clover 时不再把 Steam Deck、ROG Ally、Legion Go 等机型的固定分辨率写入 EFI，改由 Clover 根据当前掌机固件提供的 UEFI GOP 显示模式自动选择。
- 机型识别、专用 EFI 驱动、默认系统、主题、Windows 备份、BootOrder 和恢复流程保持不变；只在写入前生成的临时配置中安全移除固定分辨率字段。
- 新增 SteamOS 与 Bazzite 模拟断言，确保最终 Clover 配置不含 `ScreenResolution`；全部相关测试只操作临时目录和模拟命令。

## Renkit 1.2.1 Bazzite Clover 双系统引导 — 2026-08-09

- Bazzite 独立高级菜单新增 Clover 安装、状态与恢复入口；仍不接入 SteamOS 的 pacman、只读系统、ToDesk、内存调优或其他通用 EFI 功能。
- Clover 支持 Bazzite 的 Fedora shim 启动器，并为未知 Bazzite 掌机/迷你主机提供不加载机型专用驱动的通用配置；默认启动项可选择 Bazzite 或 Windows。
- EFI 分区、磁盘与分区号改为动态识别，不再固定 `/dev/nvme0n1p1`；开机修复只把 Clover 放到首位，保留 Windows、PXE 和其他现有 BootOrder 项。
- 重写 Clover 开机修复服务，移除 `sudo`、`bash -c` 和 EFI 变量删除操作，状态日志迁移到 root 管理的 `/run/renkit`；恢复 Clover 时同步停用并移除修复服务，SteamOS 原菜单与设备配置保持不变。
- 新增完全模拟的 Bazzite Iris Xe 通用设备、EFI 第 7 分区、Windows 文件备份及 BootOrder 保留测试；macOS 测试不会访问真实 EFI、磁盘或 systemd。

## Renkit 1.2.0 Bazzite 用户空间功能扩展 — 2026-08-09

- Bazzite 常用软件由 16 项扩展到 31 项；新增百度网盘、WiliWili、Fcitx5、Xbox 云游戏、音乐、下载、截图、办公、笔记和 Parsec 等官方 Flathub 应用，继续默认走用户级官方 Flathub。
- 新增 Bazzite 分类卸载菜单，可移除常用软件、四款游戏启动器、九款模拟器、当前 GE-Proton 和 Renkit；系统级 Flatpak 明确交给 Bazzite 自带工具，Renkit 不调用 sudo 卸载。
- GE-Proton 增加最新版与修改器常用四版本选择；Yuzu 增加本人合法备份密钥的导入与只读状态页。
- Decky 官方插件支持整组推荐或逐个浏览安装，只向本机 Decky 官方商店提交请求，不接入 SteamOS 专用插件商城模块。
- 检查与维护新增软件状态、桌面图标修复、中文兼容攻略、掌机快捷键、外接设备只读检查和操作记录导出；Bazzite 列表继续排除 ToDesk 与 AnyDesk。

## Renkit 1.1.9 Bazzite Flatpak 下载源隔离 — 2026-08-09

- Bazzite 软件安装默认使用带 GPG 签名验证的官方 Flathub，不再自动配置国内镜像；SteamOS 原有国内源与安装流程保持不变。
- Bazzite 使用准备新增独立的 Flatpak 下载源菜单：明确显示关闭 GPG 验证的风险、远程名称和完整 URL，用户主动确认后才启用上海交大与中科大镜像。
- Bazzite 国内源的启用与恢复只修改用户级 Flatpak 远程，不调用 sudo、不修改系统更新源；恢复官方源时重新启用 GPG 验证。
- 新增 Bazzite 官方安装、手动国内源、恢复官方源、旧系统级远程隔离和普通 Fedora 拒绝执行的模拟测试。

## Renkit 1.1.8 SteamOS / Bazzite 独立双平台版 — 2026-08-09

- 同一条安装命令自动分流：SteamOS 保持原有 `main.sh` 和全部现有功能，其他 Linux 使用独立的 `main-bazzite.sh`，两套菜单互不调用对方的系统功能。
- Bazzite 首期开放常用 Flatpak/AppImage、GE-Proton、Epic/战网/育碧/黑盒工坊、Steam 入库与封面、九款模拟器、网络诊断和安全清理。
- Bazzite 的 Decky Loader 只调用官方 `ujust setup-decky`，不执行 pacman、steamos-readonly、SteamOS 通道选择或服务替换；系统调优、ToDesk、EFI/Clover 等入口暂不开放。
- 新增 SteamOS/Bazzite 平台解析、启动分流、Bazzite Decky 模拟与发布防漏包测试；`/etc/os-release` 改为白名单读取，不作为 Shell 执行。

## Renkit 1.1.7 插件商城系统通道识别修复 — 2026-08-09

- 修复“根据系统版本安装插件商城”只读取 `/etc/os-release`，导致 SteamOS 测试或预览通道也总被识别为 stable 的问题。
- 新版优先读取 `atomupd-manager tracked-branch`，兼容旧系统的 `steamos-select-branch -c`，最后才使用系统版本文件兜底；稳定分支安装稳定版，beta/main/preview/staging 分支安装测试版。
- 只调整通道识别，不改变 Decky 下载、校验、服务切换、插件保留和国内源回退逻辑。

## Renkit 1.1.6 掌机控制插件中文套装 — 2026-08-09

- “掌机控制插件”扩充为七项：新增通用掌机 RGB、Legion Go 控制中心、GPD 控制中心、Legion Go 震动控制和 Legion Go 2 风扇控制，并统一使用中文插件名。
- HueSync 沿用上游完整简体中文；其余四款完成中文前端并加入 Ren-Amamiya-pixie / zliu9732-hub（闲鱼RenAmamiya）署名，保留原作者信息和官方硬件控制后端。
- 五款插件均使用 Gitee mirror-3 静默分块下载、固定 SHA256 与 GitHub Release 回退；新增 tar.gz 安全解压支持、机型限制和风扇控制风险提示。
- 安装器白名单与发布包校验显式包含全部五套前端组件，并新增官方后端保留、重复安装幂等、ZIP/tar.gz 分支及防漏打包测试。

## Renkit 1.1.5 Ally 控制中心组件随更新安装 — 2026-08-09

- 修复 1.1.4 更新成功后，正式安装目录未复制 Ally 控制中心中文组件、安装插件提示“中文组件不完整”的问题。
- 主安装器只新增 Ally 中文清单、版本、许可证和已构建前端的复制白名单；发布打包增加必需文件检查，其他更新与插件安装逻辑不变。

## Renkit 1.1.4 Ally 控制中心中文名称 — 2026-08-09

- Decky 插件显示名与工具箱菜单统一改为“Ally 控制中心”，保留官方安装目录以兼容旧版升级。
- 中文插件清单名与前端内部身份同步更新，继续校验中文前端 SHA256，避免名称不一致导致插件打开空白；原版硬件控制后端不变。

## Renkit 1.1.3 Ally Center 中文版 — 2026-08-09

- 新增“掌机控制插件”子菜单，保留原有“掌机功耗控制”，并加入适用于 ROG Ally / Ally X 的 Ally Center v1.2.0。
- Ally Center 的 RGB、TDP、风扇、CPU、电池、下载模式和设备信息界面完成中文化，并加入与小黄鸭一致的汉化署名；硬件控制后端保持作者原版。
- 下载保持 Gitee mirror-3 国内源优先、固定 SHA256 校验和 GitHub Release 自动回退；分块细节静默，已安装英文版或旧版再次执行会替换为已校验的中文版。

## Renkit 1.1.2 黑盒工坊兼容手动战网与横向 Logo 再缩小 — 2026-08-09

- 黑盒工坊预装包改为先在独立临时目录中解压并检查，再写入现有战网环境；客户手动安装的战网即使包含正常链接也不会再被误判，压缩包自身的异常链接仍会被拦截。
- Epic、战网、育碧和黑盒工坊的 Steam 横向 Logo 从约 55% 再缩小到约 32%；桌面图标、横幅背景、竖版封面和启动器安装逻辑保持不变，封面缓存标记升级为 v6。
- 战网安装完成后提示用户从右侧手柄图标把右触控板行为改为“用作鼠标”。

## Renkit 1.1.1 启动器横向 Logo 比例修复 — 2026-08-08

- Epic、战网、育碧和黑盒工坊新增独立的 Steam 横向 Logo 素材：保留官方桌面图标不变，仅通过透明留白把详情页 Logo 的显示尺寸统一缩小到原来的约 55%。
- 封面缓存标记升级为 v5；旧用户重新安装启动器或运行“修复启动器封面”即可刷新，不改变启动器安装、Steam 入库或其他封面逻辑。

## Renkit 1.1.0 Freedeck 双版本与功耗控制署名 — 2026-08-08

- Freedeck 改为双版本子菜单：保留 0.6 稳定版，并新增独立的 NewFreedeck v0.1；新版使用 mirror-3 分块镜像、固定 SHA256，并明确提示上游部分功能尚未完成。
- “掌机功耗控制”主界面新增与小黄鸭一致的两行可见署名：汉化与原作者说明，以及金色居中的汉化账号。
- 插件商城仍保持 Gitee 分块镜像优先与原有回退顺序，仅静默分块下载过程提示。

## Renkit 1.0.9 Freedeck 探测提示修复 — 2026-08-08

- Freedeck 固定安全版本可以正常安装时，静默上游最新 Release 资产不兼容的探测提示；真实安装错误仍会正常显示。

## Renkit 1.0.8 启动器旧封面缓存修复 — 2026-08-08

- 修复旧封面缓存绕过版本标记、导致重新安装仍把旧图写回 Steam 的问题；缓存升级为 v4，更新后会强制重新下载并覆盖新版素材。
- 修复 Epic 等启动器从 Steam 删除并手动重新添加后，因名称或路径变化导致“shortcut not found”；封面修复现在会安全识别 Steam 当前保存的唯一条目。

## Renkit 1.0.7 启动器图标与掌机功耗控制修复 — 2026-08-08

- Epic、战网、育碧改用各自官方桌面图标，黑盒工坊改用黑白金属风桌面图标和整套 Steam 封面；封面缓存升级为 v3，旧安装重新点安装或运行“修复启动器封面”即可替换旧素材。
- 修正“掌机功耗控制”前端与 Decky 清单身份名不一致导致的空白界面，并在版本检测中校验汉化前端 SHA，确保同为 v1.0.5 的故障版本也会自动替换。

## Renkit 1.0.6 启动器封面改走 v2 镜像 — 2026-08-08

- 启动器封面素材改为优先从 Gitee v2 镜像拉取并缓存，不再优先使用本地旧素材；镜像缓存版本升级为 v2，更新后会自动重新下载新封面。
- 新版 Epic、战网、育碧、黑盒工坊封面已同步到 `zhoukeer-toolbox-v2` 的 `launcher-covers` 镜像，更新后重装或运行“修复启动器封面”即可生效。

## Renkit 1.0.5 掌机功耗控制汉化版与版本检测 — 2026-08-08

- SimpleDeckyTDP 汉化插件更名为“掌机功耗控制”，菜单、界面和状态检测同步使用短名称。
- 插件菜单改为自动检测版本：检测到原版、旧版或非汉化版时自动替换为最新汉化版；常用功能插件状态新增掌机功耗控制检测行。

## Renkit 1.0.4 SimpleDeckyTDP 系统信息默认展开 — 2026-08-08

- SimpleDeckyTDP 汉化版底部“系统信息”区域改为默认展开，并清除旧折叠缓存，避免打开插件后底部空白。

## Renkit 1.0.3 SimpleDeckyTDP 完整汉化 — 2026-08-08

- SimpleDeckyTDP 插件完整汉化：修复 Steam 中文语言码未命中导致瓦数、滑块等界面回退英文的问题，补齐 GPU 模式、EPP/调频选项、TDP 范围等界面中文。
- 汉化组件内置并带 Ren-Amamiya-pixie / zliu9732-hub（闲鱼RenAmamiya）署名，安装复用 Gitee 镜像优先、GitHub Release 回退并校验 SHA256。

## Renkit 1.0.2 修复虚拟内存撤销与启动器封面 — 2026-08-08

- 新增“掌机适配 → 飞行家 F1 屏幕方向修复”，通过用户级 gamescope wrapper 与 systemd override 修复 ONEXPLAYER F1 游戏模式画面倒置，不使用 sudo、不修改只读系统。
- 虚拟内存撤销时自动处理独立 swap 的只读保护，避免 `rm` 因“不允许的操作”中断。
- 启动器封面素材解压忽略 macOS Apple 扩展属性警告，SteamOS 不再显示 `LIBARCHIVE.xattr.com.apple.provenance`。
- 更新 Epic、战网、育碧、黑盒工坊的封面、背景和桌面徽标素材。

## Renkit 1.0.1 清理旧版桌面入口并默认窗口启动 — 2026-08-07

- 安装或升级时自动移除旧版“周克儿工具箱”桌面与应用菜单入口，避免桌面出现重复图标。
- 启动器默认不再全屏，改为按屏幕分辨率适配的普通窗口，方便最小化和关闭。
- 需要全屏时仍可通过 `ZHOUKEER_WINDOW_FULLSCREEN=1` 恢复。

## Renkit 1.0 正式更名与旧版本清理 — 2026-08-07

- 产品正式更名为 Renkit，版本定为 1.0；界面、桌面快捷方式、诊断包和网站同步使用新名称。
- 发布包改为 `renkit.tar.gz` 与 `renkit-1.0.tar.gz`，移除 `dist` 中所有旧版发布包。
- 保留 V1.6.4 本地备份，安装、更新和下载链路继续使用原有仓库地址。
- 旧版安装检测到 Renkit 1.0 后会自动升级；仅剩域名源可用时也允许完成迁移。
