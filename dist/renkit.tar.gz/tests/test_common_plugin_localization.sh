#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_ROOT="$(mktemp -d)"
trap 'rm -rf -- "$TMP_ROOT"' EXIT
PLUGIN_ROOT="$TMP_ROOT/plugins"
mkdir -p "$PLUGIN_ROOT"

DECKY_PLUGIN_DIR="$PLUGIN_ROOT" PROJECT_ROOT="$PROJECT_ROOT" bash -c '
    set -euo pipefail
    source "$PROJECT_ROOT/modules/plugin_store.sh"

    make_plugin() {
        local directory="$1" name="$2" version="$3"
        mkdir -p "$DECKY_PLUGIN_DIR/$directory/dist"
        printf '\''{\n  "name": "%s",\n  "author": "upstream"\n}\n'\'' "$name" > \
            "$DECKY_PLUGIN_DIR/$directory/plugin.json"
        printf '\''{"version": "%s", "sentinel": "unchanged"}\n'\'' "$version" > \
            "$DECKY_PLUGIN_DIR/$directory/package.json"
        printf '\''official frontend\n'\'' > "$DECKY_PLUGIN_DIR/$directory/dist/index.js"
        printf '\''official backend\n'\'' > "$DECKY_PLUGIN_DIR/$directory/main.py"
    }

    install_decky_zip() {
        local display_name="$1" url="$2" sha256="$3" expected_dir="$4"
        printf '\''{\n  "name": "%s",\n  "author": "upstream"\n}\n'\'' "$DECKY_PLUGIN_TEST_OFFICIAL" > \
            "$DECKY_PLUGIN_DIR/$expected_dir/plugin.json"
        : > "$DECKY_PLUGIN_TEST_MARKER"
    }

    # 旧版把 plugin.json 名称改成中文，导致 Decky 前端身份不匹配；新逻辑检测到
    # 旧问题安装时必须重新安装官方包，原子替换整个目录，并保持官方后端/版本/前端不变。
    for entry in \
        "decky-steamgriddb|SteamGridDB|1.7.1|游戏封面更换" \
        "Friendeck-plugin|Friendeck|0.7.5|文件传输助手" \
        "Decky Music|Decky Music|1.0.2|音乐播放器"; do
        directory="${entry%%|*}"
        rest="${entry#*|}"
        official="${rest%%|*}"
        rest="${rest#*|}"
        version="${rest%%|*}"
        localized="${rest##*|}"
        make_plugin "$directory" "$localized" "$version"
        backend_hash="$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$directory/main.py")"
        package_hash="$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$directory/package.json")"
        frontend_hash="$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$directory/dist/index.js")"
        marker="$DECKY_PLUGIN_DIR/$directory/.renkit-reinstalled"
        rm -f -- "$marker"
        DECKY_PLUGIN_TEST_OFFICIAL="$official" DECKY_PLUGIN_TEST_MARKER="$marker" \
            ensure_official_plugin_current \
            "测试菜单名" "$directory" "$version" "$localized" "$official" \
            "https://test.invalid/pkg.zip" \
            "0000000000000000000000000000000000000000000000000000000000000000" >/dev/null
        [ -f "$marker" ] || {
            echo "FAIL: 旧版中文名插件没有触发重新安装：$directory" >&2
            exit 1
        }
        grep -Fq "\"name\": \"$official\"" "$DECKY_PLUGIN_DIR/$directory/plugin.json"
        [ "$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$directory/main.py")" = "$backend_hash" ]
        [ "$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$directory/package.json")" = "$package_hash" ]
        [ "$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$directory/dist/index.js")" = "$frontend_hash" ]
    done

    # 官方名称且版本正确时直接跳过，不重复下载。
    for entry in \
        "decky-steamgriddb|SteamGridDB|1.7.1" \
        "Friendeck-plugin|Friendeck|0.7.5" \
        "Decky Music|Decky Music|1.0.2"; do
        directory="${entry%%|*}"
        rest="${entry#*|}"
        official="${rest%%|*}"
        version="${rest##*|}"
        make_plugin "$directory" "$official" "$version"
        marker="$DECKY_PLUGIN_DIR/$directory/.renkit-reinstalled"
        rm -f -- "$marker"
        DECKY_PLUGIN_TEST_OFFICIAL="$official" DECKY_PLUGIN_TEST_MARKER="$marker" \
            ensure_official_plugin_current \
            "测试菜单名" "$directory" "$version" "中文旧名" "$official" \
            "https://test.invalid/pkg.zip" \
            "0000000000000000000000000000000000000000000000000000000000000000" >/dev/null
        [ ! -e "$marker" ] || {
            echo "FAIL: 官方名称正确时不应重新安装：$directory" >&2
            exit 1
        }
    done

    make_plugin "$CSSLOADER_OFFICIAL_DIRECTORY" "CSS Loader" "$CSSLOADER_OFFICIAL_VERSION"
    css_backend_hash="$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$CSSLOADER_OFFICIAL_DIRECTORY/main.py")"
    css_package_hash="$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$CSSLOADER_OFFICIAL_DIRECTORY/package.json")"
    ensure_cssloader_chinese_current
    grep -Fq '\''"name": "主题美化"'\'' "$DECKY_PLUGIN_DIR/$CSSLOADER_OFFICIAL_DIRECTORY/plugin.json"
    [ "$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$CSSLOADER_OFFICIAL_DIRECTORY/dist/index.js")" = \
        "$CSSLOADER_ZH_INDEX_SHA256" ]
    [ "$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$CSSLOADER_OFFICIAL_DIRECTORY/main.py")" = \
        "$css_backend_hash" ]
    [ "$(calculate_decky_sha256 "$DECKY_PLUGIN_DIR/$CSSLOADER_OFFICIAL_DIRECTORY/package.json")" = \
        "$css_package_hash" ]
'

grep -Fq 'DECKY_FRIENDECK_SHA256="65465ff115e105912adf72b5461e17b697ac07100ce7061de2e962851e41c653"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_DECKYMUSIC_SHA256="37b79e28e54691f9c7e301aaa83823e20f6cffc8948d312b7398dcc87e466e11"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'CSSLOADER_ZH_INDEX_SHA256="38ec628efcc1238247e0cf771bde98b26be49349dca9c2d7de4270ad242a2567"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"

echo "PASS: 四款常用插件名称、CSS Loader 中文前端和官方后端不变校验通过"
