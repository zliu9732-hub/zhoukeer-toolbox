#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_ROOT="$(mktemp -d)"
trap 'rm -rf -- "$TMP_ROOT"' EXIT

grep -Fq 'https://www.mhhf.com/Deck/decky/v.3.2.8/PluginLoader' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '4b9a04a1ac4ed0c028dcbbc38cd03383eb438d69744d613775c93f81809afde2' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'https://www.mhhf.com/Deck/decky/plugin_loader-release.service' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '64d6aa626aa45e1659e3137aa3afd72edd840094199d62bb6ff2e73c5ce738b1' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'releases/download/v3.2.8-pre1/PluginLoader' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '9df160a81df3fc49c96e5665a1d1b3ba5c79de5bf271adc266d6bfedfda399d8' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'v3.2.8-pre1/dist/plugin_loader-prerelease.service' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'store-test) show_plugin_download_speed_tip; install_plugin_store prerelease' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'store-auto) show_plugin_download_speed_tip; install_plugin_store_auto' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'download_decky_gitee_loader' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 测试版未接入 Gitee 国内镜像加载流程" >&2
    exit 1
}
grep -Fq 'download_decky_gitee_service' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 测试版未接入 Gitee 国内镜像服务模板" >&2
    exit 1
}
grep -Fq 'load_decky_gitee_mirror_meta' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 测试版未读取 Gitee 镜像版本清单" >&2
    exit 1
}
grep -Fq 'DECKY_GITEE_MIRROR_META' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 测试版缺少 Gitee 镜像清单地址" >&2
    exit 1
}
grep -Fq 'download_decky_prerelease_component' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 测试版 Gitee 失败后缺少官方 Release 回退" >&2
    exit 1
}
grep -Fq 'download_decky_gitee_part' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky Gitee 分块没有使用直接下载与实时进度" >&2
    exit 1
}
gitee_loader_function="$(sed -n '/^download_decky_gitee_loader()/,/^}/p' \
    "$PROJECT_ROOT/modules/plugin_store.sh")"
if printf '%s\n' "$gitee_loader_function" | \
    grep -Eq 'resolve_decky_(pre)?release_latest|GITHUB_QUIET'; then
    echo "FAIL: Decky Gitee 分块下载前仍会访问 GitHub 或静默进度" >&2
    exit 1
fi
GITEE_PART_CALLS="$TMP_ROOT/gitee-part-calls"
GITEE_LOADER_OUTPUT="$TMP_ROOT/gitee-loader-output"
GITEE_VISIBLE_OUTPUT="$TMP_ROOT/gitee-visible-output"
PROJECT_ROOT="$PROJECT_ROOT" GITEE_PART_CALLS="$GITEE_PART_CALLS" \
    GITEE_LOADER_OUTPUT="$GITEE_LOADER_OUTPUT" ZHOUKEER_TEST_MODE=1 bash -c '
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    DECKY_GITEE_PRERELEASE_VERSION="v-test"
    DECKY_GITEE_PRERELEASE_PARTS="2"
    DECKY_GITEE_PRERELEASE_SHA256="cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
    DECKY_GITEE_PRERELEASE_PART_SHA256="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
    resolve_decky_prerelease_latest() {
        echo "FAIL: Gitee 下载前访问了 GitHub" >&2
        exit 99
    }
    download_decky_gitee_part() {
        printf "%s|%s|%s\n" "$1" "$5" "$6" >> "$GITEE_PART_CALLS"
        printf "%s\n" "$1" > "$4"
    }
    calculate_decky_sha256() {
        printf "%s\n" "$DECKY_GITEE_PRERELEASE_SHA256"
    }
    download_decky_gitee_loader prerelease "$GITEE_LOADER_OUTPUT"
' > "$GITEE_VISIBLE_OUTPUT"
grep -Fxq 'Decky PluginLoader|0|2' "$GITEE_PART_CALLS" || {
    echo "FAIL: Decky 国内下载没有从总进度 0% 开始" >&2
    exit 1
}
grep -Fxq 'Decky PluginLoader|1|2' "$GITEE_PART_CALLS" || {
    echo "FAIL: Decky 国内下载没有连续换算总进度" >&2
    exit 1
}
grep -Fq '正在下载 Decky PluginLoader...' "$GITEE_VISIBLE_OUTPUT" || {
    echo "FAIL: Decky 国内下载缺少统一进度提示" >&2
    exit 1
}
if grep -Eq '分块|[0-9]+/[0-9]+' "$GITEE_VISIBLE_OUTPUT"; then
    echo "FAIL: Decky 下载界面暴露了内部传输细节" >&2
    exit 1
fi
[ -s "$GITEE_LOADER_OUTPUT" ] || {
    echo "FAIL: Decky Gitee 模拟分块未完成重组" >&2
    exit 1
}
grep -Fq 'ensure_steam302_for_download' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 测试版下载缺少 Steam302 加速重试" >&2
    exit 1
}
grep -Fq '强烈建议进入 游戏与插件，安装修改器所需兼容层' \
    "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: CheatDeck 下载缺少修改器兼容层提示" >&2
    exit 1
}
grep -Fq 'systemctl --user disable --now "$DECKY_SERVICE_NAME"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'download_decky_component' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '下载较慢，正在启用加速，请耐心等待' "$PROJECT_ROOT/modules/steam_accelerator.sh"
grep -Fq 'render_decky_service' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'rollback_decky_install' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'systemctl stop "$DECKY_SERVICE_NAME"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'toolbox_sudo systemctl restart "$DECKY_SERVICE_NAME"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
decky_component_download="$(sed -n '/^download_decky_component()/,/^}/p' \
    "$PROJECT_ROOT/modules/plugin_store.sh")"
if printf '%s\n' "$decky_component_download" | grep -Fq -- '--retry-all-errors'; then
    echo "FAIL: Decky 组件下载仍会重复重试确定的 404/403 错误" >&2
    exit 1
fi
grep -Fq 'run_curl_with_progress "$name"' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 组件下载未使用同步实时速度进度条" >&2
    exit 1
}
printf '%s\n' "$decky_component_download" | grep -Fq -- '--speed-limit 65536' || {
    echo "FAIL: Decky 组件下载缺少低速中断保护" >&2
    exit 1
}
printf '%s\n' "$decky_component_download" | grep -Fq -- '--speed-time 60' || {
    echo "FAIL: Decky 组件下载缺少低速中断时长" >&2
    exit 1
}
printf '%s\n' "$decky_component_download" | grep -Fq -- '--progress-meter' || {
    echo "FAIL: Decky 组件下载缺少实时速度显示" >&2
    exit 1
}
grep -Fq '下载失败，切换备用源。' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Decky 插件下载缺少原有备用源提示" >&2
    exit 1
}
grep -Fq 'modules/steam_accelerator.sh" ensure' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: 插件下载失败后没有自动启用加速重试" >&2
    exit 1
}
if grep -Fq 'https://www.mhhf.com/Deck/install.sh' "$PROJECT_ROOT/modules/plugin_store.sh" || \
    grep -Fq 'toolbox_sudo bash "$installer"' "$PROJECT_ROOT/modules/plugin_store.sh"; then
    echo "FAIL: 不应继续下载或执行Decky外层安装脚本"
    exit 1
fi
grep -Fq 'DECKY_LSFG_SHA256="322f6eec21a489ef9f12938ea2ec4e43c234093876f95b7245fbd260f882ce9c"' \
    "$PROJECT_ROOT/config/settings.example.conf"
grep -Fq 'DECKY_FSR4_SHA256="3300b617e3d979b483d03f995c75c829d6d54beaa4ac8dfae300c2560e4fc60f"' \
    "$PROJECT_ROOT/config/settings.example.conf"
grep -Fq 'DECKY_CHEATDECK_SHA256="32e2931f9ca8083c1605f04b4ed089b0bf210f79db236a7fd34f02c519e902d9"' \
    "$PROJECT_ROOT/config/settings.example.conf"
grep -Fq 'DECKY_TOMOON_SHA256="5500e6ed2d110b0e077b9eba3f1908eb50593483e51158b9351978d9a03191a6"' \
    "$PROJECT_ROOT/config/settings.example.conf"
grep -Fq 'decky-lsfg-vk/releases/download/v0.12.8/Decky.LSFG-VK.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Decky-Framegen/releases/download/v0.17/Decky-Framegen.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'CheatDeck/releases/download/v2.0.0/CheatDeck.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'YukiCoco/ToMoon/releases/download/v0.2.8/tomoon-v0.2.8.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'jinzhongjia/decky-music/releases/download/v1.0.2/Decky.Music.full.zip' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '37b79e28e54691f9c7e301aaa83823e20f6cffc8948d312b7398dcc87e466e11' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'ensure_deckymusic_full_current' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_DECKYMUSIC_MIRROR_REPO="zhoukeer-toolbox-mirror-4"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Ren-Amamiya-pixle/DeckRecall/releases/download/v0.4.2/DeckRecall.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '38cbbaa94f39bbe7231f490fd3826f1347ce8c0acb53aa69c784d8511cc058fd' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Ren-Amamiya-pixle/SavePulse/releases/download/v0.2.0-alpha.1/SavePulse.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'e0680fc3995b8bbb2971673db43d5e9459d8fa8e4a1b431a1f5d4edad19a35ad' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_DECKRECALL_SHA256="38cbbaa94f39bbe7231f490fd3826f1347ce8c0acb53aa69c784d8511cc058fd"' \
    "$PROJECT_ROOT/config/settings.example.conf"
grep -Fq 'resolve_deckrecall_latest' "$PROJECT_ROOT/modules/plugin_store.sh"
deckrecall_install="$(sed -n '/^[[:space:]]*deckrecall)/,/^[[:space:]]*;;/p' "$PROJECT_ROOT/modules/plugin_store.sh")"
printf '%s\n' "$deckrecall_install" | grep -Fq '"DeckRecall"' || {
    echo "FAIL: DeckRecall 未校验发布包插件目录" >&2
    exit 1
}
printf '%s\n' "$deckrecall_install" | grep -Fq 'DeckRecall $installed_version 已是最新正式版，无需重复下载' || {
    echo "FAIL: DeckRecall 同版仍会重复下载" >&2
    exit 1
}
printf '%s\n' "$deckrecall_install" | grep -Fq 'GITHUB_MIN_SPEED_TIME=15' || {
    echo "FAIL: DeckRecall 下载低速切换时间过长" >&2
    exit 1
}
savepulse_install="$(sed -n '/^[[:space:]]*savepulse)/,/^[[:space:]]*;;/p' "$PROJECT_ROOT/modules/plugin_store.sh")"
printf '%s\n' "$savepulse_install" | grep -Fq '"SavePulse"' || {
    echo "FAIL: SavePulse 未校验发布包插件目录" >&2
    exit 1
}
printf '%s\n' "$savepulse_install" | grep -Fq 'DECKY_SAVEPULSE_SHA256' || {
    echo "FAIL: SavePulse 未使用固定 SHA256" >&2
    exit 1
}

# SavePulse 公开 Release 为单一顶层目录；使用本地 ZIP 桩验证固定版本安装、
# 目录检查、原子替换及 Decky 重载，不发起网络请求。
SAVEPULSE_ARCHIVE="$TMP_ROOT/SavePulse.zip"
SAVEPULSE_BUILD="$TMP_ROOT/savepulse-build/SavePulse"
SAVEPULSE_PLUGIN_ROOT="$TMP_ROOT/savepulse-plugins"
mkdir -p "$SAVEPULSE_BUILD/dist" "$SAVEPULSE_BUILD/backend" "$SAVEPULSE_PLUGIN_ROOT"
printf '{"name":"SavePulse","flags":["root"],"api_version":1}\n' > "$SAVEPULSE_BUILD/plugin.json"
printf '{"version":"0.2.0-alpha.1"}\n' > "$SAVEPULSE_BUILD/package.json"
printf 'test bundle\n' > "$SAVEPULSE_BUILD/dist/index.js"
printf '# backend fixture\n' > "$SAVEPULSE_BUILD/main.py"
printf '# package fixture\n' > "$SAVEPULSE_BUILD/backend/main.py"
(
    cd "$(dirname "$SAVEPULSE_BUILD")"
    zip -qr "$SAVEPULSE_ARCHIVE" SavePulse
)
savepulse_install_output="$(
    SAVEPULSE_ARCHIVE="$SAVEPULSE_ARCHIVE" \
    DECKY_PLUGIN_DIR="$SAVEPULSE_PLUGIN_ROOT" \
    PROJECT_ROOT="$PROJECT_ROOT" \
    ZHOUKEER_TEST_MODE=1 \
    bash -c '
        source "$PROJECT_ROOT/modules/plugin_store.sh"
        detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
        download_verified_package() { cp -- "$SAVEPULSE_ARCHIVE" "$4"; }
        reload_decky_plugins() { echo "TEST_RELOAD: SavePulse"; }
        install_configured_plugin savepulse
    '
)"
printf '%s\n' "$savepulse_install_output" | grep -Fq 'SavePulse（自动存档与加密 WebDAV 换机恢复） 安装成功。'
printf '%s\n' "$savepulse_install_output" | grep -Fq 'TEST_RELOAD: SavePulse'
[ -s "$SAVEPULSE_PLUGIN_ROOT/SavePulse/plugin.json" ] || {
    echo "FAIL: SavePulse 未安装到预期目录" >&2
    exit 1
}
(
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    deckrecall_version_is_older 0.2.8 0.3.1
    ! deckrecall_version_is_older 0.3.1 0.3.1
    ! deckrecall_version_is_older 0.10.0 0.9.0
) || {
    echo "FAIL: DeckRecall 未正确使用三段语义版本比较" >&2
    exit 1
}
grep -Fq 'mubaraknumann/unifideck/releases/download/Release-0.7.2/unifideck.prod.v0.7.2.zip' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'a313be924cabe15255d222742a402cd98cb510a35dfe4b2d06cf1e59366936de' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
unifideck_install="$(sed -n '/^[[:space:]]*unifideck)/,/^[[:space:]]*;;/p' \
    "$PROJECT_ROOT/modules/plugin_store.sh" | head -n 16)"
printf '%s\n' "$unifideck_install" | grep -Fq 'resolve_plugin_latest unifideck' || {
    echo "FAIL: Unifideck 安装前未自动检测最新 Release" >&2
    exit 1
}
printf '%s\n' "$unifideck_install" | grep -Fq 'ensure_steam302_for_download' || {
    echo "FAIL: Unifideck 大包下载前未先检查 Steam302 加速" >&2
    exit 1
}
printf '%s\n' "$unifideck_install" | grep -Fq 'GITHUB_MIN_SPEED_TIME=20' || {
    echo "FAIL: Unifideck 下载仍会长时间等待低速来源" >&2
    exit 1
}
printf '%s\n' "$unifideck_install" | grep -Fq '"Unifideck"' || {
    echo "FAIL: Unifideck 未使用官方压缩包中的大写目录" >&2
    exit 1
}
grep -Fq 'Freedeck/releases/download/0.6/freedeck.v.0.6.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '04329d07761c42cc481e97ddd4fc180fa51eb1d0388761424a8c90a18a822c62' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '"freedeck-plugin"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '"Freedeck" >/dev/null 2>&1; then' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: Freedeck 可用固定版本回退时仍会显示最新 Release 探测错误" >&2
    exit 1
}
grep -Fq 'Freedeck/releases/download/N0.2/NewFreedeck.v.0.2.zip' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '74988f2da1a0d63394f9b7d968df32fd34f1dba8b3ba7736b31e7c8b452a293a' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_NEWFREEDECK_VERSION="0.2.0"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_NEWFREEDECK_MIRROR_REPO="zhoukeer-toolbox-mirror-3"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
newfreedeck_install="$(sed -n '/^install_configured_plugin()/,/^decky_plugin_version()/p' \
    "$PROJECT_ROOT/modules/plugin_store.sh" | \
    sed -n '/^[[:space:]]*newfreedeck)/,/^[[:space:]]*;;/p')"
printf '%s\n' "$newfreedeck_install" | grep -Fq 'feature_plugin_is_current' || {
    echo "FAIL: NewFreedeck 未检测已安装版本" >&2
    exit 1
}
printf '%s\n' "$newfreedeck_install" | grep -Fq 'resolve_plugin_latest newfreedeck' || {
    echo "FAIL: NewFreedeck 安装前未自动检测作者最新 Release" >&2
    exit 1
}
printf '%s\n' "$newfreedeck_install" | grep -Fq '"NewFreedeck" 0' || {
    echo "FAIL: NewFreedeck 旧版本不会被原子替换" >&2
    exit 1
}
grep -Fq 'newfreedeck) show_plugin_download_speed_tip; install_configured_plugin newfreedeck' \
    "$PROJECT_ROOT/modules/plugin_store.sh"

# NewFreedeck 与 CheatDeck 一样在安装前读取最新 Release，并从资产名规范化三段版本号。
newfreedeck_latest="$(
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    resolve_latest_github_release() {
        _LATEST_RELEASE_URL="https://github.com/panyiwei-home/Freedeck/releases/download/N0.3/NewFreedeck.v.0.3.zip"
        _LATEST_RELEASE_SHA256="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        _LATEST_RELEASE_ASSET="NewFreedeck.v.0.3.zip"
        return 0
    }
    resolve_plugin_latest newfreedeck
    printf '%s|%s|%s\n' "$DECKY_NEWFREEDECK_VERSION" \
        "$DECKY_NEWFREEDECK_URL" "$DECKY_NEWFREEDECK_SHA256"
)"
[ "$newfreedeck_latest" = \
    '0.3.0|https://github.com/panyiwei-home/Freedeck/releases/download/N0.3/NewFreedeck.v.0.3.zip|aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' ] || {
    echo "FAIL: NewFreedeck 未正确解析作者最新 Release：$newfreedeck_latest" >&2
    exit 1
}

# 本地 ZIP 桩验证 0.1 会原子升级到 0.2.0，同版再次执行不会重复下载。
NEWFREEDECK_ARCHIVE="$TMP_ROOT/NewFreedeck.v.0.2.zip"
NEWFREEDECK_BUILD="$TMP_ROOT/newfreedeck-build/NewFreedeck"
NEWFREEDECK_PLUGIN_ROOT="$TMP_ROOT/newfreedeck-plugins"
mkdir -p "$NEWFREEDECK_BUILD/dist" "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/dist"
printf '{"name":"NewFreedeck","flags":[],"api_version":1}\n' > \
    "$NEWFREEDECK_BUILD/plugin.json"
printf '{"name":"Newfreedeck","version":"0.2.0"}\n' > \
    "$NEWFREEDECK_BUILD/package.json"
printf 'new bundle\n' > "$NEWFREEDECK_BUILD/dist/index.js"
printf '{"name":"NewFreedeck","flags":[],"api_version":1}\n' > \
    "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/plugin.json"
printf '{"name":"Newfreedeck","version":"0.1"}\n' > \
    "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/package.json"
printf 'old bundle\n' > "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/dist/index.js"
printf 'remove on update\n' > "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/old-marker.txt"
(
    cd "$(dirname "$NEWFREEDECK_BUILD")"
    zip -qr "$NEWFREEDECK_ARCHIVE" NewFreedeck
)
newfreedeck_upgrade_output="$(
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
    resolve_plugin_latest() { :; }
    download_verified_package() { cp -- "$NEWFREEDECK_ARCHIVE" "$4"; }
    reload_decky_plugins() { echo "TEST_RELOAD: NewFreedeck"; }
    DECKY_PLUGIN_DIR="$NEWFREEDECK_PLUGIN_ROOT"
    ZHOUKEER_TEST_MODE=1
    install_configured_plugin newfreedeck
)"
printf '%s\n' "$newfreedeck_upgrade_output" | \
    grep -Fq '检测到 NewFreedeck 旧版本 0.1，将更新到 0.2.0。'
printf '%s\n' "$newfreedeck_upgrade_output" | grep -Fq 'TEST_RELOAD: NewFreedeck'
installed_newfreedeck_version="$(sed -n \
    's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' \
    "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/package.json")"
[ "$installed_newfreedeck_version" = "0.2.0" ] || {
    echo "FAIL: NewFreedeck 旧版本未升级到 0.2.0" >&2
    exit 1
}
[ ! -e "$NEWFREEDECK_PLUGIN_ROOT/NewFreedeck/old-marker.txt" ] || {
    echo "FAIL: NewFreedeck 原子更新后仍残留旧文件" >&2
    exit 1
}
newfreedeck_repeat_output="$(
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
    resolve_plugin_latest() { :; }
    download_verified_package() { echo 'FAIL: 同版仍触发下载' >&2; return 1; }
    reload_decky_plugins() { echo 'FAIL: 同版仍触发重载' >&2; return 1; }
    DECKY_PLUGIN_DIR="$NEWFREEDECK_PLUGIN_ROOT"
    ZHOUKEER_TEST_MODE=1
    install_configured_plugin newfreedeck
)"
printf '%s\n' "$newfreedeck_repeat_output" | \
    grep -Fq '[已安装] NewFreedeck v0.2.0 已存在且文件完整，无需重复安装。'
grep -Fq 'PixelAddictUnlocked/allycenter/releases/download/v1.2.0/allycenter-v1.2.0.zip' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'a1059534de2a0e9556669adff3d933bcde802101faae7558f9b33db3a8e51bc7' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_ALLYCENTER_MIRROR_REPO="zhoukeer-toolbox-mirror-3"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'allycenter) show_plugin_download_speed_tip; install_configured_plugin allycenter' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'ALLYCENTER_ZH_INDEX_SHA256="1a937de0d4489663a436f165b0c872e770a21d1e34b58bf0a3ae52bde7ddb4cb"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
if grep -Eq '双风扇|全速|修补、汉化者|full_speed' \
    "$PROJECT_ROOT/third_party/allycenter-zh-v1.2.0/dist/index.js"; then
    echo "FAIL: Ally Center 中文前端仍包含 Renkit 的风扇修补功能" >&2
    exit 1
fi
grep -Fq '充电上限已设置为' \
    "$PROJECT_ROOT/third_party/allycenter-zh-v1.2.0/dist/index.js" || {
    echo "FAIL: Ally Center 中文构建缺少电池界面汉化" >&2
    exit 1
}
grep -Fq 'RGB 灯光' \
    "$PROJECT_ROOT/third_party/allycenter-zh-v1.2.0/src/index.tsx" || {
    echo "FAIL: Ally Center 中文构建缺少 RGB 界面汉化" >&2
    exit 1
}
allycenter_zh_actual_sha256="$(shasum -a 256 \
    "$PROJECT_ROOT/third_party/allycenter-zh-v1.2.0/dist/index.js" | awk '{print $1}')"
[ "$allycenter_zh_actual_sha256" = "1a937de0d4489663a436f165b0c872e770a21d1e34b58bf0a3ae52bde7ddb4cb" ] || {
    echo "FAIL: Ally Center 中文构建文件校验值不匹配" >&2
    exit 1
}
grep -Fq 'LSFG_ZH_MIRROR_ID="lsfg-zh-signed"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'LSFG_ZH_PACKAGE_SHA256="7f846c28bf5f9d08f6589a618c4e0c4ee4dffb05ad15938c39359c6460f1157b"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'FSR4_ZH_MIRROR_ID="fsr4-zh-signed"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'FSR4_ZH_PACKAGE_SHA256="409aa32b843500a6828b73feeed5cc7307d9c7c60a470e288f2c8cf777d03adb"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'download_github_file "$url" "$output" "$expected_sha256" "$name"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'https://gitee.com/zliu9732-hub/zhoukeer-toolbox/repository/archive/v6.0.4.zip' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'cbe50c9dcd64bba1433713c1945ec73de2fa1cc51f8a8327ef0f9cdd0ace147a' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'install_decky_zip_from_gitee_archive' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'install_tree_atomically' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_PLUGIN_DIR:-$HOME/homebrew/plugins' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Lossless Scaling 的 Steam 正版页面' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'steam://store/993090' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'import_lossless_backup' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'steam://install/993090' "$PROJECT_ROOT/modules/plugin_store.sh"

feature_install="$(sed -n '/^install_feature_plugins()/,/^}/p' "$PROJECT_ROOT/modules/plugin_store.sh")"
for install_call in \
    'install_lsfg_zh_from_gitee 0' \
    'install_fsr4_zh_from_gitee 0' \
    'install_configured_plugin cheatdeck 0 0' \
    'install_configured_plugin steamgriddb 0 0' \
    'install_configured_plugin cssloader 0 0' \
    'install_configured_plugin friendeck 0 0' \
    'install_configured_plugin deckymusic 0 0' \
    'install_configured_plugin fantastic 0 0'; do
    printf '%s\n' "$feature_install" | grep -Fq "$install_call" || {
        echo "FAIL: 常用插件组合缺少下载调用：$install_call" >&2
        exit 1
    }
done
store_line="$(printf '%s\n' "$feature_install" | grep -n 'check_lossless_scaling_installation' | tail -n 1 | cut -d: -f1)"
loop_line="$(printf '%s\n' "$feature_install" | grep -n 'done' | head -n 1 | cut -d: -f1)"
[ -n "$store_line" ] && [ -n "$loop_line" ] && [ "$store_line" -gt "$loop_line" ] || {
    echo "FAIL: 小黄鸭正版页面仍在常用插件组合安装中途打开" >&2
    exit 1
}
grep -Fq 'check_lossless_scaling_installation' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '未检测到 Steam 库中的 Lossless Scaling' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '选择名称以 Linux 开头的可用版本' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Steam Deck 机身右下角“三个点（…）”按钮' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '风灵月影，小黄鸭，FSR4使用教程.txt' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'FSR4支持游戏名单.txt' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'BV1ew411J7ab' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '败家君的游戏屋' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '找到“LSFG-VK”开关并打开' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '找到“OptiScaler”开关并打开' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'install_feature_plugins()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'print_feature_plugin_status()' "$PROJECT_ROOT/modules/plugin_store.sh"
feature_install_function="$(sed -n '/^install_feature_plugins()/,/^}/p' \
    "$PROJECT_ROOT/modules/plugin_store.sh")"
printf '%s\n' "$feature_install_function" | grep -Fq 'ensure_plugin_store_ready || return 1' || {
    echo "FAIL: 常用插件组合未先检查插件商城" >&2
    exit 1
}
grep -Fq 'install_plugin_store_auto || {' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: 插件组合没有调用按系统通道检测最新版的商城安装流程" >&2
    exit 1
}
grep -Fq 'decky_plugin_store_version()' "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: 插件商城缺少已安装版本读取" >&2
    exit 1
}
printf '%s\n' "$feature_install_function" | grep -Fq '小黄鸭（LSFG-VK）'
printf '%s\n' "$feature_install_function" | grep -Fq 'reload_decky_plugins'
printf '%s\n' "$feature_install_function" | grep -Fq '常用插件会出现在插头菜单中'
printf '%s\n' "$feature_install_function" | grep -Fq '九款常用功能插件'
printf '%s\n' "$feature_install_function" | grep -Fq 'feature_plugins="lsfg fsr4 cheatdeck lsfg-mako'
grep -Fq 'SWITCH_TO_WINDOWS_SOURCE_DIR="$PROJECT_ROOT/decky-plugins/switch-to-windows"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Switch to Windows v$SWITCH_TO_WINDOWS_VERSION 安装成功；本人制作：RenAmamiya。' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'switch-to-windows) install_configured_plugin switch-to-windows' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_FANTASTIC_URL="https://gitee.com/' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'fantastic) show_plugin_download_speed_tip; install_configured_plugin fantastic' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '正在直接安装 Fantastic v$DECKY_FANTASTIC_VERSION 汉化版' "$PROJECT_ROOT/modules/plugin_store.sh"
if grep -Fq '正在从 Gitee mirror-3 直接安装 Fantastic' "$PROJECT_ROOT/modules/plugin_store.sh"; then
    echo "FAIL: Fantastic 安装进度仍显示镜像名称" >&2
    exit 1
fi
grep -Fq 'CheatDeck 安装完成后可在 Decky 右侧栏显示' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '风灵月影网址.txt' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '若返回游戏模式后没有看到 Decky 的插头图标' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'Steam 键 → 设置 → 启用开发者模式' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '设置左侧出现“开发者”后 → 开发者 → 杂项' "$PROJECT_ROOT/modules/plugin_store.sh"
NOTE_DESKTOP="$TMP_ROOT/note-desktop"
PROJECT_ROOT="$PROJECT_ROOT" ZHOUKEER_DESKTOP_DIR="$NOTE_DESKTOP" bash -c '
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    write_flingtrainer_desktop_note
' || {
    echo "FAIL: 无法生成风灵月影网址桌面文件" >&2
    exit 1
}
grep -Fxq 'flingtrainer.com' "$NOTE_DESKTOP/风灵月影网址.txt" || {
    echo "FAIL: 风灵月影网址桌面文件内容错误" >&2
    exit 1
}
grep -Fq '英文搜索并下载对应游戏的最新修改器' "$NOTE_DESKTOP/风灵月影网址.txt" || {
    echo "FAIL: 风灵月影网址桌面文件缺少使用说明" >&2
    exit 1
}
grep -Fq 'install_all_plugin_packages()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'decky_plugin_store_is_installed()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '未检测到插件商城，先安装插件商城。' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'LSFG_RUNTIME_ARCHIVE="lsfg-vk_noui.zip"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'FSR4_RUNTIME_ARCHIVE="Optiscaler_0.9.4-final.20260718._MM.7z"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'restore_lsfg_official()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'LSFG_ZH_INDEX_SHA256="49d475932c6508a2c58113f605857ba9d26b92646ae49f31804e8f1a913d7d1b"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'FSR4_ZH_INDEX_SHA256="961d4571a5068f8410885617f3fdf1016ea7b1284a9c9cc6311dc1251de21515"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '小黄鸭署名包的国内镜像不可用，已保留现有插件。' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'FSR4 署名包的国内镜像不可用，已保留现有插件。' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '"name": "掌机功耗控制"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/plugin.json"
grep -Fq '"description": "掌机硬件控制插件，支持 TDP、GPU 等。中文汉化：RenAmamiya。"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/plugin.json" || {
    echo "FAIL: SimpleDeckyTDP 插件清单说明仍为英文" >&2
    exit 1
}
grep -Fq 'const manifest = {"name":"掌机功耗控制"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 前端 API 身份名与插件清单不一致" >&2
    exit 1
}
grep -Fq '"description":"掌机硬件控制插件，支持 TDP、GPU 等。中文汉化：RenAmamiya。"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 前端内嵌清单说明仍为英文" >&2
    exit 1
}
python3 - \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/i18n/en.json" \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/i18n/zh.json" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as handle:
    english = json.load(handle)
with open(sys.argv[2], encoding="utf-8") as handle:
    chinese = json.load(handle)

if set(english) != set(chinese):
    raise SystemExit("FAIL: SimpleDeckyTDP 中英文词库键不完整")
unchanged = [key for key in english if english[key] == chinese[key]]
if unchanged:
    raise SystemExit("FAIL: SimpleDeckyTDP 中文词库仍有英文原文: " + ", ".join(unchanged))
PY
grep -Fq '"version": "1.0.7"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/package.json"
[ "$(grep -Fc 'RenAmamiya汉化' "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js")" -ge 1 ] || {
    echo "FAIL: SimpleDeckyTDP 插件打开后缺少可见汉化署名" >&2
    exit 1
}
grep -Fq '中文汉化：RenAmamiya · 原插件作者：Aarron Lee' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 缺少与小黄鸭一致的作者署名行" >&2
    exit 1
}
grep -Fq 'color: "#ffcc66"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 缺少与小黄鸭一致的突出汉化署名" >&2
    exit 1
}
grep -Fq 'lang.includes("-")' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP v1.0.7 缺少地区后缀语言码兼容修复" >&2
    exit 1
}
grep -Fq 'cachedLang = "zh";' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 中文版没有强制命中简体中文词库" >&2
    exit 1
}
grep -Fq 'CPU_CONTROLS_TITLE: "CPU 设置"' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 中文构建未内嵌主要中文界面词条" >&2
    exit 1
}
grep -Fq '请在 RenKit 中更新掌机功耗控制；插件内官方重装会覆盖中文界面。' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" || {
    echo "FAIL: SimpleDeckyTDP 中文版缺少由 RenKit 管理更新的可见提示" >&2
    exit 1
}
if grep -Fq 'createElement(OtaUpdates, null)' \
    "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js"; then
    echo "FAIL: SimpleDeckyTDP 中文版仍会显示覆盖汉化的官方重装入口" >&2
    exit 1
fi
simpledeckytdp_future_output="$(PROJECT_ROOT="$PROJECT_ROOT" bash -c '
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    DECKY_SIMPLE_TDP_URL="https://github.com/aarron-lee/SimpleDeckyTDP/releases/download/v1.0.7/SimpleDeckyTDP.zip"
    DECKY_SIMPLE_TDP_VERSION="v1.0.7"
    DECKY_SIMPLE_TDP_SHA256="dae7cf43ec8936c07a94a08ac418be8d9e129744a54f3aa63d2b31222bc0ad38"
    resolve_latest_github_release() {
        _LATEST_RELEASE_TAG="v1.0.8"
        _LATEST_RELEASE_URL="https://example.invalid/SimpleDeckyTDP-v1.0.8.zip"
        _LATEST_RELEASE_SHA256="ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
        return 0
    }
    resolve_plugin_latest simpledeckytdp
    printf "RESULT:%s:%s\n" "$DECKY_SIMPLE_TDP_VERSION" "$DECKY_SIMPLE_TDP_SHA256"
')"
printf '%s\n' "$simpledeckytdp_future_output" | \
    grep -Fq 'v1.0.8 尚未完成Renkit汉化，继续使用 v1.0.7' || {
    echo "FAIL: SimpleDeckyTDP 新上游版本没有保留已汉化安全基线" >&2
    exit 1
}
printf '%s\n' "$simpledeckytdp_future_output" | \
    grep -Fq 'RESULT:v1.0.7:dae7cf43ec8936c07a94a08ac418be8d9e129744a54f3aa63d2b31222bc0ad38' || {
    echo "FAIL: SimpleDeckyTDP 未汉化新版本覆盖了固定下载配置" >&2
    exit 1
}
simpledeckytdp_actual_sha256="$(shasum -a 256 "$PROJECT_ROOT/third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js" | awk '{print $1}')"
[ "$simpledeckytdp_actual_sha256" = "22b8e59c71e3e3f3f94b2eff4864bb39f362a8b095916b4614d1ce636fe9cb16" ] || {
    echo "FAIL: SimpleDeckyTDP 中文构建文件校验值不匹配" >&2
    exit 1
}
grep -Fq 'SIMPLEDECKYTDP_ZH_INDEX_SHA256="22b8e59c71e3e3f3f94b2eff4864bb39f362a8b095916b4614d1ce636fe9cb16"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'install_simpledeckytdp_chinese()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'simpledeckytdp_chinese_is_current()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '"$plugin_root/$SIMPLEDECKYTDP_OFFICIAL_DIRECTORY/dist/index.js"' \
    "$PROJECT_ROOT/modules/plugin_store.sh" || {
    echo "FAIL: SimpleDeckyTDP 最新版检测未校验前端文件" >&2
    exit 1
}
grep -Fq 'ensure_simpledeckytdp_chinese_current()' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'simpledeckytdp-zh-gitee) ensure_simpledeckytdp_chinese_current' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'cp -a -- "$official_bin_dir" "$staged_source/bin"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
if grep -Eq '^copy_zhoukeer_localizer$' "$PROJECT_ROOT/install.sh"; then
    echo "FAIL: 已停用的扫描式汉化不应继续随安装器复制" >&2
    exit 1
fi
if grep -En 'copy_lsfg_chinese|copy_fsr4_chinese|decky-lsfg-vk-zh-v0[.]12[.]5|decky-framegen-zh-v0[.]17' \
    "$PROJECT_ROOT/install.sh" "$PROJECT_ROOT/scripts/package_release.sh"; then
    echo "FAIL: 安装或发布脚本仍携带旧本地中文覆盖层" >&2
    exit 1
fi
grep -Fq 'copy_allycenter_chinese()' "$PROJECT_ROOT/install.sh" || {
    echo "FAIL: 主安装器未复制 Ally Center 中文组件" >&2
    exit 1
}
grep -Fq 'copy_allycenter_chinese' "$PROJECT_ROOT/install.sh"
grep -Fq 'third_party/allycenter-zh-v1.2.0/dist/index.js' \
    "$PROJECT_ROOT/scripts/package_release.sh" || {
    echo "FAIL: 发布包未强制校验 Ally Center 中文前端" >&2
    exit 1
}
grep -Fq 'toolbox_sudo systemctl restart "$DECKY_SERVICE_NAME"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '旧版通用扫描式汉化已停用' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'features) show_plugin_download_speed_tip; install_feature_plugins' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'tomoon) show_plugin_download_speed_tip; install_configured_plugin tomoon' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'deckrecall) show_plugin_download_speed_tip; install_configured_plugin deckrecall' "$PROJECT_ROOT/modules/plugin_store.sh"

# DeckRecall 使用专用 mirror-3；安装完成标记仍不能被子 Shell 隔离，
# Decky 才能在新安装或旧安装修复后正确重载。
DECKRECALL_RELOAD_LOG="$TMP_ROOT/deckrecall-reload.log"
DECKRECALL_MIRROR_LOG="$TMP_ROOT/deckrecall-mirror.log"
(
    export DECKRECALL_RELOAD_LOG DECKRECALL_MIRROR_LOG
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
    resolve_plugin_latest() { return 0; }
    install_decky_zip() {
        printf '%s\n' "${GITEE_MIRROR_REPO:-missing}" >> "$DECKRECALL_MIRROR_LOG"
        case "${DECKRECALL_TEST_MODE:-new}" in
            new) PLUGIN_INSTALL_CHANGED=1 ;;
            existing) PLUGIN_INSTALL_CHANGED=0 ;;
            *) return 1 ;;
        esac
    }
    decky_plugin_directory_is_complete() {
        [ "${DECKRECALL_TEST_MODE:-new}" = "existing" ]
    }
    patch_deckrecall_steam_browser() { return 0; }
    reload_decky_plugins() {
        printf 'reload\n' >> "$DECKRECALL_RELOAD_LOG"
    }

    DECKRECALL_TEST_MODE=new install_configured_plugin deckrecall
    DECKRECALL_TEST_MODE=existing install_configured_plugin deckrecall
)
[ "$(grep -c '^reload$' "$DECKRECALL_RELOAD_LOG")" -eq 2 ] || {
    echo "FAIL: DeckRecall 新安装或已有文件修复后没有重载 Decky" >&2
    exit 1
}
[ "$(grep -c '^zhoukeer-toolbox-mirror-3$' "$DECKRECALL_MIRROR_LOG")" -eq 2 ] || {
    echo "FAIL: DeckRecall 安装未使用专用 mirror-3" >&2
    exit 1
}
printf '%s\n' "$deckrecall_install" | grep -Fq 'GITEE_MIRROR_REPO="$DECKY_DECKRECALL_MIRROR_REPO"' || {
    echo "FAIL: DeckRecall 缺少专用 mirror-3 注入" >&2
    exit 1
}

# DeckRecall 必须对齐桌面模式已验证可下载的 Steam 浏览器调用，不能改用
# 系统浏览器；重复修复必须保持幂等，并能迁移 1.4.1 的错误补丁。
DECKRECALL_PLUGIN_ROOT="$TMP_ROOT/deckrecall-browser/plugins"
mkdir -p "$DECKRECALL_PLUGIN_ROOT/DeckRecall/dist"
printf '%s\n' \
    'before();DFL.Navigation.NavigateToExternalWeb("https://flingtrainer.com/");after();' \
    > "$DECKRECALL_PLUGIN_ROOT/DeckRecall/dist/index.js"
(
    export DECKY_PLUGIN_DIR="$DECKRECALL_PLUGIN_ROOT"
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    patch_deckrecall_steam_browser
    first_hash="$(shasum -a 256 "$DECKY_PLUGIN_DIR/DeckRecall/dist/index.js" | awk '{print $1}')"
    patch_deckrecall_steam_browser
    second_hash="$(shasum -a 256 "$DECKY_PLUGIN_DIR/DeckRecall/dist/index.js" | awk '{print $1}')"
    [ "$first_hash" = "$second_hash" ] || {
        echo "FAIL: DeckRecall 浏览器补丁重复执行后改变了文件" >&2
        exit 1
    }
)
grep -Fq 'steamBrowser.OpenUrl("https://flingtrainer.com/");' \
    "$DECKRECALL_PLUGIN_ROOT/DeckRecall/dist/index.js" || {
    echo "FAIL: DeckRecall 没有直接调用 Steam 浏览器" >&2
    exit 1
}
if grep -Fq 'systemBrowser.OpenInSystemBrowser' \
    "$DECKRECALL_PLUGIN_ROOT/DeckRecall/dist/index.js"; then
    echo "FAIL: DeckRecall 仍在调用系统默认浏览器" >&2
    exit 1
fi
[ "$(grep -Foc 'DFL.Navigation.NavigateToExternalWeb("https://flingtrainer.com/");' \
    "$DECKRECALL_PLUGIN_ROOT/DeckRecall/dist/index.js")" -eq 1 ] || {
    echo "FAIL: DeckRecall 浏览器补丁没有保留唯一的兼容回退" >&2
    exit 1
}

DECKRECALL_WRONG_PATCH_ROOT="$TMP_ROOT/deckrecall-wrong-browser/plugins"
mkdir -p "$DECKRECALL_WRONG_PATCH_ROOT/DeckRecall/dist"
cat > "$DECKRECALL_WRONG_PATCH_ROOT/DeckRecall/dist/index.js" <<'SCRIPT'
before();const systemBrowser = globalThis.SteamClient?.System;
                                if (typeof systemBrowser?.OpenInSystemBrowser === "function") {
                                    systemBrowser.OpenInSystemBrowser("https://flingtrainer.com/");
                                    return;
                                }
                                DFL.Navigation.NavigateToExternalWeb("https://flingtrainer.com/");after();
SCRIPT
(
    export DECKY_PLUGIN_DIR="$DECKRECALL_WRONG_PATCH_ROOT"
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    patch_deckrecall_steam_browser
)
grep -Fq 'steamBrowser.OpenUrl("https://flingtrainer.com/");' \
    "$DECKRECALL_WRONG_PATCH_ROOT/DeckRecall/dist/index.js" || {
    echo "FAIL: DeckRecall 没有迁移 1.4.1 的错误系统浏览器补丁" >&2
    exit 1
}
if grep -Fq 'systemBrowser.OpenInSystemBrowser' \
    "$DECKRECALL_WRONG_PATCH_ROOT/DeckRecall/dist/index.js"; then
    echo "FAIL: DeckRecall 迁移后仍保留错误系统浏览器调用" >&2
    exit 1
fi
grep -Fq 'onexplayer-apex) show_plugin_download_speed_tip; install_configured_plugin onexplayer-apex' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'OneXPlayer_Apex_Tools.zip' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '7c522bc8145697d78d6165f7f97671d4d67a5bf4f9e4ed5e6feccbb1154acb91' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '仅支持 OneXPlayer Apex 的原版 SteamOS' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'ONEXPLAYER_APEX_ZH_SOURCE_DIR="$PROJECT_ROOT/third_party/onexplayer-apex-tools-zh-v0.1.0"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'ONEXPLAYER_APEX_ZH_INDEX_SHA256="a85f19f0f910ac9f400ab52b273c1e82080a1d1c22b5fa3f94c469fcf852ab85"' "$PROJECT_ROOT/modules/plugin_store.sh"
OXP_CALLS="$TMP_ROOT/onexplayer-apex.calls"
(
    export OXP_CALLS
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
    ensure_handheld_overlay_current() {
        printf '%s\n' "type:$1" >> "$OXP_CALLS"
        printf '%s\n' "directory:$2" >> "$OXP_CALLS"
        printf '%s\n' "version:$3" >> "$OXP_CALLS"
        printf '%s\n' "archive:$5" >> "$OXP_CALLS"
        printf '%s\n' "sha256:$6" >> "$OXP_CALLS"
        printf '%s\n' "overlay:$7" >> "$OXP_CALLS"
        printf '%s\n' "overlay-sha256:$8" >> "$OXP_CALLS"
        printf '%s\n' "mirror:${DECKY_HANDHELD_PLUGIN_MIRROR_REPO:-}" >> "$OXP_CALLS"
        printf '%s\n' "author:$9" >> "$OXP_CALLS"
    }
    install_configured_plugin onexplayer-apex
)
grep -Fxq 'archive:https://github.com/srsholmes/onexplayer-apex-bazzite-fixes/releases/download/build-b696161/OneXPlayer_Apex_Tools.zip' "$OXP_CALLS"
grep -Fxq 'sha256:7c522bc8145697d78d6165f7f97671d4d67a5bf4f9e4ed5e6feccbb1154acb91' "$OXP_CALLS"
grep -Fxq 'mirror:zhoukeer-toolbox-mirror-3' "$OXP_CALLS"
grep -Fxq 'type:zip' "$OXP_CALLS"
grep -Fxq 'directory:OneXPlayer Apex Tools' "$OXP_CALLS"
grep -Fxq 'version:0.1.0' "$OXP_CALLS"
grep -Fxq "overlay:$PROJECT_ROOT/third_party/onexplayer-apex-tools-zh-v0.1.0" "$OXP_CALLS"
grep -Fxq 'overlay-sha256:a85f19f0f910ac9f400ab52b273c1e82080a1d1c22b5fa3f94c469fcf852ab85' "$OXP_CALLS"
grep -Fxq 'author:原作者：Simon Holmes（srsholmes）；许可证：MIT。' "$OXP_CALLS"
grep -Fq '"tomoon"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'feature-status) print_feature_plugin_status' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'uninstall) uninstall_all_decky_plugins' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '不会删除 Decky Loader 本体' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'all) show_plugin_download_speed_tip; install_all_plugin_packages' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'lsfg-mako) show_plugin_download_speed_tip; install_configured_plugin lsfg-mako' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'eugeniosegala/MAKO' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'LSFG_MAKO_DIRECTORY="Mako"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'LSFG_MAKO_VERSION="2.2.0"' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'DECKY_LSFG_MAKO_SHA256="621ad66bd40f12b416e8112bb78e1aae55a96bf7fe14439b95fca1cf89324089"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq 'LSFG_MAKO_INDEX_SHA256="e615016e8d1bb89634be7b259e24a972537cef0238b9036a20235bfffc615e2e"' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '正在安装小黄鸭' "$PROJECT_ROOT/modules/plugin_store.sh"
configured_plugin_function="$(sed -n '/^install_configured_plugin()/,/^}/p' "$PROJECT_ROOT/modules/plugin_store.sh")"
if printf '%s\n' "$configured_plugin_function" | grep -Fq 'remove_legacy_lsfg_directories'; then
    echo "FAIL: 安装 MAKO 小黄鸭时不应删除旧版 LSFG-VK" >&2
    exit 1
fi

grep -Fq '正在安装 FSR4' "$PROJECT_ROOT/modules/plugin_store.sh"
grep -Fq '将依次直接安装：小黄鸭、FSR4、CheatDeck、游戏封面更换、主题美化、文件传输助手、音乐播放器、Fantastic 风扇控制。' \
    "$PROJECT_ROOT/modules/plugin_store.sh"
if grep -Fq 'Lossless Scaling.rar' "$PROJECT_ROOT/modules/plugin_store.sh" || \
    grep -Eq 'https?://[^[:space:]]*Lossless' "$PROJECT_ROOT/modules/plugin_store.sh"; then
    echo "FAIL: 付费软件本体不应配置为客户下载源"
    exit 1
fi
if grep -Fqi '云盘' "$PROJECT_ROOT/modules/plugin_store.sh"; then
    echo "FAIL: 插件下载模块不应保留第三方云盘地址"
    exit 1
fi

output="$(bash "$PROJECT_ROOT/modules/plugin_store.sh" lsfg || true)"
printf '%s\n' "$output" | grep -Fq '仅支持 SteamOS、Bazzite 或 ChimeraOS'

simpledeckytdp_output="$(bash "$PROJECT_ROOT/modules/plugin_store.sh" simpledeckytdp-zh-gitee || true)"
printf '%s\n' "$simpledeckytdp_output" | grep -Fq '仅支持 SteamOS、Bazzite 或 ChimeraOS'

allycenter_output="$(bash "$PROJECT_ROOT/modules/plugin_store.sh" allycenter || true)"
printf '%s\n' "$allycenter_output" | \
    grep -Fq 'Decky 插件安装仅支持 SteamOS、Bazzite 或 ChimeraOS'

(
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    resolve_latest_gitee_mirror() {
        [ "${GITEE_MIRROR_REPO:-}" = "zhoukeer-toolbox-mirror-3" ] || exit 81
        [ "${GITEE_MIRROR_CONNECT_TIMEOUT:-}" = "5" ] || exit 82
        [ "${GITEE_MIRROR_MAX_TIME:-}" = "8" ] || exit 83
        [ "${GITEE_MIRROR_RETRIES:-}" = "1" ] || exit 84
        _GITEE_MIRROR_LATEST_VERSION="plugin-v2.2.0"
        _GITEE_MIRROR_LATEST_FILE="MAKO-Decky-v2.2.0.zip"
        _GITEE_MIRROR_LATEST_URL="https://github.com/eugeniosegala/MAKO/releases/download/plugin-v2.2.0/MAKO-Decky-v2.2.0.zip"
        _GITEE_MIRROR_LATEST_SHA256="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
    resolve_latest_github_release() {
        echo "FAIL: MAKO 已取得 Gitee 镜像版本后不应继续等待 GitHub" >&2
        exit 1
    }
    resolve_plugin_latest lsfg-mako
    [ "$LSFG_MAKO_VERSION" = "2.2.0" ] || {
        echo "FAIL: MAKO 没有从 Gitee 镜像资产名更新版本" >&2
        exit 1
    }
    [ "$DECKY_LSFG_MAKO_SHA256" = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" ] || {
        echo "FAIL: MAKO 没有采用 Gitee 镜像清单 SHA256" >&2
        exit 1
    }
)

(
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    resolve_latest_gitee_mirror() { return 1; }
    resolve_latest_github_release() {
        [ "${GITHUB_API_CONNECT_TIMEOUT:-}" = "5" ] || exit 91
        [ "${GITHUB_API_MAX_TIME:-}" = "8" ] || exit 92
        _LATEST_RELEASE_TAG="plugin-v2.2.0"
        _LATEST_RELEASE_ASSET="MAKO-Decky-v2.2.0.zip"
        _LATEST_RELEASE_URL="https://github.com/eugeniosegala/MAKO/releases/download/plugin-v2.2.0/MAKO-Decky-v2.2.0.zip"
        _LATEST_RELEASE_SHA256="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
    }
    resolve_plugin_latest lsfg-mako
    [ "$LSFG_MAKO_VERSION" = "2.2.0" ] || exit 93
    [ "$DECKY_LSFG_MAKO_SHA256" = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb" ] || exit 94
)

MAKO_CALLS="$TMP_ROOT/mako.calls"
(
    export DECKY_PLUGIN_DIR="$TMP_ROOT/mako-plugins"
    export MAKO_CALLS
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
    resolve_plugin_latest() {
        LSFG_MAKO_VERSION="2.2.0"
        DECKY_LSFG_MAKO_URL="https://github.com/eugeniosegala/MAKO/releases/download/plugin-v2.2.0/MAKO-Decky-v2.2.0.zip"
        DECKY_LSFG_MAKO_SHA256="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
    MAKO_CHECKS=0
    mako_official_is_current() {
        MAKO_CHECKS=$((MAKO_CHECKS + 1))
        [ "$MAKO_CHECKS" -ge 2 ]
    }
    install_decky_zip() {
        printf '%s\n' "$2" > "$MAKO_CALLS"
        printf '%s\n' "$3" >> "$MAKO_CALLS"
        printf '%s\n' "${GITEE_MIRROR_REPO:-missing}" >> "$MAKO_CALLS"
        printf '%s\n' "$5" >> "$MAKO_CALLS"
        PLUGIN_INSTALL_CHANGED=1
    }
    remove_legacy_lsfg_directories() { return 0; }
    refresh_feature_usage_guides() { return 0; }
    reload_decky_plugins() { return 0; }
    install_configured_plugin lsfg-mako
)
grep -Fxq 'https://github.com/eugeniosegala/MAKO/releases/download/plugin-v2.2.0/MAKO-Decky-v2.2.0.zip' "$MAKO_CALLS" || {
    echo "FAIL: MAKO 小黄鸭没有把作者最新 Release 交给统一下载器" >&2
    exit 1
}
grep -Fxq 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' "$MAKO_CALLS" || {
    echo "FAIL: MAKO 小黄鸭没有校验最新官方 SHA256" >&2
    exit 1
}
grep -Fq 'zhoukeer-toolbox-mirror-3' "$MAKO_CALLS" || {
    echo "FAIL: MAKO 小黄鸭没有使用 mirror-3 分块镜像" >&2
    exit 1
}
grep -Fxq '0' "$MAKO_CALLS" || {
    echo "FAIL: MAKO 更新没有强制替换旧版本" >&2
    exit 1
}
if grep -En 'apply_mako_zh_patch|LSFG_MAKO_ZH_(JSON|EN_JSON)' \
    "$PROJECT_ROOT/modules/plugin_store.sh" >/dev/null; then
    echo "FAIL: MAKO 官方中文原包仍会调用 Renkit 汉化覆盖层" >&2
    exit 1
fi

# 小黄鸭官方 v0.12.8 使用 Decky LSFG-VK，旧汉化包使用“小黄鸭”；
# 状态检查必须同时兼容官方名和旧中文名。
PLUGIN_ROOT="$TMP_ROOT/plugins"
for plugin_dir in "Decky LSFG-VK" Decky-Framegen CheatDeck decky-steamgriddb SDH-CssLoader Friendeck-plugin "Decky Music"; do
    mkdir -p "$PLUGIN_ROOT/$plugin_dir/dist"
    printf 'bundle\n' > "$PLUGIN_ROOT/$plugin_dir/dist/index.js"
done
printf '{"name":"Decky LSFG-VK"}\n' > "$PLUGIN_ROOT/Decky LSFG-VK/plugin.json"
printf '{"version":"0.12.8"}\n' > "$PLUGIN_ROOT/Decky LSFG-VK/package.json"
printf '{ "name": "Decky-Framegen" }\n' > "$PLUGIN_ROOT/Decky-Framegen/plugin.json"
printf '{"version":"0.17"}\n' > "$PLUGIN_ROOT/Decky-Framegen/package.json"
printf '{"name": "CheatDeck"}\n' > "$PLUGIN_ROOT/CheatDeck/plugin.json"
printf '{"version":"2.0.0"}\n' > "$PLUGIN_ROOT/CheatDeck/package.json"
printf '{"name": "SteamGridDB"}\n' > "$PLUGIN_ROOT/decky-steamgriddb/plugin.json"
printf '{"version":"1.7.1"}\n' > "$PLUGIN_ROOT/decky-steamgriddb/package.json"
printf '{"name": "主题美化"}\n' > "$PLUGIN_ROOT/SDH-CssLoader/plugin.json"
printf '{"version":"2.1.2"}\n' > "$PLUGIN_ROOT/SDH-CssLoader/package.json"
cp "$PROJECT_ROOT/third_party/cssloader-zh-v2.1.2/dist/index.js" \
    "$PLUGIN_ROOT/SDH-CssLoader/dist/index.js"
printf '{"name": "Friendeck"}\n' > "$PLUGIN_ROOT/Friendeck-plugin/plugin.json"
printf '{"version":"0.7.5"}\n' > "$PLUGIN_ROOT/Friendeck-plugin/package.json"
printf '{"name": "Decky Music"}\n' > "$PLUGIN_ROOT/Decky Music/plugin.json"
printf '{"version":"1.0.2"}\n' > "$PLUGIN_ROOT/Decky Music/package.json"
mkdir -p "$PLUGIN_ROOT/Decky Music/bin"
for binary in player qq-provider ncm-provider; do
    printf 'binary fixture\n' > "$PLUGIN_ROOT/Decky Music/bin/$binary"
done
status_output="$(DECKY_PLUGIN_DIR="$PLUGIN_ROOT" \
    bash "$PROJECT_ROOT/modules/plugin_store.sh" feature-status)"
printf '%s\n' "$status_output" | grep -Fq '✓ 小黄鸭（LSFG-VK）：已写入 Decky'
printf '%s\n' "$status_output" | grep -Fq '✓ FSR4（Decky-Framegen）：已写入 Decky，官方版本 0.17'
printf '%s\n' "$status_output" | grep -Fq '✓ CheatDeck：已写入 Decky，官方版本 2.0.0'
printf '%s\n' "$status_output" | grep -Fq '✓ 游戏封面更换（SteamGridDB）'
printf '%s\n' "$status_output" | grep -Fq '✓ 主题美化（CSS Loader）'
printf '%s\n' "$status_output" | grep -Fq '✓ 文件传输助手（Friendeck）'
printf '%s\n' "$status_output" | grep -Fq '✓ 音乐播放器（Decky Music）'

rm -f -- "$PLUGIN_ROOT/Decky Music/bin/ncm-provider"
if incomplete_music_status="$(DECKY_PLUGIN_DIR="$PLUGIN_ROOT" \
    bash "$PROJECT_ROOT/modules/plugin_store.sh" feature-status)"; then
    echo "FAIL: Decky Music 缺少音乐源时不应通过状态检查" >&2
    exit 1
fi
printf '%s\n' "$incomplete_music_status" | \
    grep -Fq '音乐源文件不完整'
printf 'binary fixture\n' > "$PLUGIN_ROOT/Decky Music/bin/ncm-provider"

printf '{"name":"小黄鸭"}\n' > "$PLUGIN_ROOT/Decky LSFG-VK/plugin.json"
legacy_status_output="$(DECKY_PLUGIN_DIR="$PLUGIN_ROOT" \
    bash "$PROJECT_ROOT/modules/plugin_store.sh" feature-status)"
printf '%s\n' "$legacy_status_output" | \
    grep -Fq '✓ 小黄鸭（LSFG-VK）：已写入 Decky'

printf '{"version":"0.12.1"}\n' > "$PLUGIN_ROOT/Decky LSFG-VK/package.json"
if stale_status_output="$(DECKY_PLUGIN_DIR="$PLUGIN_ROOT" \
    bash "$PROJECT_ROOT/modules/plugin_store.sh" feature-status)"; then
    echo "FAIL: 旧版小黄鸭不应被识别为官方 0.12.8" >&2
    exit 1
fi
printf '%s\n' "$stale_status_output" | \
    grep -Fq '检测到版本 0.12.1，请更新到 0.12.8'

printf '{"version":"0.12.8"}\n' > "$PLUGIN_ROOT/Decky LSFG-VK/package.json"
printf '{"version":"0.16.9"}\n' > "$PLUGIN_ROOT/Decky-Framegen/package.json"
if stale_fsr4_status_output="$(DECKY_PLUGIN_DIR="$PLUGIN_ROOT" \
    bash "$PROJECT_ROOT/modules/plugin_store.sh" feature-status)"; then
    echo "FAIL: 旧版 FSR4 不应被识别为官方 0.17" >&2
    exit 1
fi
printf '%s\n' "$stale_fsr4_status_output" | \
    grep -Fq '检测到版本 0.16.9，请更新到 0.17'

printf '{"version":"1.2.1"}\n' > "$PLUGIN_ROOT/CheatDeck/package.json"
if stale_cheatdeck_status_output="$(DECKY_PLUGIN_DIR="$PLUGIN_ROOT" \
    bash "$PROJECT_ROOT/modules/plugin_store.sh" feature-status)"; then
    echo "FAIL: 旧版 CheatDeck 不应被识别为官方 2.0.0" >&2
    exit 1
fi
printf '%s\n' "$stale_cheatdeck_status_output" | \
    grep -Fq '检测到版本 1.2.1，请更新到 2.0.0'

# 整组安装必须把同名旧版送入更新流程，不能只凭名称和目录跳过。
printf '{"version":"0.12.1"}\n' > "$PLUGIN_ROOT/Decky LSFG-VK/package.json"
printf '{"version":"1.2.1"}\n' > "$PLUGIN_ROOT/CheatDeck/package.json"
update_output="$(
    DECKY_PLUGIN_DIR="$PLUGIN_ROOT" PROJECT_ROOT="$PROJECT_ROOT" bash -c '
        source "$PROJECT_ROOT/modules/plugin_store.sh"
        detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
        ensure_plugin_store_ready() { return 0; }
        install_lsfg_zh_from_gitee() {
            printf '\''{"version":"%s"}\n'\'' "$LSFG_OFFICIAL_VERSION" > \
                "$DECKY_PLUGIN_DIR/$LSFG_OFFICIAL_DIRECTORY/package.json"
            echo "TEST_UPDATE: LSFG"
        }
        install_fsr4_zh_from_gitee() {
            printf '\''{"version":"%s"}\n'\'' "$FSR4_OFFICIAL_VERSION" > \
                "$DECKY_PLUGIN_DIR/$FSR4_OFFICIAL_DIRECTORY/package.json"
            echo "TEST_UPDATE: FSR4"
        }
        install_configured_plugin() {
            case "$1" in
                cheatdeck)
                    printf '\''{"version":"%s"}\n'\'' "$DECKY_CHEATDECK_VERSION" > \
                        "$DECKY_PLUGIN_DIR/CheatDeck/package.json"
                    echo "TEST_UPDATE: CheatDeck"
                    ;;
                steamgriddb) echo "TEST_UPDATE: SteamGridDB" ;;
                cssloader) echo "TEST_UPDATE: CSS Loader" ;;
                friendeck) echo "TEST_UPDATE: Friendeck" ;;
                deckymusic) echo "TEST_UPDATE: Decky Music" ;;
                fantastic)
                    mkdir -p "$DECKY_PLUGIN_DIR/Fantastic"
                    cp -R "$PROJECT_ROOT/third_party/fantastic-zh-v0.5.1/." \
                        "$DECKY_PLUGIN_DIR/Fantastic/"
                    echo "TEST_UPDATE: Fantastic"
                    ;;
                *) return 1 ;;
            esac
            return 0
        }
        refresh_feature_usage_guides() { return 0; }
        reload_decky_plugins() { return 0; }
        check_lossless_scaling_installation() { return 0; }
        write_flingtrainer_desktop_note() { return 0; }
        print_cef_remote_debugging_tip() { return 0; }
        install_feature_plugins
    '
)"
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: LSFG'
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: FSR4'
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: CheatDeck'
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: SteamGridDB'
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: CSS Loader'
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: Friendeck'
printf '%s\n' "$update_output" | grep -Fq 'TEST_UPDATE: Decky Music'
printf '%s\n' "$update_output" | grep -Fq '官方版本 0.12.8'
printf '%s\n' "$update_output" | grep -Fq '官方版本 0.17'

# Ally Center 官方包的 plugin.json 位于 ZIP 根目录；使用全临时目录和下载桩
# 验证同一套校验、解压、原子替换流程可正确安装，且再次执行会幂等跳过。
ALLY_ARCHIVE="$TMP_ROOT/allycenter-v1.2.0.zip"
ALLY_BUILD="$TMP_ROOT/allycenter-build"
ALLY_PLUGIN_ROOT="$TMP_ROOT/allycenter-plugins"
mkdir -p "$ALLY_BUILD/dist" "$ALLY_PLUGIN_ROOT"
printf '{"name":"Ally Center","author":"Keith Baker","flags":["root"],"api_version":1}\n' \
    > "$ALLY_BUILD/plugin.json"
printf '{"version":"1.2.0"}\n' > "$ALLY_BUILD/package.json"
printf '# official backend fixture\n' > "$ALLY_BUILD/main.py"
printf 'test bundle\n' > "$ALLY_BUILD/dist/index.js"
printf 'official runtime asset\n' > "$ALLY_BUILD/dist/runtime.js"
(
    cd "$ALLY_BUILD"
    zip -qr "$ALLY_ARCHIVE" .
)
ally_install_output="$(
    ALLY_ARCHIVE="$ALLY_ARCHIVE" \
    DECKY_PLUGIN_DIR="$ALLY_PLUGIN_ROOT" \
    PROJECT_ROOT="$PROJECT_ROOT" \
    ZHOUKEER_DECKY_ALLYCENTER_URL="https://example.invalid/allycenter-v1.2.0.zip" \
    ZHOUKEER_TEST_MODE=1 \
    bash -c '
        source "$PROJECT_ROOT/modules/plugin_store.sh"
        detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
        download_verified_package() { cp -- "$ALLY_ARCHIVE" "$4"; }
        reload_decky_plugins() { echo "TEST_RELOAD: Ally Center"; }
        ensure_allycenter_chinese_current
    '
)"
printf '%s\n' "$ally_install_output" | grep -Fq 'Ally Center（ROG Ally / Ally X 控制中心） 安装成功。'
printf '%s\n' "$ally_install_output" | grep -Fq 'Ally Center v1.2.0 中文版已安装。'
printf '%s\n' "$ally_install_output" | grep -Fq 'TEST_RELOAD: Ally Center'
[ -s "$ALLY_PLUGIN_ROOT/Ally Center/plugin.json" ] || {
    echo "FAIL: Ally Center 根目录结构未安装 plugin.json" >&2
    exit 1
}
grep -Fq '"name":"Ally Center"' "$ALLY_PLUGIN_ROOT/Ally Center/plugin.json" || {
    echo "FAIL: Ally Center 安装后未保留原版插件清单" >&2
    exit 1
}
[ -s "$ALLY_PLUGIN_ROOT/Ally Center/dist/index.js" ] || {
    echo "FAIL: Ally Center 根目录结构未安装前端文件" >&2
    exit 1
}
grep -Fq 'official runtime asset' "$ALLY_PLUGIN_ROOT/Ally Center/dist/runtime.js" || {
    echo "FAIL: Ally Center 汉化覆盖丢失了官方 dist 文件" >&2
    exit 1
}
installed_allycenter_sha256="$(shasum -a 256 \
    "$ALLY_PLUGIN_ROOT/Ally Center/dist/index.js" | awk '{print $1}')"
[ "$installed_allycenter_sha256" = "$allycenter_zh_actual_sha256" ] || {
    echo "FAIL: Ally Center 安装后未覆盖为已校验的中文前端" >&2
    exit 1
}
grep -Fq '# official backend fixture' "$ALLY_PLUGIN_ROOT/Ally Center/main.py" || {
    echo "FAIL: Ally Center 安装后未保留原版后台" >&2
    exit 1
}
grep -Fq '"version":"1.2.0"' "$ALLY_PLUGIN_ROOT/Ally Center/package.json"
ally_repeat_output="$(
    DECKY_PLUGIN_DIR="$ALLY_PLUGIN_ROOT" \
    PROJECT_ROOT="$PROJECT_ROOT" \
    ZHOUKEER_DECKY_ALLYCENTER_URL="https://example.invalid/allycenter-v1.2.0.zip" \
    ZHOUKEER_TEST_MODE=1 \
    bash -c '
        source "$PROJECT_ROOT/modules/plugin_store.sh"
        detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
        ensure_allycenter_chinese_current
    '
)"
printf '%s\n' "$ally_repeat_output" | \
    grep -Fq '[已检测] Ally Center 已是最新汉化版 v1.2.0，无需处理。'

# A bad bundled backend must fail before any download or replacement.
cp -R "$PROJECT_ROOT/third_party/allycenter-zh-v1.2.0" "$TMP_ROOT/bad-ally-bundle"
printf 'broken frontend\n' > "$TMP_ROOT/bad-ally-bundle/dist/index.js"
PROJECT_ROOT="$PROJECT_ROOT" DECKY_PLUGIN_DIR="$ALLY_PLUGIN_ROOT" \
    BAD_BUNDLE="$TMP_ROOT/bad-ally-bundle" ZHOUKEER_TEST_MODE=1 bash -c '
    source "$PROJECT_ROOT/modules/plugin_store.sh"
    detect_platform() { IS_STEAMOS=1; }
    ALLYCENTER_ZH_SOURCE_DIR="$BAD_BUNDLE"
    # Force the upgrade path while preserving the installed fixture.
    allycenter_chinese_is_current() { return 1; }
    download_verified_package() { echo "FAIL: bad bundle reached downloader" >&2; exit 99; }
    if ensure_allycenter_chinese_current; then
        echo "FAIL: corrupt frontend was accepted" >&2
        exit 1
    fi
    grep -Fq "# official backend fixture" "$DECKY_PLUGIN_DIR/Ally Center/main.py"
'

echo "PASS: Decky国内源、独立功能插件和完整清单配置检查通过"
