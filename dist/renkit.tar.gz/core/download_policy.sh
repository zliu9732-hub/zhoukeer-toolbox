#!/bin/bash

# 下载供应链策略由Renkit代码维护，不能从用户配置扩展域名。
# 调用方仍须校验固定版本的 SHA256/签名；白名单只决定是否允许发起请求。

if [ -n "${ZHOUKEER_DOWNLOAD_POLICY_LOADED:-}" ]; then
    return 0
fi
ZHOUKEER_DOWNLOAD_POLICY_LOADED=1

download_policy_source_catalog() {
    cat <<'EOF'
ID|域名|用途|允许文件类型|版本策略|校验方式|大小上限（字节）|回退规则
toolbox-gitee|gitee.com|Renkit版本、校验文件与固定镜像|text,sha256,tar.gz,zip,deb,AppImage|固定 main 或固定标签|SHA256+完整性校验+包内版本|1073741824|域名源→GitHub
toolbox-github|raw.githubusercontent.com,github.com|Renkit更新与固定 Release|text,sha256,tar.gz,zip,AppImage|固定仓库、版本或标签|SHA256+结构检查|1073741824|Gitee/域名源
toolbox-domain|jktool.icu|Renkit更新备用|text,sha256,tar.gz|固定 main 发布内容|SHA256+包内版本|9437184|GitHub→Gitee
github-proxy|ghproxy.net,gh.api.99988866.xyz,github.moeyy.xyz,gh.llkk.cc,mirror.ghproxy.com,gh.ddlc.com,gh-proxy.lanqier.me,ghfast.top|固定 GitHub 文件加速|同原始文件|只转发白名单 GitHub URL|调用方固定 SHA256|1073741824|GitHub 官方源
github-api|api.github.com|GitHub 最新正式 Release 元数据|json|仅最新正式 Release|GitHub SHA256 digest|2097152|固定版本回退
decky|gitee.com,www.mhhf.com,github.com,raw.githubusercontent.com,plugins.deckbrew.xyz,cdn.tzatzikiweeb.moe|Decky Gitee镜像、国内镜像、官方国外源和官方插件|binary,service,json,zip|固定版本或 Decky 官方数据库|SHA256/Decky hash|536870912|Gitee镜像→国内镜像→Decky官方源→停止安装
flathub|mirror.sjtu.edu.cn,mirrors.ustc.edu.cn,dl.flathub.org|Flatpak 国内缓存与官方源|flatpakrepo,repo|固定远程|Flatpak GPG；国内缓存例外需明确确认|2097152|上海交大→中科大→官方
vendors|qq-web.cdn-go.cn,im.qq.com,qqdl.gtimg.cn,dldir1v6.qq.com,launcher-public-service-prod06.ol.epicgames.com,epicgames-download1.akamaized.net,downloader.battle.net,static3.cdn.ubi.com|官方应用安装包|json,AppImage,exe,msi|官方当前版或固定版|官方HTTPS+固定路径+类型/大小；固定版另验SHA256|536870912|停止安装
launcher-preinstalled|gitee.com|战网预装客户端固定镜像|7z|固定版本|SHA256+分卷重组|94371840|停止安装
steam302|gitee.com|Steamcommunity 302 固定版本（自有 Gitee 镜像）|tar.gz|固定版本|MD5+SHA256+结构检查|536870912|停止安装
clover|gitee.com|Clover 双系统引导固定资源（Gitee 来源）|tar.gz|固定版本|SHA256+完整性校验|1073741824|自有 Gitee 镜像
todesk|github.com,dl.todesk.com|ToDesk 官方 Linux 客户端的未修改镜像与官网|deb|固定官方版本|SHA256+DEB/包内结构|268435456|Gitee镜像→GitHub镜像源→官网→停止安装
EOF
}

download_progress_filter() {
    local label="${1:-下载}"
    local segment_index="${2:-0}"
    local segment_total="${3:-1}"
    local progress_fd=1
    local progress_chunk=""

    # GUI 动作会经过日志管道。存在真实控制终端时直接刷新 Konsole，避免
    # 管道或日志查看器把每次回车刷新展开成多行；无终端的测试仍走 stdout。
    if [ "${ZHOUKEER_PROGRESS_DIRECT_TTY:-0}" = "1" ] && [ ! -t 1 ] && \
        [ -c /dev/tty ] && exec 9>/dev/tty 2>/dev/null; then
        progress_fd=9
    fi

    # curl 用回车符刷新进度。tr 的块缓冲会把这些刷新积压到下载结束；
    # Bash read 每收到一个回车就立即输出一帧，让后面的 awk 实时渲染。
    while IFS= read -r -d $'\r' progress_chunk || [ -n "$progress_chunk" ]; do
        printf '%s\n' "$progress_chunk"
        progress_chunk=""
    done | awk -v label="$label" \
        -v segment_index="$segment_index" -v segment_total="$segment_total" '
        BEGIN {
            if (segment_index !~ /^[0-9]+$/) segment_index = 0
            if (segment_total !~ /^[1-9][0-9]*$/) segment_total = 1
            if (segment_index >= segment_total) segment_index = 0
            bar_width = 20
        }
        function progress_line(line) {
            return line ~ /^[ ]*[0-9]+[ ]+[0-9]+/ && NF >= 8
        }
        function progress_bar(percent,    filled, result, i) {
            filled = int(percent * bar_width / 100)
            result = ""
            for (i = 0; i < filled; i++) result = result "#"
            for (i = filled; i < bar_width; i++) result = result "-"
            return result
        }
        function render_progress(raw_percent, raw_speed,    percent, speed, unit) {
            if (raw_percent < 0) raw_percent = 0
            if (raw_percent > 100) raw_percent = 100
            percent = int((segment_index * 100 + raw_percent) / segment_total)
            if (percent < last_percent) percent = last_percent
            last_percent = percent
            speed = raw_speed
            unit = "B/s"
            if (speed ~ /[kK]$/) { unit = "KB/s"; speed = substr(speed, 1, length(speed) - 1) }
            else if (speed ~ /[mM]$/) { unit = "MB/s"; speed = substr(speed, 1, length(speed) - 1) }
            else if (speed ~ /[gG]$/) { unit = "GB/s"; speed = substr(speed, 1, length(speed) - 1) }
            printf "\r\033[2K正在下载 %s... [%s] %d%%（%s %s）", \
                label, progress_bar(percent), percent, speed, unit
            fflush()
        }
        {
            line = $0
            lowered = tolower(line)
            if (lowered ~ /^curl: \(/) {
                failed = 1
                next
            }
            if (lowered ~ /warning:/) {
                next
            }
            if (line ~ /% Total/ || line ~ /Dload/ || line ~ /Upload/) {
                next
            }
            if (progress_line(line)) {
                raw_percent = $1 + 0
                # curl 跟随重定向时，会先把几百字节的跳转响应报告为 100%，
                # 随后正式文件又从 0% 开始。延迟一帧；检测到 100→低百分比
                # 时丢弃跳转帧，避免进度提前完成或倒退。
                if (raw_percent >= 100) {
                    pending_percent = raw_percent
                    pending_speed = $NF
                    have_pending = 1
                    next
                }
                # 低百分比紧跟在待定的 100% 后面，说明前一帧属于跳转响应。
                have_pending = 0
                render_progress(raw_percent, $NF)
                next
            }
            if (line != "") print line
        }
        END {
            if (have_pending) render_progress(pending_percent, pending_speed)
            if (failed || segment_index + 1 >= segment_total) printf "\n"
        }
    ' >&"$progress_fd"
    [ "$progress_fd" -ne 9 ] || exec 9>&-
}

# 通过命名管道等待进度渲染进程彻底结束，避免下一项输出抢先换行，造成
# 5% 与 10% 等进度帧堆叠。调用参数为：名称、分段序号、总分段数、curl参数。
run_curl_with_progress() {
    local label="$1" segment_index="${2:-0}" segment_total="${3:-1}"
    local progress_dir progress_fifo progress_pid curl_status
    shift 3

    progress_dir="$(mktemp -d "${TMPDIR:-/tmp}/renkit-progress.XXXXXX")" || return 1
    progress_fifo="$progress_dir/curl.stderr"
    if ! mkfifo "$progress_fifo"; then
        rmdir "$progress_dir" 2>/dev/null || true
        return 1
    fi
    download_progress_filter "$label" "$segment_index" "$segment_total" \
        < "$progress_fifo" >&2 &
    progress_pid=$!
    curl "$@" 2> "$progress_fifo"
    curl_status=$?
    wait "$progress_pid" 2>/dev/null || true
    rm -f -- "$progress_fifo"
    rmdir "$progress_dir" 2>/dev/null || true
    return "$curl_status"
}

download_policy_github_repo_allowed() {
    case "$1" in
        SteamDeckHomebrew/decky-loader|Taskerer/SDWEAK|ShadowBlip/InputPlumber|dahui/onexplayer-x2-mini-pro-cachyos|srsholmes/onexplayer-apex-bazzite-fixes|xXJSONDeruloXx/decky-lsfg-vk|eugeniosegala/decky-lsfg-vk-experimental|eugeniosegala/MAKO|xXJSONDeruloXx/Decky-Framegen|SheffeyG/CheatDeck|YukiCoco/ToMoon|Ren-Amamiya-pixle/DeckRecall|Ren-Amamiya-pixle/SavePulse|aarron-lee/SimpleDeckyTDP|mengmeet/PowerControl|mubaraknumann/unifideck|panyiwei-home/Freedeck|panyiwei-home/Friendeck|jinzhongjia/decky-music|GloriousEggroll/proton-ge-custom|CachyOS/proton-cachyos|rustdesk/rustdesk|zliu9732-hub/zhoukeer-toolbox|zliu9732-hub/decky-lsfg-vk-zh|zliu9732-hub/decky-framegen-zh|HMCL-dev/HMCL|adoptium/temurin21-binaries) return 0 ;;
        *) return 1 ;;
    esac
}

download_policy_github_mirror_allowed() {
    case "${1%/}" in
        https://github.com|https://ghproxy.net|https://gh.api.99988866.xyz|https://github.moeyy.xyz|https://gh.llkk.cc|https://mirror.ghproxy.com|https://gh.ddlc.com|https://gh-proxy.lanqier.me|https://ghfast.top) return 0 ;;
        *) return 1 ;;
    esac
}

download_policy_url_allowed() {
    local url="$1"
    local rest repo

    case "$url" in
        https://api.github.com/repos/*/releases/latest) return 0 ;;
        https://api.github.com/repos/SteamDeckHomebrew/decky-loader/releases?per_page=*) return 0 ;;
        https://github.com/*)
            rest="${url#https://github.com/}"
            repo="${rest%%/releases/*}"
            [ "$repo" != "$rest" ] || repo="${rest%%/archive/*}"
            download_policy_github_repo_allowed "$repo"
            ;;
        https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/*) return 0 ;;
        https://raw.githubusercontent.com/dahui/onexplayer-x2-mini-pro-cachyos/a0b76a16471174ded80913a681357f43bfb17fa4/*) return 0 ;;
        https://raw.githubusercontent.com/SteamDeckHomebrew/decky-loader/v3.2.8/dist/plugin_loader-release.service) return 0 ;;
        https://raw.githubusercontent.com/SteamDeckHomebrew/decky-loader/v3.2.8-pre1/dist/plugin_loader-prerelease.service) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-2/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-3/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-4/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-5/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-6/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-7/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-8/*) return 0 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-9/*) return 0 ;;
        https://gitee.com/easylife2025/battle/releases/download/v1.0.0/Battle.net.7z.001|https://gitee.com/easylife2025/battle/releases/download/v1.0.0/Battle.net.7z.002|https://gitee.com/easylife2025/battle/releases/download/v1.0.0/Battle.net.7z.003|https://gitee.com/easylife2025/battle/releases/download/v1.0.0/Battle.net.7z.004) return 0 ;;
        https://gitee.com/easylife2025/emu/releases/download/v1.0.0/Clover.tar.gz) return 0 ;;
        https://dl.todesk.com/linux/todesk-v4.8.6.2-amd64.deb) return 0 ;;
        https://jktool.icu/VERSION|https://jktool.icu/dist/SHA256SUMS|https://jktool.icu/dist/renkit.tar.gz|https://jktool.icu/dist/zhoukeer-toolbox.tar.gz) return 0 ;;
        https://www.mhhf.com/Deck/decky/*|https://plugins.deckbrew.xyz/plugins|https://cdn.tzatzikiweeb.moe/file/steam-deck-homebrew/versions/*) return 0 ;;
        https://mirror.sjtu.edu.cn/flathub*|https://mirrors.ustc.edu.cn/flathub*|https://mirrors.ustc.edu.cn/archlinuxcn/*|https://dl.flathub.org/repo/*) return 0 ;;
        https://qq-web.cdn-go.cn/im.qq.com_new/latest/rainbow/pcConfig.json|https://im.qq.com/proxy/domain/qq-web.cdn-go.cn/im.qq.com_new/latest/rainbow/pcConfig.json|https://qqdl.gtimg.cn/qqfile/*.AppImage|https://dldir1v6.qq.com/weixin/Universal/Linux/WeChatLinux_x86_64.AppImage) return 0 ;;
        https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/installer/download/EpicGamesLauncherInstaller.msi|https://downloader.battle.net/download/getInstallerForGame\?os=win\&installer=Battle.net-Setup.exe|https://static3.cdn.ubi.com/orbit/launcher_installer/UbisoftConnectInstaller.exe) return 0 ;;
        https://epicgames-download1.akamaized.net/Builds/UnrealEngineLauncher/Installers/Windows/EpicInstaller-20.1.4.msi*) return 0 ;;
        https://epicgames-download1.akamaized.net/Builds/UnrealEngineLauncher/Installers/Windows/EpicInstaller-20.1.4.exe*) return 0 ;;
        https://www.dogfight360.com/blog/wp-content/uploads/2026/02/steamcommunity_302_Linux_AMD64_V14.0.02.tar.gz) return 0 ;;
        *)
            if [ "${ZHOUKEER_TEST_MODE:-0}" = "1" ]; then
                case "$url" in https://*) return 0 ;; esac
            fi
            return 1
            ;;
    esac
}

download_policy_max_bytes() {
    case "${1%%\?*}" in
        https://api.github.com/*) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/mirrors/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-2/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-3/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-4/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-5/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-6/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-7/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-8/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-9/raw/main/*/latest.txt) printf '%s\n' 2097152 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/mirrors/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-2/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-3/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-4/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-5/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-6/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-7/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-8/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror-9/raw/main/*/part.*) printf '%s\n' 8388608 ;;
        https://gitee.com/easylife2025/battle/releases/download/*) printf '%s\n' 104857600 ;;
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/dist/renkit.tar.gz|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/dist/renkit.tar.gz|https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/main/dist/renkit.tar.gz|https://jktool.icu/dist/renkit.tar.gz|https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/dist/zhoukeer-toolbox.tar.gz|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/dist/zhoukeer-toolbox.tar.gz|https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/main/dist/zhoukeer-toolbox.tar.gz|https://jktool.icu/dist/zhoukeer-toolbox.tar.gz) printf '%s\n' 9437184 ;;
        */VERSION|*/SHA256SUMS|*.json|*.flatpakrepo|*.service|*.txt) printf '%s\n' 2097152 ;;
        *.deb) printf '%s\n' 268435456 ;;
        *.AppImage|*.exe|*.msi|*.zip) printf '%s\n' 536870912 ;;
        *.tar.gz|*.tar.zst) printf '%s\n' 1073741824 ;;
        *) printf '%s\n' 134217728 ;;
    esac
}

download_policy_file_size() {
    if stat -c '%s' -- "$1" >/dev/null 2>&1; then
        stat -c '%s' -- "$1"
    else
        stat -f '%z' -- "$1"
    fi
}

download_policy_response_is_safe() {
    local url="$1"
    local file="$2"
    local size max prefix

    [ -f "$file" ] && [ ! -L "$file" ] && [ -s "$file" ] || return 1
    size="$(download_policy_file_size "$file")" || return 1
    max="$(download_policy_max_bytes "$url")"
    case "$size" in ''|*[!0-9]*) return 1 ;; esac
    [ "$size" -le "$max" ] || return 1
    if LC_ALL=C head -c 512 "$file" 2>/dev/null | grep -Eiq '<(!doctype[[:space:]]+html|html[[:space:]>])|access[[:space:]]+denied|error[[:space:]]+403'; then
        return 1
    fi
    prefix="$(LC_ALL=C od -An -tx1 -N4 "$file" 2>/dev/null | tr -d ' \n')"
    case "${url%%\?*}" in
        *.zip) case "$prefix" in 504b0304|504b0506|504b0708) ;; *) return 1 ;; esac ;;
        *.tar.gz) [ "${prefix#1f8b}" != "$prefix" ] || return 1 ;;
        *.deb) [ "$prefix" = "213c6172" ] || return 1 ;;
        *.AppImage) [ "$prefix" = "7f454c46" ] || return 1 ;;
        *.exe) [ "${prefix#4d5a}" != "$prefix" ] || return 1 ;;
        *.msi) case "$prefix" in d0cf11e0|4d5a*) ;; *) return 1 ;; esac ;;
    esac
}
