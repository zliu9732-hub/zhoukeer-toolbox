#!/bin/bash

set -u

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN_PROGRAM="$PROJECT_ROOT/main.sh"
MAIN_PROFILE_FILE="${XDG_DATA_HOME:-$HOME/.local/share}/konsole/ZhoukeerToolbox.profile"
PROFILE_FILE="$MAIN_PROFILE_FILE"
STARTUP_VIEW="main-with-disclaimer"
WINDOW_SIZE="1280x740"
FONT_SIZE="12"
WINDOW_FULLSCREEN="${ZHOUKEER_WINDOW_FULLSCREEN:-0}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
LAUNCH_LOG="${ZHOUKEER_LAUNCH_LOG:-$STATE_HOME/zhoukeer-toolbox/launcher.log}"

resolve_main_program() {
    if [ -r "$PROJECT_ROOT/core/platform.sh" ]; then
        # shellcheck disable=SC1091
        source "$PROJECT_ROOT/core/platform.sh"
        detect_platform
        if [ "$(uname -s 2>/dev/null || echo unknown)" = "Linux" ] && \
            [ "${IS_CHIMERAOS:-0}" -eq 1 ]; then
            MAIN_PROGRAM="$PROJECT_ROOT/main-chimera.sh"
        elif [ "$(uname -s 2>/dev/null || echo unknown)" = "Linux" ] && \
            [ "${IS_STEAMOS:-0}" -ne 1 ]; then
            MAIN_PROGRAM="$PROJECT_ROOT/main-bazzite.sh"
        fi
    fi
}

prepare_launcher_log() {
    local fallback_log

    if mkdir -p "$(dirname "$LAUNCH_LOG")" 2>/dev/null && \
        touch "$LAUNCH_LOG" 2>/dev/null; then
        chmod 600 "$LAUNCH_LOG" 2>/dev/null || true
        return 0
    fi

    fallback_log="${TMPDIR:-/tmp}/zhoukeer-toolbox-launcher-${UID:-user}.log"
    LAUNCH_LOG="$fallback_log"
    touch "$LAUNCH_LOG" 2>/dev/null || return 1
    chmod 600 "$LAUNCH_LOG" 2>/dev/null || true
}

launcher_log() {
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$$" "$*" \
        >> "$LAUNCH_LOG" 2>/dev/null || true
}

show_launch_error() {
    local title="$1"
    local message="$2"

    launcher_log "错误：${title}；${message//$'\n'/；}"

    if command -v kdialog >/dev/null 2>&1 && \
        kdialog --title "$title" --error "$message" >/dev/null 2>&1; then
        return 0
    fi
    if command -v zenity >/dev/null 2>&1 && \
        zenity --error --title="$title" --text="$message" >/dev/null 2>&1; then
        return 0
    fi
    if command -v xmessage >/dev/null 2>&1 && \
        xmessage -center "$title

$message" >/dev/null 2>&1; then
        return 0
    fi
    if command -v notify-send >/dev/null 2>&1 && \
        notify-send -u critical "$title" "$message" >/dev/null 2>&1; then
        return 0
    fi

    printf '%s\n%s\n' "$title" "$message" >&2
    return 1
}

run_startup_update() {
    local default_install_dir="$HOME/.local/share/zhoukeer-toolbox"
    local startup_update_max_seconds="${ZHOUKEER_STARTUP_UPDATE_MAX_SECONDS:-60}"
    local status

    [ "${ZHOUKEER_AUTO_UPDATE:-1}" != "0" ] || return 0
    [ "${ZHOUKEER_SKIP_STARTUP_UPDATE:-0}" != "1" ] || return 0
    [ "$(uname -s 2>/dev/null || echo unknown)" = "Linux" ] || return 0
    [ -r "$PROJECT_ROOT/update.sh" ] || return 0

    if [ ! -f "$PROJECT_ROOT/.zhoukeer-installed" ] && \
        [ "$PROJECT_ROOT" != "$default_install_dir" ] && \
        [ "${ZHOUKEER_AUTO_UPDATE_FORCE:-0}" != "1" ]; then
        launcher_log "跳过自动更新：当前目录不是受管理的安装目录"
        return 0
    fi

    launcher_log "开始启动自动更新检测"

    # Konsole 默认工作目录就是安装目录，更新时该目录会被原子替换。
    # 提前移到稳定目录，更新后再进入新版本，避免父进程保留已删除的 cwd。
    cd "$HOME" 2>/dev/null || cd / || true
    # 自动更新只写入启动日志。正常启动不回显下载、校验或安装器的底层输出，
    # 避免终端在进入Renkit前残留二进制/归档等技术信息。
    if command -v timeout >/dev/null 2>&1; then
        timeout -k 5 "$startup_update_max_seconds" \
            bash "$PROJECT_ROOT/update.sh" --startup >> "$LAUNCH_LOG" 2>&1
    else
        bash "$PROJECT_ROOT/update.sh" --startup >> "$LAUNCH_LOG" 2>&1
    fi
    status=$?
    cd "$PROJECT_ROOT" 2>/dev/null || cd "$HOME" 2>/dev/null || cd / || true

    if [ "$status" -eq 0 ]; then
        launcher_log "启动自动更新检测完成"
    else
        if [ "$status" -eq 124 ] || [ "$status" -eq 137 ]; then
            launcher_log "启动自动更新超过${startup_update_max_seconds}秒，已停止并继续当前版本"
        else
            launcher_log "启动自动更新检测失败：状态码=${status}；继续当前版本"
        fi
        printf '%s\n' "自动更新暂时不可用，继续启动当前版本。"
    fi
    return 0
}

filter_terminal_stderr() {
    local line

    while IFS= read -r line; do
        case "$line" in
            *"QLayout: Cannot add a null widget to QHBoxLayout"*| \
            *"curl: ("*| \
            *"Operation timed out"*| \
            *"Connection timed out"*| \
            *"Connection refused"*| \
            *"Could not resolve host"*| \
            *"Failed to connect"*| \
            *"No route to host"*| \
            *"Empty reply from server"*| \
            *"HTTP error"*| \
            *"SSL"*|*"TLS"*| \
            *"error:"*|*"Error:"*|*"WARNING:"*)
                launcher_log "已隐藏英文错误提示：$line"
                ;;
            *)
                printf '%s\n' "$line" >&2
                launcher_log "终端启动输出：$line"
                ;;
        esac
    done
}

run_startup_screen() {
    printf '\033[0m\033[r\033[3J\033[2J\033[H\n\n  Renkit启动中，请耐心等待…\n  若启动较慢，Renkit可能正在更新，请耐心等待。\n'
    run_startup_update
    if [ "$(uname -s 2>/dev/null || echo unknown)" = Linux ] &&
        [ -r "$PROJECT_ROOT/modules/inputplumber_update.sh" ]; then
        bash "$PROJECT_ROOT/modules/inputplumber_update.sh" auto >> "$LAUNCH_LOG" 2>&1 ||
            launcher_log "InputPlumber 自动检查或更新失败；继续启动 RenKit"
    fi
}

run_main() {
    local status
    local message

    # 启动更新可能受网络或镜像响应影响。先显示明确状态，避免 Konsole 在
    # 更新检查尚未结束时只留下空白背景而被误认为Renkit已经卡死。
    if [ "$MAIN_PROGRAM" = "$PROJECT_ROOT/main.sh" ] && [ -t 0 ] && [ -t 1 ] &&
        command -v python3 >/dev/null 2>&1; then
        python3 "$PROJECT_ROOT/scripts/terminal_brand.py" -- bash "$PROJECT_ROOT/launch.sh" --run-startup-screen
    else
        run_startup_screen
    fi
    # 自动更新与主界面复用同一个终端；进入触控 UI 前清除更新输出和滚动残影。
    printf '\033[0m\033[r\033[3J\033[2J\033[H'
    launcher_log "主程序开始：$MAIN_PROGRAM --touch"
    if [ ! -r "$MAIN_PROGRAM" ]; then
        message="主程序文件缺失或无法读取：
$MAIN_PROGRAM

启动日志：$LAUNCH_LOG"
        show_launch_error "Renkit启动失败" "$message" || true
        return 1
    fi

    if command -v tee >/dev/null 2>&1; then
        ZHOUKEER_LAUNCHED=1 bash "$MAIN_PROGRAM" --touch \
            2> >(tee -a "$LAUNCH_LOG" | filter_terminal_stderr >&2)
        status=$?
    else
        ZHOUKEER_LAUNCHED=1 bash "$MAIN_PROGRAM" --touch
        status=$?
    fi

    launcher_log "主程序结束：状态码=$status"
    if [ "$status" -eq 0 ]; then
        return 0
    fi

    message="主程序异常退出（状态码：${status}）。
请把启动日志发给维护者排查：
$LAUNCH_LOG"
    if ! show_launch_error "Renkit运行失败" "$message"; then
        if [ -r /dev/tty ] && [ -w /dev/tty ]; then
            printf '按回车键关闭窗口...' > /dev/tty
            read -r _ < /dev/tty || true
        fi
    fi
    return "$status"
}

prepare_launcher_log || true
resolve_main_program

case "${1:-}" in
    --run-startup-screen)
        run_startup_screen
        exit $?
        ;;
    --run-main)
        run_main
        exit $?
        ;;
    --open-main)
        PROFILE_FILE="$MAIN_PROFILE_FILE"
        STARTUP_VIEW="main"
        ;;
    "")
        launcher_log "免责声明使用终端文字版"
        ;;
    *)
        show_launch_error "Renkit启动失败" \
            "启动器收到未知参数：$1
启动日志：$LAUNCH_LOG" || true
        exit 2
        ;;
esac

launcher_log "启动请求：目录=$PROJECT_ROOT 系统=$(uname -s 2>/dev/null || echo unknown)"

screen_size() {
    local value="${ZHOUKEER_SCREEN_SIZE:-}"

    if [ -z "$value" ] && command -v xrandr >/dev/null 2>&1; then
        value="$(xrandr --current 2>/dev/null | awk -F'[ x]' '/\*/ { print $1 "x" $2; exit }')"
    fi
    if [ -z "$value" ] && command -v kscreen-doctor >/dev/null 2>&1; then
        value="$(kscreen-doctor -o 2>/dev/null | \
            awk '/[0-9]+x[0-9]+/ { match($0, /[0-9]+x[0-9]+/); print substr($0, RSTART, RLENGTH); exit }')"
    fi
    if [ -z "$value" ] && command -v xdpyinfo >/dev/null 2>&1; then
        value="$(xdpyinfo 2>/dev/null | awk '/dimensions:/ { print $2; exit }')"
    fi
    case "$value" in
        [0-9]*x[0-9]*) printf '%s\n' "$value" ;;
    esac
}

adapt_window_size() {
    local screen width height window_width window_height font

    screen="$(screen_size)"
    [ -n "$screen" ] || return 0
    width="${screen%x*}"
    height="${screen#*x}"
    case "$width" in ''|*[!0-9]*) return 0 ;; esac
    case "$height" in ''|*[!0-9]*) return 0 ;; esac

    window_width=$((width * 94 / 100))
    window_height=$((height * 92 / 100))
    [ "$window_width" -ge 1024 ] || window_width=1024
    [ "$window_height" -ge 600 ] || window_height=600
    [ "$window_width" -le 3840 ] || window_width=3840
    [ "$window_height" -le 2160 ] || window_height=2160

    if [ "$height" -le 800 ]; then font=12
    elif [ "$height" -le 1080 ]; then font=14
    elif [ "$height" -le 1440 ]; then font=16
    elif [ "$height" -le 1600 ]; then font=18
    else font=20
    fi

    WINDOW_SIZE="${window_width}x${window_height}"
    FONT_SIZE="$font"
    ZHOUKEER_FONT_SIZE="$font"
    export ZHOUKEER_FONT_SIZE
}

adapt_window_size

if [ ! -r "$MAIN_PROGRAM" ] && [ ! -r "$PROJECT_ROOT/update.sh" ]; then
    show_launch_error "Renkit启动失败" \
        "安装可能不完整，未找到主程序：
$MAIN_PROGRAM

启动日志：$LAUNCH_LOG" || true
    exit 1
fi

case "$STARTUP_VIEW" in
    main)
        RUN_COMMAND=(env ZHOUKEER_SKIP_DISCLAIMER=1 ZHOUKEER_SKIP_STARTUP_UPDATE=1 \
            ZHOUKEER_STARTUP_SPLASH=0 bash "$PROJECT_ROOT/launch.sh" --run-main)
        FALLBACK_RUN_COMMAND=("${RUN_COMMAND[@]}")
        ;;
    *)
        RUN_COMMAND=(env ZHOUKEER_STARTUP_SPLASH=0 \
            bash "$PROJECT_ROOT/launch.sh" --run-main)
        FALLBACK_RUN_COMMAND=("${RUN_COMMAND[@]}")
        ;;
esac
KONSOLE_HELP=""

supports_konsole_option() {
    printf '%s\n' "$KONSOLE_HELP" | grep -q -- "$1"
}

try_terminal() {
    local label="$1"
    shift

    launcher_log "尝试启动：${label}；命令=$1"
    "$@" 2> >(filter_terminal_stderr)
    local status=$?
    if [ "$status" -eq 0 ]; then
        launcher_log "启动命令已接受：$label"
        return 0
    fi

    launcher_log "启动失败：${label}；状态码=$status"
    return "$status"
}

find_toolbox_konsole() {
    if [ -x "$HOME/.local/bin/zhoukeer-konsole" ]; then
        printf '%s\n' "$HOME/.local/bin/zhoukeer-konsole"
        return 0
    fi
    if command -v konsole >/dev/null 2>&1; then
        command -v konsole
        return 0
    fi
    return 1
}

try_konsole_levels() {
    local optional_args=()
    local window_mode="默认尺寸"
    local konsole_bin

    konsole_bin="$(find_toolbox_konsole)" || return 1
    KONSOLE_HELP="$("$konsole_bin" --help 2>/dev/null || true)"

    # 默认使用普通窗口，字号与窗口尺寸按检测到的屏幕分辨率适配；
    # 需要全屏时由维护者通过 ZHOUKEER_WINDOW_FULLSCREEN=1 显式开启。
    if [ "$WINDOW_FULLSCREEN" = "1" ] && supports_konsole_option '--fullscreen'; then
        optional_args+=(--fullscreen)
        window_mode="全屏（字号按分辨率适配）"
    fi
    if supports_konsole_option '--geometry'; then
        optional_args+=(--geometry "$WINDOW_SIZE")
        [ "$window_mode" = "默认尺寸" ] && window_mode="窗口 $WINDOW_SIZE"
    fi
    if supports_konsole_option '--workdir'; then
        optional_args+=(--workdir "$PROJECT_ROOT")
    fi

    if [ -f "$PROFILE_FILE" ] && supports_konsole_option '--profile'; then
        if try_terminal "Konsole 完整主题（${window_mode}）" \
            "$konsole_bin" "${optional_args[@]}" --profile "$PROFILE_FILE" \
            -e "${RUN_COMMAND[@]}"; then
            return 0
        fi
    fi

    if [ "${#optional_args[@]}" -gt 0 ]; then
        if try_terminal "Konsole 兼容模式（${window_mode}）" \
            "$konsole_bin" "${optional_args[@]}" -e "${FALLBACK_RUN_COMMAND[@]}"; then
            return 0
        fi
    fi

    try_terminal "Konsole 最小参数模式" "$konsole_bin" -e "${FALLBACK_RUN_COMMAND[@]}"
}

try_fallback_terminals() {
    if command -v ptyxis >/dev/null 2>&1 && \
        try_terminal "Ptyxis" ptyxis --standalone \
            --working-directory="$PROJECT_ROOT" -- "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v kgx >/dev/null 2>&1 && \
        try_terminal "GNOME Console" kgx \
            --working-directory="$PROJECT_ROOT" -- "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v gnome-terminal >/dev/null 2>&1 && \
        try_terminal "GNOME Terminal" gnome-terminal \
            --working-directory="$PROJECT_ROOT" -- "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v x-terminal-emulator >/dev/null 2>&1 && \
        try_terminal "系统默认终端" x-terminal-emulator -e "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v qterminal >/dev/null 2>&1 && \
        try_terminal "QTerminal" qterminal --workdir "$PROJECT_ROOT" \
            -e "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v kitty >/dev/null 2>&1 && \
        try_terminal "Kitty" kitty --directory "$PROJECT_ROOT" "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v alacritty >/dev/null 2>&1 && \
        try_terminal "Alacritty" alacritty --working-directory "$PROJECT_ROOT" \
            -e "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    if command -v xterm >/dev/null 2>&1 && \
        try_terminal "XTerm" xterm -e "${FALLBACK_RUN_COMMAND[@]}"; then
        return 0
    fi
    return 1
}

if try_konsole_levels; then
    exit 0
fi

launcher_log "Konsole 各级启动均不可用，尝试备用终端"
if try_fallback_terminals; then
    exit 0
fi

if [ -t 0 ] && [ -t 1 ]; then
    launcher_log "图形终端均不可用，使用当前终端直接启动"
    run_main
    exit $?
fi

show_launch_error "Renkit启动失败" \
    "未能启动 Konsole 或其他兼容终端。
请检查终端程序是否完整，或在 Konsole 中运行：
bash \"$MAIN_PROGRAM\"

启动日志：$LAUNCH_LOG" || true
exit 1
