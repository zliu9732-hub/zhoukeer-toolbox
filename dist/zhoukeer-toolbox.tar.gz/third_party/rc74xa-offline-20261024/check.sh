#!/bin/sh
set -eu
exec sh "$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)/install.sh" check
