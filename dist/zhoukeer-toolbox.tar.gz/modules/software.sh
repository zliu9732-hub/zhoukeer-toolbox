#!/bin/bash

# shellcheck disable=SC1091
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../core/env.sh"
# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/platform.sh"
# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/logger.sh"

FLATHUB_CN_REMOTE="flathub-cn"
FLATHUB_CN_FALLBACK_REMOTE="flathub-ustc"
FLATHUB_CN_URL="${ZHOUKEER_FLATHUB_CN_URL:-https://mirror.sjtu.edu.cn/flathub}"
FLATHUB_CN_FALLBACK_URL="${ZHOUKEER_FLATHUB_CN_FALLBACK_URL:-https://mirrors.ustc.edu.cn/flathub}"
FLATHUB_REPO_FILE_PRIMARY="https://mirror.sjtu.edu.cn/flathub/flathub.flatpakrepo"
FLATPAK_INSTALL_TIMEOUT="${ZHOUKEER_FLATPAK_INSTALL_TIMEOUT:-300}"
FLATPAK_INSTALL_RETRIES="${ZHOUKEER_FLATPAK_INSTALL_RETRIES:-1}"
FLATPAK_SOURCE_PROBE_TIMEOUT="${ZHOUKEER_FLATPAK_SOURCE_PROBE_TIMEOUT:-8}"
INSTALL_PRIMARY_REMOTE="$FLATHUB_CN_REMOTE"
INSTALL_FALLBACK_REMOTE="$FLATHUB_CN_FALLBACK_REMOTE"

QQ_CONFIG_PRIMARY="https://qq-web.cdn-go.cn/im.qq.com_new/latest/rainbow/pcConfig.json"
QQ_CONFIG_FALLBACK="https://im.qq.com/proxy/domain/qq-web.cdn-go.cn/im.qq.com_new/latest/rainbow/pcConfig.json"
QQ_APPIMAGE_PATH="${ZHOUKEER_QQ_APPIMAGE_PATH:-$APP_DIR/QQ.AppImage}"
QQ_DOWNLOAD_TIMEOUT="${ZHOUKEER_QQ_DOWNLOAD_TIMEOUT:-600}"
QQ_MIN_BYTES="${ZHOUKEER_QQ_MIN_BYTES:-52428800}"

software_details() {
    SOFTWARE_INSTALL_MODE="flatpak"
    case "$1" in
        wechat)
            SOFTWARE_NAME="微信"
            SOFTWARE_DESKTOP_NAME="微信"
            SOFTWARE_APP_ID="com.tencent.WeChat"
            SOFTWARE_CATEGORIES="Network;InstantMessaging;"
            ;;
        qq)
            SOFTWARE_NAME="QQ"
            SOFTWARE_DESKTOP_NAME="QQ"
            SOFTWARE_APP_ID=""
            SOFTWARE_INSTALL_MODE="appimage"
            SOFTWARE_CATEGORIES="Network;InstantMessaging;"
            ;;
        browser)
            SOFTWARE_NAME="Chromium浏览器"
            SOFTWARE_DESKTOP_NAME="Chromium浏览器"
            SOFTWARE_APP_ID="org.chromium.Chromium"
            SOFTWARE_CATEGORIES="Network;WebBrowser;"
            ;;
        rustdesk)
            SOFTWARE_NAME="RustDesk"
            SOFTWARE_DESKTOP_NAME="RustDesk"
            SOFTWARE_APP_ID="com.rustdesk.RustDesk"
            SOFTWARE_CATEGORIES="Network;RemoteAccess;"
            ;;
        anydesk)
            SOFTWARE_NAME="AnyDesk"
            SOFTWARE_DESKTOP_NAME="AnyDesk"
            SOFTWARE_APP_ID="com.anydesk.Anydesk"
            SOFTWARE_CATEGORIES="Network;RemoteAccess;"
            ;;
        *)
            echo "未知软件: $1"
            return 1
            ;;
    esac
}

confirm_software_install() {
    local answer

    if [ "$SOFTWARE_INSTALL_MODE" = "appimage" ]; then
        echo "将从腾讯QQ官网国内CDN下载官方AppImage：$SOFTWARE_NAME"
        echo "安装位置：$QQ_APPIMAGE_PATH"
        echo "下载最长等待 $QQ_DOWNLOAD_TIMEOUT 秒，失败后会保留旧版本。"
    else
        echo "将通过Flatpak以当前用户身份安装：$SOFTWARE_NAME"
        echo "应用ID：$SOFTWARE_APP_ID"
        echo "下载顺序：上海交大Flathub缓存 → 中科大Flathub缓存"
        echo "每个来源最长等待 $FLATPAK_INSTALL_TIMEOUT 秒，不再自动连接Flathub官方源。"
    fi
    case "$SOFTWARE_APP_ID" in
        com.tencent.WeChat)
            echo "注意：Flathub页面将该应用标记为非腾讯官方验证的社区封装。"
            ;;
        com.anydesk.Anydesk)
            echo "注意：AnyDesk 的 Flathub 包由社区维护；首次启动请按软件提示授权。"
            ;;
    esac

    if [ "${ZHOUKEER_AUTO_CONFIRM:-0}" = "1" ]; then
        return 0
    fi

    read -r -p "是否继续？[y/N] " answer
    case "$answer" in
        y|Y|yes|YES) return 0 ;;
        *) return 1 ;;
    esac
}

download_flathub_repo_file() {
    local destination="$1"

    echo "正在从上海交大镜像获取Flathub签名配置..."
    if curl \
        --fail \
        --location \
        --silent \
        --show-error \
        --proto '=https' \
        --proto-redir '=https' \
        --connect-timeout 10 \
        --max-time 30 \
        --retry 2 \
        --output "$destination" \
        "$FLATHUB_REPO_FILE_PRIMARY" && \
        grep -q '^\[Flatpak Repo\]$' "$destination" && \
        grep -q '^GPGKey=' "$destination"; then
        return 0
    fi

    rm -f -- "$destination"
    echo "无法获取Flathub签名配置。"
    return 1
}

flatpak_remote_exists() {
    flatpak remotes --user --columns=name 2>/dev/null | grep -Fxq "$1"
}

ensure_flatpak_remotes() {
    local repo_file=""

    if ! flatpak_remote_exists "$FLATHUB_CN_REMOTE" || \
        ! flatpak_remote_exists "$FLATHUB_CN_FALLBACK_REMOTE"; then
        repo_file="$(mktemp)" || return 1
        if ! download_flathub_repo_file "$repo_file"; then
            rm -f -- "$repo_file"
            return 1
        fi
    fi

    if ! flatpak_remote_exists "$FLATHUB_CN_REMOTE"; then
        echo "正在添加Flathub国内缓存源..."
        if ! flatpak remote-add --user --if-not-exists \
            "$FLATHUB_CN_REMOTE" "$repo_file"; then
            rm -f -- "$repo_file"
            return 1
        fi
    fi

    if ! flatpak remote-modify --user "$FLATHUB_CN_REMOTE" \
        --url="$FLATHUB_CN_URL"; then
        echo "无法配置上海交大Flathub缓存源。"
        rm -f -- "$repo_file"
        return 1
    fi

    if ! flatpak_remote_exists "$FLATHUB_CN_FALLBACK_REMOTE"; then
        echo "正在添加中科大Flathub缓存源..."
        if ! flatpak remote-add --user --if-not-exists \
            "$FLATHUB_CN_FALLBACK_REMOTE" "$repo_file"; then
            rm -f -- "$repo_file"
            return 1
        fi
    fi
    if ! flatpak remote-modify --user "$FLATHUB_CN_FALLBACK_REMOTE" \
        --url="$FLATHUB_CN_FALLBACK_URL"; then
        echo "无法配置中科大Flathub缓存源。"
        rm -f -- "$repo_file"
        return 1
    fi

    rm -f -- "$repo_file"
}

run_flatpak_install() {
    local remote="$1"
    local locale_name="C"
    local utf8_locale
    local attempt=1

    utf8_locale="$(locale -a 2>/dev/null | awk 'tolower($0) ~ /^c\.(utf-8|utf8)$/ { print; exit }')"
    if [ -n "$utf8_locale" ]; then
        locale_name="$utf8_locale"
    fi

    while [ "$attempt" -le "$FLATPAK_INSTALL_RETRIES" ]; do
        echo "正在从 $remote 安装（第 $attempt/$FLATPAK_INSTALL_RETRIES 次尝试）..."
        if LC_ALL="$locale_name" LANG="$locale_name" \
            timeout --foreground "$FLATPAK_INSTALL_TIMEOUT" \
            flatpak install --user --noninteractive -y "$remote" "$SOFTWARE_APP_ID"; then
            return 0
        fi
        attempt=$((attempt + 1))
    done
    return 1
}

measure_source_seconds() {
    local url="$1"
    local elapsed

    elapsed="$(curl --fail --location --silent --output /dev/null \
        --proto '=https' --proto-redir '=https' \
        --connect-timeout "$FLATPAK_SOURCE_PROBE_TIMEOUT" \
        --max-time "$FLATPAK_SOURCE_PROBE_TIMEOUT" \
        --write-out '%{time_total}' "$url" 2>/dev/null || true)"
    case "$elapsed" in
        ''|*[!0-9.]*|.*) return 1 ;;
        *) printf '%s\n' "$elapsed" ;;
    esac
}

choose_install_remotes() {
    local primary_seconds fallback_seconds

    INSTALL_PRIMARY_REMOTE="$FLATHUB_CN_REMOTE"
    INSTALL_FALLBACK_REMOTE="$FLATHUB_CN_FALLBACK_REMOTE"
    primary_seconds="$(measure_source_seconds "$FLATHUB_CN_URL/summary.idx" || true)"
    fallback_seconds="$(measure_source_seconds "$FLATHUB_CN_FALLBACK_URL/summary.idx" || true)"

    if [ -n "$primary_seconds" ] && [ -n "$fallback_seconds" ] && \
        awk "BEGIN { exit !($fallback_seconds < $primary_seconds) }"; then
        INSTALL_PRIMARY_REMOTE="$FLATHUB_CN_FALLBACK_REMOTE"
        INSTALL_FALLBACK_REMOTE="$FLATHUB_CN_REMOTE"
        echo "测速结果：优先使用中科大缓存（科大 ${fallback_seconds}s，交大 ${primary_seconds}s）。"
    elif [ -n "$primary_seconds" ]; then
        echo "测速结果：优先使用上海交大缓存（${primary_seconds}s）。"
    else
        echo "测速未完成，默认先尝试上海交大缓存。"
    fi
    log "$SOFTWARE_NAME 下载源顺序: $INSTALL_PRIMARY_REMOTE -> $INSTALL_FALLBACK_REMOTE"
}

file_size_bytes() {
    stat -c '%s' "$1" 2>/dev/null || stat -f '%z' "$1" 2>/dev/null
}

qq_appimage_is_valid() {
    local image_file="$1"
    local image_size magic

    [ -f "$image_file" ] || return 1
    image_size="$(file_size_bytes "$image_file" || true)"
    case "$image_size" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$image_size" -ge "$QQ_MIN_BYTES" ] || return 1

    magic="$(od -An -tx1 -N4 "$image_file" 2>/dev/null | tr -d '[:space:]')"
    [ "$magic" = "7f454c46" ]
}

resolve_qq_appimage_url() {
    local config_file config_url appimage_url

    config_file="$(mktemp)" || return 1
    for config_url in "$QQ_CONFIG_PRIMARY" "$QQ_CONFIG_FALLBACK"; do
        if curl \
            --fail \
            --location \
            --silent \
            --show-error \
            --proto '=https' \
            --proto-redir '=https' \
            --connect-timeout 10 \
            --max-time 30 \
            --retry 2 \
            --output "$config_file" \
            "$config_url"; then
            appimage_url="$(grep -o '"appimage"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | \
                head -n 1 | sed 's/^"appimage"[[:space:]]*:[[:space:]]*"//; s/"$//' || true)"
            case "$appimage_url" in
                https://qqdl.gtimg.cn/qqfile/*.AppImage)
                    rm -f -- "$config_file"
                    printf '%s\n' "$appimage_url"
                    return 0
                    ;;
            esac
        fi
    done

    rm -f -- "$config_file"
    return 1
}

install_official_qq_appimage() (
    local architecture appimage_url parent_dir temp_file backup_file

    architecture="$(uname -m)"
    case "$architecture" in
        x86_64|amd64) ;;
        *)
            echo "腾讯官网当前未提供适用于 $architecture 的QQ AppImage安装入口。"
            return 1
            ;;
    esac

    echo "正在向腾讯官网查询最新版QQ下载地址..."
    appimage_url="$(resolve_qq_appimage_url)" || {
        echo "未能从腾讯官网获取QQ下载地址，请稍后重试。"
        return 1
    }

    parent_dir="$(dirname "$QQ_APPIMAGE_PATH")"
    mkdir -p "$parent_dir" || return 1
    temp_file="$QQ_APPIMAGE_PATH.new.$$"
    backup_file="$QQ_APPIMAGE_PATH.backup.$$"

    cleanup_qq_download() {
        rm -f -- "$temp_file"
        if [ -f "$backup_file" ] && [ ! -e "$QQ_APPIMAGE_PATH" ]; then
            mv -- "$backup_file" "$QQ_APPIMAGE_PATH" 2>/dev/null || true
        else
            rm -f -- "$backup_file"
        fi
    }
    trap cleanup_qq_download EXIT INT TERM

    echo "正在从腾讯国内CDN下载QQ，最长等待 $QQ_DOWNLOAD_TIMEOUT 秒..."
    if ! curl \
        --fail \
        --location \
        --show-error \
        --progress-bar \
        --proto '=https' \
        --proto-redir '=https' \
        --connect-timeout 15 \
        --max-time "$QQ_DOWNLOAD_TIMEOUT" \
        --retry 2 \
        --retry-delay 2 \
        --retry-all-errors \
        --output "$temp_file" \
        "$appimage_url"; then
        echo "QQ下载失败或超时，已停止；原有版本未受影响。"
        return 1
    fi

    if ! qq_appimage_is_valid "$temp_file"; then
        echo "QQ下载文件不完整或格式不正确，已丢弃；原有版本未受影响。"
        return 1
    fi
    chmod 0755 "$temp_file" || return 1

    if [ -e "$QQ_APPIMAGE_PATH" ]; then
        mv -- "$QQ_APPIMAGE_PATH" "$backup_file" || return 1
    fi
    if ! mv -- "$temp_file" "$QQ_APPIMAGE_PATH"; then
        echo "QQ文件替换失败，正在恢复原有版本。"
        return 1
    fi
    rm -f -- "$backup_file"
    trap - EXIT INT TERM

    echo "QQ安装完成：$QQ_APPIMAGE_PATH"
    log "QQ官方AppImage安装完成: $QQ_APPIMAGE_PATH"
)

software_is_installed() {
    if [ "$SOFTWARE_INSTALL_MODE" = "appimage" ]; then
        qq_appimage_is_valid "$QQ_APPIMAGE_PATH"
    else
        command -v flatpak >/dev/null 2>&1 && \
            flatpak info "$SOFTWARE_APP_ID" >/dev/null 2>&1
    fi
}

create_software_shortcut() {
    local desktop_dir="$HOME/Desktop"
    local desktop_file="$desktop_dir/$SOFTWARE_DESKTOP_NAME.desktop"
    local exec_line icon_name

    if [ "$SOFTWARE_INSTALL_MODE" = "appimage" ]; then
        exec_line="\"$QQ_APPIMAGE_PATH\""
        icon_name="qq"
    else
        exec_line="flatpak run $SOFTWARE_APP_ID"
        icon_name="$SOFTWARE_APP_ID"
    fi

    mkdir -p "$desktop_dir" || return 1
    cat > "$desktop_file" <<EOF
[Desktop Entry]
Type=Application
Name=$SOFTWARE_NAME
Comment=由周克儿工具箱安装
Exec=$exec_line
Icon=$icon_name
Terminal=false
Categories=$SOFTWARE_CATEGORIES
EOF
    chmod +x "$desktop_file" || return 1

    echo "已创建桌面快捷方式：$desktop_file"
    log "$SOFTWARE_NAME 桌面快捷方式已创建: $desktop_file"
}

install_software() {
    local target="$1"

    software_details "$target" || return 1
    is_linux || {
        echo "$SOFTWARE_NAME 安装仅支持Linux/SteamOS。"
        return 1
    }
    require_command curl || return 1
    require_command od || return 1

    if software_is_installed; then
        echo "$SOFTWARE_NAME 已安装，正在检查桌面快捷方式。"
        create_software_shortcut
        return $?
    fi

    confirm_software_install || {
        echo "已取消安装 $SOFTWARE_NAME。"
        return 0
    }

    if [ "$SOFTWARE_INSTALL_MODE" = "appimage" ]; then
        install_official_qq_appimage || return 1
        create_software_shortcut
        return $?
    fi

    require_command flatpak || return 1
    require_command timeout || {
        echo "系统缺少限时运行组件，为避免安装无限卡住，已停止。"
        return 1
    }
    if ! ensure_flatpak_remotes; then
        echo "国内Flathub缓存源配置失败，已停止，不会转连官方源。"
        return 1
    fi

    choose_install_remotes
    echo "正在安装 $SOFTWARE_NAME..."
    if ! run_flatpak_install "$INSTALL_PRIMARY_REMOTE"; then
        echo "$INSTALL_PRIMARY_REMOTE 安装失败或超时，切换备用源 $INSTALL_FALLBACK_REMOTE。"
        if ! run_flatpak_install "$INSTALL_FALLBACK_REMOTE"; then
            echo "两个国内缓存均失败或超时，已停止，不再连接Flathub官方源。"
            log "$SOFTWARE_NAME Flatpak安装失败"
            return 1
        fi
    fi

    if ! software_is_installed; then
        echo "$SOFTWARE_NAME 安装命令结束，但未检测到已安装应用。"
        log "$SOFTWARE_NAME Flatpak安装结果验证失败"
        return 1
    fi

    echo "$SOFTWARE_NAME 安装完成。"
    log "$SOFTWARE_NAME Flatpak安装完成"
    create_software_shortcut
}

show_software_status() {
    local target
    local installed_count=0

    echo "常用软件与远程协助安装状态："
    for target in wechat qq browser rustdesk anydesk; do
        software_details "$target" || return 1
        if software_is_installed; then
            echo "✓ $SOFTWARE_NAME：已安装"
            installed_count=$((installed_count + 1))
        else
            echo "- $SOFTWARE_NAME：未安装"
        fi
    done
    echo "已安装：$installed_count / 5"
}

repair_software_shortcuts() {
    local target
    local repaired=0

    for target in wechat qq browser rustdesk anydesk; do
        software_details "$target" || return 1
        if software_is_installed; then
            create_software_shortcut || return 1
            repaired=$((repaired + 1))
        fi
    done
    echo "已修复 $repaired 个已安装应用的桌面图标。"
    log "已修复 $repaired 个应用桌面图标"
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    case "${1:-}" in
        wechat|qq|browser|rustdesk|anydesk) install_software "$1" ;;
        status) require_command od && show_software_status ;;
        repair-shortcuts) require_command od && repair_software_shortcuts ;;
        *) echo "用法: $0 {wechat|qq|browser|rustdesk|anydesk|status|repair-shortcuts}"; exit 1 ;;
    esac
fi
