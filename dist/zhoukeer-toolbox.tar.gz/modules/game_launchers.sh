#!/bin/bash

set -u

# shellcheck disable=SC1091
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../core/env.sh"
# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/platform.sh"
# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/logger.sh"

DOWNLOAD_TIMEOUT="${ZHOUKEER_LAUNCHER_DOWNLOAD_TIMEOUT:-600}"
POST_INSTALL_TIMEOUT="${ZHOUKEER_LAUNCHER_POST_INSTALL_TIMEOUT:-300}"
POST_INSTALL_INTERVAL="${ZHOUKEER_LAUNCHER_POST_INSTALL_INTERVAL:-5}"
STEAM_SHORTCUT_HELPER="$PROJECT_ROOT/scripts/steam_shortcut.py"
STEAM_COMPAT_HELPER="$PROJECT_ROOT/scripts/steam_compat.py"
PROTON_10_APP_ID="3658110"
PROTON_EXPERIMENTAL_APP_ID="1493710"
PROTON_INSTALL_TIMEOUT="${ZHOUKEER_PROTON_INSTALL_TIMEOUT:-900}"
PROTON_INSTALL_INTERVAL="${ZHOUKEER_PROTON_INSTALL_INTERVAL:-5}"
LAUNCHER_PREINSTALLED_BASE="${ZHOUKEER_LAUNCHER_PREINSTALLED_BASE:-https://gitee.com/easylife2025/battle/releases/download/v1.0.0}"
# Windows 虚拟 C 盘放在用户可见目录，避免隐藏目录导致战网插件、黑盒工坊等找不到游戏文件。
LAUNCHER_BASE="${ZHOUKEER_LAUNCHER_BASE:-$HOME/游戏启动器}"
LAUNCHER_COVER_MIRROR_ID="${ZHOUKEER_LAUNCHER_COVER_MIRROR_ID:-launcher-covers}"
LAUNCHER_COVER_BUNDLE_NAME="启动器封面素材"
LAUNCHER_COVER_CACHE_ROOT="${ZHOUKEER_LAUNCHER_COVER_CACHE_DIR:-$APP_DIR/game-launchers/covers}"
LAUNCHER_COVER_READY_MARKER="$LAUNCHER_COVER_CACHE_ROOT/.covers-ready-v8"

launcher_details() {
    case "$1" in
        epic)
            LAUNCHER_NAME="Epic Games 启动器"
            LAUNCHER_FILE_NAME="EpicGamesLauncherInstaller.msi"
            LAUNCHER_URL="https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/installer/download/EpicGamesLauncherInstaller.msi"
            LAUNCHER_FALLBACK_URL="https://epicgames-download1.akamaized.net/Builds/UnrealEngineLauncher/Installers/Windows/EpicInstaller-20.1.4.msi?launcherfilename=EpicInstaller-20.1.4.msi"
            LAUNCHER_FALLBACK_SHA256="1513d6cc2afda0367c8375b6f25f490c162da5607ce4b4adbb41906a2d742236"
            LAUNCHER_GITEE_MIRROR_ID="epic"
            LAUNCHER_GITEE_MIRROR_SHA256="1513d6cc2afda0367c8375b6f25f490c162da5607ce4b4adbb41906a2d742236"
            LAUNCHER_GITEE_MIRROR_URL="https://epicgames-download1.akamaized.net/Builds/UnrealEngineLauncher/Installers/Windows/EpicInstaller-20.1.4.msi"
            LAUNCHER_MIN_BYTES=52428800
            LAUNCHER_MAGIC="d0cf11e0"
            LAUNCHER_MAGIC_ALT="4d5a"
            LAUNCHER_TARGET_RELATIVES=$'Program Files (x86)/Epic Games/Launcher/Portal/Binaries/Win64/EpicGamesLauncher.exe\nProgram Files/Epic Games/Launcher/Portal/Binaries/Win64/EpicGamesLauncher.exe'
            ;;
        battlenet)
            LAUNCHER_NAME="战网启动器"
            LAUNCHER_FILE_NAME="Battle.net-Setup.exe"
            LAUNCHER_URL="https://downloader.battle.net/download/getInstallerForGame?os=win&installer=Battle.net-Setup.exe"
            LAUNCHER_FALLBACK_URL=""
            LAUNCHER_FALLBACK_SHA256=""
            LAUNCHER_PREINSTALLED=1
            LAUNCHER_PREINSTALLED_FILE="Battle.net.7z"
            LAUNCHER_PREINSTALLED_PARTS=4
            LAUNCHER_PREINSTALLED_TARGET_RELATIVE="Battle.net/Battle.net Launcher.exe"
            LAUNCHER_PREINSTALLED_BYTES=(94371840 94371840 94371840 32192646)
            LAUNCHER_PREINSTALLED_SHA256=(\
                61b8d62253f40ec599ab94c1e426c921377154c284f054e0f8854d9d0d99a12c \
                d6fd711531f29ccc4b73a318e22602f1d6bc0dc64bc71e9283139a1ed9aab99c \
                c7dc2e0129e345fdff6ddcce23e861e8c9826e33f1feb038213638356903b4c8 \
                174b546aa6c00f45b02b6eeea3e14820ba6908efb2ad46e2266bc449e315aacc)
            LAUNCHER_PREINSTALLED_ARCHIVE_SHA256="cedab076e12356eb0b61d47ad9479d66138fef3a3cec7c22d394e41a09413955"
            LAUNCHER_MIN_BYTES=1048576
            LAUNCHER_MAGIC="4d5a"
            LAUNCHER_TARGET_RELATIVES=$'Program Files (x86)/Battle.net/Battle.net Launcher.exe\nProgram Files (x86)/Battle.net/Battle.net.exe'
            ;;
        ubisoft|uplay)
            LAUNCHER_NAME="育碧"
            LAUNCHER_FILE_NAME="UbisoftConnectInstaller.exe"
            LAUNCHER_URL="https://static3.cdn.ubi.com/orbit/launcher_installer/UbisoftConnectInstaller.exe"
            LAUNCHER_FALLBACK_URL=""
            LAUNCHER_FALLBACK_SHA256=""
            LAUNCHER_MIN_BYTES=10485760
            LAUNCHER_MAGIC="4d5a"
            LAUNCHER_TARGET_RELATIVES=$'Program Files (x86)/Ubisoft/Ubisoft Game Launcher/UbisoftConnect.exe\nProgram Files (x86)/Ubisoft/Ubisoft Game Launcher/upc.exe'
            ;;
        heihe)
            LAUNCHER_NAME="黑盒工坊"
            LAUNCHER_FILE_NAME="wow_installer_1.9.51.0.exe"
            LAUNCHER_URL=""
            LAUNCHER_FALLBACK_URL=""
            LAUNCHER_FALLBACK_SHA256=""
            LAUNCHER_GITEE_MIRROR_ID="heihe"
            LAUNCHER_GITEE_MIRROR_SHA256="9e0bce560d8264eb015a020337167f57918babd755d1671c38a49f3cdb05654a"
            LAUNCHER_GITEE_MIRROR_URL="https://gitee.com/zliu9732-hub/zhoukeer-toolbox-mirror/raw/main/heihe/1.9.51.0/wow_installer_1.9.51.0.exe"
            LAUNCHER_PREINSTALLED=1
            LAUNCHER_PREINSTALLED_MIRROR_ID="heihe-preinstalled"
            LAUNCHER_PREINSTALLED_FILE="heyboxwow.7z"
            LAUNCHER_PREINSTALLED_TARGET_RELATIVE="Qingfeng/HeyboxWow/heyboxwow.exe"
            LAUNCHER_PREINSTALLED_ARCHIVE_SHA256="8ef819da7291a7448ca346cc0e058bcf15b7da33dcec9a237b627a08331ede70"
            LAUNCHER_MIN_BYTES=10485760
            LAUNCHER_MAGIC="4d5a"
            LAUNCHER_TARGET_RELATIVES=$'Program Files (x86)/Qingfeng/HeyboxWow/heyboxwow.exe\nProgram Files (x86)/Qingfeng/HeyboxWow/HeyboxWow.exe\nProgram Files/Qingfeng/HeyboxWow/heyboxwow.exe\nProgram Files/Qingfeng/HeyboxWow/HeyboxWow.exe\nProgram Files (x86)/HeyboxWow/heyboxwow.exe\nProgram Files (x86)/HeyboxWow/HeyboxWow.exe\nProgram Files/HeyboxWow/heyboxwow.exe\nProgram Files/HeyboxWow/HeyboxWow.exe\nAppData/Local/Programs/Qingfeng/HeyboxWow/heyboxwow.exe\nAppData/Local/Programs/Qingfeng/HeyboxWow/HeyboxWow.exe\nAppData/Local/Programs/HeyboxWow/heyboxwow.exe\nAppData/Local/Programs/HeyboxWow/HeyboxWow.exe\nProgram Files (x86)/黑盒工坊/黑盒工坊.exe\nProgram Files (x86)/HeiHe/HeiHe.exe'
            ;;
        hmcl)
            LAUNCHER_NAME="HMCL 启动器"
            LAUNCHER_FILE_NAME="HMCL.jar"
            LAUNCHER_URL="https://github.com/HMCL-dev/HMCL/releases/download/v3.16.3/HMCL-3.16.3.jar"
            LAUNCHER_SHA256="5d02f4d04d9442116354ecfccf679910cca371d00a23cd5d6b16558c20a73dd3"
            LAUNCHER_MIN_BYTES=10000000
            LAUNCHER_MAGIC="504b0304"
            LAUNCHER_TARGET_RELATIVES=$'HMCL.jar'
            LAUNCHER_HMCL_JAVA_URL="${ZHOUKEER_HMCL_JAVA_URL:-https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.12%2B8/OpenJDK21U-jre_x64_linux_hotspot_21.0.12_8.tar.gz}"
            LAUNCHER_HMCL_JAVA_SHA256="${ZHOUKEER_HMCL_JAVA_SHA256:-8a379a67c91a3ae61ffb33d46e0a40c7ba35e70713c4db31cfca30492f792eff}"
            LAUNCHER_HMCL_JAVA_MIN_BYTES=40000000
            LAUNCHER_HMCL_JAVA_MAGIC="1f8b"
            ;;
        *)
            echo "未知启动器: $1"
            return 1
            ;;
    esac
}

verify_installer() {
    local file="$1"
    local size magic magic_ok

    size="$(wc -c < "$file" | tr -d ' ')"
    magic="$(od -An -tx1 -N4 "$file" | tr -d ' \n')"
    if [ "${size:-0}" -lt "$LAUNCHER_MIN_BYTES" ]; then
        echo "下载文件过小，已保留原有安装包。"
        return 1
    fi
    magic_ok=0
    case "$magic" in
        "$LAUNCHER_MAGIC"*) magic_ok=1 ;;
    esac
    if [ -n "${LAUNCHER_MAGIC_ALT:-}" ]; then
        case "$magic" in
            "$LAUNCHER_MAGIC_ALT"*) magic_ok=1 ;;
        esac
    fi
    if [ "$magic_ok" -ne 1 ]; then
        echo "下载文件格式不正确，已保留原有安装包。"
        return 1
    fi
}

hmcl_artifact_valid() {
    local file="$1" min_bytes="$2" magic_prefix="$3" size magic

    [ -f "$file" ] && [ ! -L "$file" ] || return 1
    size="$(wc -c < "$file" | tr -d ' ')"
    case "$size" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$size" -ge "$min_bytes" ] || return 1
    magic="$(od -An -tx1 -N4 "$file" 2>/dev/null | tr -d ' \n')"
    case "$magic" in
        "$magic_prefix"*) return 0 ;;
        *) return 1 ;;
    esac
}

download_hmcl_artifact() {
    local url="$1" expected_sha="$2" output="$3" min_bytes="$4" magic_prefix="$5" name="$6"
    local temporary="$output.new.$$"

    require_command curl || return 1
    download_policy_url_allowed "$url" || {
        echo "$name 下载地址不在受控来源清单中。"
        return 1
    }
    rm -f -- "$temporary"
    echo "正在下载 $name..."
    if ! curl --fail --location --progress-meter --proto '=https' --proto-redir '=https' \
        --connect-timeout 15 --max-time "$DOWNLOAD_TIMEOUT" --retry 3 --retry-delay 2 \
        --retry-connrefused --retry-all-errors --speed-limit 65536 --speed-time 60 \
        --max-filesize "$(download_policy_max_bytes "$url")" \
        --user-agent 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36' \
        --compressed --output "$temporary" "$url" \
        2> >(download_progress_filter "$name" >&2); then
        rm -f -- "$temporary"
        echo "$name 下载失败，旧版本保持不变。"
        return 1
    fi
    if ! download_policy_response_is_safe "$url" "$temporary" || \
        ! hmcl_artifact_valid "$temporary" "$min_bytes" "$magic_prefix" || \
        [ "$(launcher_file_sha256 "$temporary")" != "$expected_sha" ]; then
        rm -f -- "$temporary"
        echo "$name 下载响应格式或 SHA256 校验失败。"
        return 1
    fi
    mv -f -- "$temporary" "$output" || return 1
}

launcher_file_sha256() {
    local file="$1"

    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum -- "$file" | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then
        shasum -a 256 -- "$file" | awk '{print $1}'
    else
        return 1
    fi
}

download_launcher_installer() {
    local output="$1"
    local temporary="$output.new.$$"
    local attempt
    local -a curl_options

    require_command curl || return 1
    if [ -n "${LAUNCHER_GITEE_MIRROR_ID:-}" ] && [ -n "${LAUNCHER_GITEE_MIRROR_SHA256:-}" ]; then
        rm -f -- "$temporary"
        if download_gitee_mirror_file "$LAUNCHER_GITEE_MIRROR_ID" "$temporary" \
            "$LAUNCHER_GITEE_MIRROR_SHA256" "$LAUNCHER_NAME" && \
            verify_installer "$temporary" >/dev/null 2>&1; then
            mv -f -- "$temporary" "$output" || return 1
            return 0
        fi
        rm -f -- "$temporary"
        echo "$LAUNCHER_NAME 镜像下载失败，切换官方源。"
    fi
    download_policy_url_allowed "$LAUNCHER_URL" || {
        echo "$LAUNCHER_NAME 下载地址不在受控来源清单中。"
        return 1
    }
    for attempt in 1 2 3; do
        rm -f -- "$temporary"
        echo "正在下载 $LAUNCHER_NAME 官方安装器…"
        curl_options=(
            --fail --location --progress-meter
            --proto '=https' --proto-redir '=https'
            --connect-timeout 15 --max-time "$DOWNLOAD_TIMEOUT"
            --retry 3 --retry-delay 2 --retry-connrefused --retry-all-errors
            --speed-limit 65536 --speed-time 60
            --max-filesize "$(download_policy_max_bytes "$LAUNCHER_URL")"
            --user-agent 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36'
            --compressed
        )
        if [ "$attempt" -eq 2 ]; then
            curl_options+=(--http1.1)
        fi
        if curl "${curl_options[@]}" --output "$temporary" "$LAUNCHER_URL" \
            2> >(download_progress_filter "$LAUNCHER_NAME" >&2); then
            if download_policy_response_is_safe "$LAUNCHER_URL" "$temporary" && \
                verify_installer "$temporary" >/dev/null 2>&1; then
                mv -f -- "$temporary" "$output" || return 1
                return 0
            fi
        fi
        rm -f -- "$temporary"
        [ "$attempt" -eq 1 ] && echo "$LAUNCHER_NAME 下载响应异常，正在使用备用请求方式重试..."
    done
    if [ -n "${LAUNCHER_FALLBACK_URL:-}" ] && [ -n "${LAUNCHER_FALLBACK_SHA256:-}" ]; then
        rm -f -- "$temporary"
        echo "正在从 $LAUNCHER_NAME 官方 CDN 备用线路下载…"
        if download_policy_url_allowed "$LAUNCHER_FALLBACK_URL" && \
            curl --fail --location --progress-meter --proto '=https' --proto-redir '=https' \
                --connect-timeout 15 --max-time "$DOWNLOAD_TIMEOUT" --retry 2 --retry-delay 2 \
                --speed-limit 65536 --speed-time 60 \
                --max-filesize "$(download_policy_max_bytes "$LAUNCHER_FALLBACK_URL")" \
                --user-agent 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36' \
                --compressed --http1.1 \
                --output "$temporary" "$LAUNCHER_FALLBACK_URL" \
                2> >(download_progress_filter "$LAUNCHER_NAME" >&2) && \
            download_policy_response_is_safe "$LAUNCHER_FALLBACK_URL" "$temporary" && \
            verify_installer "$temporary" >/dev/null 2>&1 && \
            [ "$(launcher_file_sha256 "$temporary")" = "$LAUNCHER_FALLBACK_SHA256" ]; then
            mv -f -- "$temporary" "$output" || return 1
            return 0
        fi
        rm -f -- "$temporary"
    fi
    echo "$LAUNCHER_NAME 下载响应格式或大小异常。"
    return 1
}

download_preinstalled_launcher_parts() {
    local workdir="$1"
    local index part_url part_file expected_size expected_sha actual_size actual_sha magic
    local -a curl_options

    [ "$LAUNCHER_PREINSTALLED_PARTS" -gt 0 ] || {
        echo "$LAUNCHER_NAME 客户端分卷配置无效。"
        return 1
    }
    mkdir -p "$workdir" || return 1
    echo "正在下载 $LAUNCHER_NAME 预装客户端..."
    for index in $(seq 1 "$LAUNCHER_PREINSTALLED_PARTS"); do
        part_url="$LAUNCHER_PREINSTALLED_BASE/$LAUNCHER_PREINSTALLED_FILE.$(printf '%03d' "$index")"
        part_file="$workdir/$LAUNCHER_PREINSTALLED_FILE.$(printf '%03d' "$index")"
        expected_size="${LAUNCHER_PREINSTALLED_BYTES[$((index - 1))]}"
        expected_sha="${LAUNCHER_PREINSTALLED_SHA256[$((index - 1))]}"
        download_policy_url_allowed "$part_url" || {
            echo "$LAUNCHER_NAME 下载地址不在受控来源清单中。"
            return 1
        }
        curl_options=(
            --fail --location --progress-meter
            --proto '=https' --proto-redir '=https'
            --connect-timeout 15 --max-time "$DOWNLOAD_TIMEOUT"
            --retry 3 --retry-delay 2 --retry-connrefused --retry-all-errors
            --speed-limit 65536 --speed-time 60
            --max-filesize "$(download_policy_max_bytes "$part_url")"
        )
        if ! curl "${curl_options[@]}" --output "$part_file" "$part_url" \
            2> >(download_progress_filter "$LAUNCHER_NAME 预装客户端" >&2); then
            echo "$LAUNCHER_NAME 客户端下载失败，已保留已下载分卷。"
            return 1
        fi
        download_policy_response_is_safe "$part_url" "$part_file" || {
            echo "$LAUNCHER_NAME 客户端响应异常，已保留已下载分卷。"
            return 1
        }
        actual_size="$(wc -c < "$part_file" | tr -d ' ')"
        [ "$actual_size" = "$expected_size" ] || {
            echo "$LAUNCHER_NAME 客户端分卷大小校验失败：${LAUNCHER_PREINSTALLED_FILE}.$(printf '%03d' "$index")"
            return 1
        }
        if [ "$index" -eq 1 ]; then
            magic="$(od -An -tx1 -N6 "$part_file" | tr -d ' \n')"
            [ "$magic" = "377abcaf271c" ] || {
                echo "$LAUNCHER_NAME 客户端分卷格式校验失败：${LAUNCHER_PREINSTALLED_FILE}.001"
                return 1
            }
        fi
        actual_sha="$(launcher_file_sha256 "$part_file")" || {
            echo "无法计算 $LAUNCHER_NAME 客户端分卷校验值。"
            return 1
        }
        [ "$actual_sha" = "$expected_sha" ] || {
            echo "$LAUNCHER_NAME 客户端分卷 SHA256 校验失败：${LAUNCHER_PREINSTALLED_FILE}.$(printf '%03d' "$index")"
            return 1
        }
    done
    echo "正在重组 $LAUNCHER_NAME 客户端文件..."
    : > "$workdir/$LAUNCHER_PREINSTALLED_FILE"
    for index in $(seq 1 "$LAUNCHER_PREINSTALLED_PARTS"); do
        cat -- "$workdir/$LAUNCHER_PREINSTALLED_FILE.$(printf '%03d' "$index")" \
            >> "$workdir/$LAUNCHER_PREINSTALLED_FILE" || return 1
    done
    [ "$(launcher_file_sha256 "$workdir/$LAUNCHER_PREINSTALLED_FILE")" = "$LAUNCHER_PREINSTALLED_ARCHIVE_SHA256" ] || {
        echo "$LAUNCHER_NAME 客户端重组后校验失败。"
        return 1
    }
    echo "$LAUNCHER_NAME 预装客户端下载完成。"
}

download_preinstalled_launcher() {
    local workdir="$1"

    mkdir -p "$workdir" || return 1
    if [ -n "${LAUNCHER_PREINSTALLED_MIRROR_ID:-}" ]; then
        download_gitee_mirror_file "$LAUNCHER_PREINSTALLED_MIRROR_ID" \
            "$workdir/$LAUNCHER_PREINSTALLED_FILE" \
            "$LAUNCHER_PREINSTALLED_ARCHIVE_SHA256" "$LAUNCHER_NAME"
        return
    fi
    download_preinstalled_launcher_parts "$workdir"
}

extract_preinstalled_launcher() {
    local archive="$1" drive_c="$2"
    local target_dir target_exe staged_exe list_file extract_dir entry

    require_command bsdtar || return 1
    list_file="$(mktemp)" || return 1
    if ! LC_ALL=C bsdtar -tf "$archive" < /dev/null > "$list_file" 2>/dev/null; then
        rm -f -- "$list_file"
        echo "$LAUNCHER_NAME 客户端压缩包无法读取，可能已损坏。"
        return 1
    fi
    if LC_ALL=C grep -Eq '[[:cntrl:]\\]|^/|^[A-Za-z]:' "$list_file"; then
        rm -f -- "$list_file"
        echo "$LAUNCHER_NAME 客户端压缩包路径不安全，已停止安装。"
        return 1
    fi
    while IFS= read -r entry; do
        case "$entry" in
            '..'|'../'*|*/'..'|*/'../'*)
                rm -f -- "$list_file"
                echo "$LAUNCHER_NAME 客户端压缩包路径越界，已停止安装。"
                return 1
                ;;
        esac
    done < "$list_file"
    rm -f -- "$list_file"
    extract_dir="$(mktemp -d)" || return 1
    if ! bsdtar --no-same-owner --no-same-permissions --no-acls --no-xattrs \
        --no-fflags -xf "$archive" -C "$extract_dir" < /dev/null; then
        rm -rf -- "$extract_dir"
        echo "$LAUNCHER_NAME 客户端解压失败，已停止安装。"
        return 1
    fi
    staged_exe="$extract_dir/$LAUNCHER_PREINSTALLED_TARGET_RELATIVE"
    [ -f "$staged_exe" ] && [ ! -L "$staged_exe" ] || {
        rm -rf -- "$extract_dir"
        echo "解压后未找到 $LAUNCHER_NAME 主程序。"
        return 1
    }
    if find "$extract_dir" -type l -print -quit 2>/dev/null | grep -q .; then
        rm -rf -- "$extract_dir"
        echo "$LAUNCHER_NAME 客户端解压产物包含异常链接，已停止安装。"
        return 1
    fi
    target_dir="$drive_c/Program Files (x86)"
    mkdir -p "$target_dir" || {
        rm -rf -- "$extract_dir"
        return 1
    }
    if ! cp -Rp "$extract_dir/." "$target_dir/"; then
        rm -rf -- "$extract_dir"
        echo "$LAUNCHER_NAME 客户端文件写入失败，已停止安装。"
        return 1
    fi
    rm -rf -- "$extract_dir"
    target_exe="$target_dir/$LAUNCHER_PREINSTALLED_TARGET_RELATIVE"
    [ -f "$target_exe" ] && [ ! -L "$target_exe" ] || {
        echo "写入后未找到 $LAUNCHER_NAME 主程序。"
        return 1
    }
    return 0
}

prepare_launcher_shared_prefix() {
    local target="$1" drive_c="$2"
    local prefix_dir="$APP_DIR/game-launchers/$target/compatdata"

    mkdir -p "$prefix_dir/pfx" || return 1
    if [ -L "$prefix_dir/pfx/drive_c" ]; then
        if [ "$(readlink "$prefix_dir/pfx/drive_c")" = "$drive_c" ]; then
            printf '%s\n' "$prefix_dir"
            return 0
        fi
        rm -f -- "$prefix_dir/pfx/drive_c" || return 1
    elif [ -e "$prefix_dir/pfx/drive_c" ]; then
        rm -rf -- "$prefix_dir/pfx/drive_c" || return 1
    fi
    ln -s -- "$drive_c" "$prefix_dir/pfx/drive_c" || return 1
    printf '%s\n' "$prefix_dir"
}

launcher_drive_c() {
    local target="$1"

    printf '%s/%s/drive_c\n' "$LAUNCHER_BASE" "$target"
}

link_steam_compatdata_drive() {
    local steam_root="$1" app_id="$2" prefix_dir="$3"
    local drive_c compat_pfx backup

    case "$app_id" in
        ''|*[!0-9]*) echo "Steam 兼容层编号无效。"; return 1 ;;
    esac
    drive_c="$prefix_dir/pfx/drive_c"
    [ -d "$drive_c" ] || return 0
    compat_pfx="$steam_root/steamapps/compatdata/$app_id/pfx"
    mkdir -p "$compat_pfx" || return 1
    if [ -L "$compat_pfx/drive_c" ]; then
        [ "$(readlink "$compat_pfx/drive_c")" = "$drive_c" ] || {
            echo "Steam 兼容层已有其他 drive_c 链接，已停止覆盖。"
            return 1
        }
        return 0
    fi
    if [ -e "$compat_pfx/drive_c" ]; then
        backup="$compat_pfx/.zhoukeer-drive-c-backup"
        [ ! -e "$backup" ] || {
            echo "Steam 兼容层已有旧目录备份，请先检查后重试。"
            return 1
        }
        mv -- "$compat_pfx/drive_c" "$backup" || return 1
    fi
    ln -s -- "$drive_c" "$compat_pfx/drive_c" || return 1
}

set_launcher_grid_icon() {
    local shortcut_file="$1" name="$2" exe="$3" grid_dir="$4"
    shift 4
    local candidate icon=""

    for candidate in "$@"; do
        if [ -f "$grid_dir/${candidate}_icon.png" ]; then
            icon="$grid_dir/${candidate}_icon.png"
            break
        fi
    done
    [ -n "$icon" ] || return 0
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" set-icon \
        --name "$name" --exe "$exe" --icon "$icon" >/dev/null || return 1
    printf '%s\n' "$icon"
}

migrate_launcher_drive_to_visible() {
    local target="$1" prefix_dir="$2"
    local drive_c real_drive new_drive new_parent

    drive_c="$prefix_dir/pfx/drive_c"
    if [ -L "$drive_c" ]; then
        real_drive="$(readlink "$drive_c")"
    elif [ -d "$drive_c" ]; then
        real_drive="$drive_c"
    else
        return 0
    fi
    new_drive="$(launcher_drive_c "$target")"
    [ "$real_drive" = "$new_drive" ] && return 0
    case "$real_drive" in
        "$APP_DIR"/*) ;;
        *) return 0 ;;
    esac
    if [ -e "$new_drive" ] || [ -L "$new_drive" ]; then
        if [ -d "$new_drive" ] && [ ! -L "$new_drive" ] && \
            [ -z "$(ls -A "$new_drive" 2>/dev/null)" ]; then
            rmdir "$new_drive" || return 1
        else
            echo "$LAUNCHER_NAME 目标虚拟目录已存在，未迁移：$new_drive"
            return 1
        fi
    fi
    new_parent="$(dirname "$new_drive")"
    mkdir -p "$new_parent" || return 1
    mv -- "$real_drive" "$new_drive" || return 1
    prepare_launcher_shared_prefix "$target" "$new_drive" >/dev/null || return 1
    echo "已将 $LAUNCHER_NAME 虚拟目录迁移到 ${new_drive}。"
}

find_battle_platform_drive_c() {
    local steam_root="$1"
    local battle_drive_c candidate_dir

    battle_drive_c="$(launcher_drive_c battlenet)"
    if [ -d "$battle_drive_c" ] && [ ! -L "$battle_drive_c" ]; then
        printf '%s\n' "$battle_drive_c"
        return 0
    fi
    battle_drive_c="$APP_DIR/game-launchers/battlenet/drive_c"
    if [ -d "$battle_drive_c" ] && [ ! -L "$battle_drive_c" ]; then
        printf '%s\n' "$battle_drive_c"
        return 0
    fi
    for candidate_dir in "$steam_root/steamapps/compatdata"/*/; do
        [ -d "$candidate_dir" ] || continue
        candidate_dir="${candidate_dir%/}"
        if [ -f "$candidate_dir/pfx/drive_c/Program Files (x86)/Battle.net/Battle.net Launcher.exe" ]; then
            printf '%s\n' "$candidate_dir/pfx/drive_c"
            return 0
        fi
    done
    return 1
}

find_steam_root() {
    local candidate

    if [ -n "${ZHOUKEER_STEAM_ROOT:-}" ] && [ -d "$ZHOUKEER_STEAM_ROOT/steamapps" ]; then
        printf '%s\n' "$ZHOUKEER_STEAM_ROOT"
        return 0
    fi
    for candidate in "$HOME/.local/share/Steam" "$HOME/.steam/steam"; do
        if [ -d "$candidate/steamapps" ] && [ -d "$candidate/userdata" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done
    echo "未找到已初始化的 Steam 库。" >&2
    echo "请先在桌面模式打开 Steam 并完成登录，等待 Steam 库初始化完成（游戏列表能正常显示）后再运行本工具。" >&2
    echo "若 Steam 刚安装或从未登录，请先打开并登录一次，稍等片刻后再重试。" >&2
    return 1
}

find_shortcut_file() {
    local steam_root="$1"
    local loginusers_file steam_id account_id
    local candidate
    local newest=""
    local newest_time=0
    local modified

    if [ -n "${ZHOUKEER_SHORTCUT_FILE:-}" ]; then
        printf '%s\n' "$ZHOUKEER_SHORTCUT_FILE"
        return 0
    fi

    loginusers_file="$steam_root/config/loginusers.vdf"
    if [ -f "$loginusers_file" ] && [ ! -L "$loginusers_file" ]; then
        steam_id="$(awk '
            {
                value=$0
                gsub(/[[:space:]"]/, "", value)
                if (value ~ /^[0-9]+$/) {
                    current=value
                } else if (value == "MostRecent1" && current != "") {
                    print current
                    exit
                }
            }
        ' "$loginusers_file")"
        case "$steam_id" in
            ''|*[!0-9]*) ;;
            *)
                account_id=$((steam_id - 76561197960265728))
                if [ "$account_id" -gt 0 ] && [ -d "$steam_root/userdata/$account_id/config" ]; then
                    printf '%s/userdata/%s/config/shortcuts.vdf\n' "$steam_root" "$account_id"
                    return 0
                fi
                ;;
        esac
    fi

    # loginusers.vdf 不可用时，优先复用已有快捷方式文件，避免写进旧账号。
    while IFS= read -r -d '' candidate; do
        modified="$(stat -c '%Y' "$candidate" 2>/dev/null || printf '0')"
        if [ "$modified" -ge "$newest_time" ]; then
            newest="$candidate"
            newest_time="$modified"
        fi
    done < <(find "$steam_root/userdata" -mindepth 3 -maxdepth 3 -type f -name shortcuts.vdf -print0 2>/dev/null)
    if [ -n "$newest" ]; then
        printf '%s\n' "$newest"
        return 0
    fi

    newest=""
    newest_time=0
    while IFS= read -r -d '' candidate; do
        modified="$(stat -c '%Y' "$candidate" 2>/dev/null || printf '0')"
        if [ "$modified" -ge "$newest_time" ]; then
            newest="$candidate"
            newest_time="$modified"
        fi
    done < <(find "$steam_root/userdata" -mindepth 2 -maxdepth 2 -type d -name config -print0 2>/dev/null)

    if [ -z "$newest" ]; then
        echo "未找到 Steam 当前账号的 userdata/config，无法确定入库位置。" >&2
        echo "请先在桌面模式打开 Steam 并完成登录，等待 Steam 库初始化完成（游戏列表能正常显示）后再运行。" >&2
        echo "若 Steam 正在运行但还没有生成用户目录，请先完全退出 Steam，再重新打开并登录一次。" >&2
        return 1
    fi
    printf '%s/shortcuts.vdf\n' "$newest"
}

steam_is_running() {
    command -v pgrep >/dev/null 2>&1 && pgrep -u "$(id -u)" -x steam >/dev/null 2>&1
}

steam_command() {
    if command -v steam >/dev/null 2>&1; then
        command -v steam
    elif [ -x "$HOME/.steam/steam/steam.sh" ]; then
        printf '%s\n' "$HOME/.steam/steam/steam.sh"
    else
        return 1
    fi
}

stop_steam_for_vdf() {
    local steam_bin
    local attempt

    [ "${ZHOUKEER_SKIP_STEAM_RESTART:-0}" = "1" ] && return 0
    steam_is_running || return 0
    steam_bin="$(steam_command)" || {
        echo "Steam 正在运行，但找不到 Steam 启动命令，无法安全写入非 Steam 游戏列表。"
        return 1
    }
    echo "正在让 Steam 安全退出，以写入非 Steam 游戏条目..."
    "$steam_bin" -shutdown >/dev/null 2>&1 || true
    for attempt in $(seq 1 20); do
        steam_is_running || return 0
        sleep 1
    done
    echo "Steam 未能在 20 秒内退出。请确认没有游戏运行后重试，原有库未被修改。"
    return 1
}

start_steam() {
    local steam_bin

    [ "${ZHOUKEER_SKIP_STEAM_RESTART:-0}" = "1" ] && return 0
    steam_bin="$(steam_command)" || return 0
    "$steam_bin" >/dev/null 2>&1 &
}

wait_for_steam_running() {
    local attempt

    steam_command >/dev/null 2>&1 || return 1
    for attempt in $(seq 1 30); do
        steam_is_running && return 0
        sleep 1
    done
    return 1
}

find_launcher_in_prefix() {
    local prefix_dir="$1"
    local relative_path

    while IFS= read -r relative_path; do
        [ -n "$relative_path" ] || continue
        if [ -f "$prefix_dir/pfx/drive_c/$relative_path" ]; then
            printf '%s\n' "$prefix_dir/pfx/drive_c/$relative_path"
            return 0
        fi
    done <<< "$LAUNCHER_TARGET_RELATIVES"
    return 1
}

find_launcher_in_drive() {
    local drive_c="$1"
    local relative_path

    while IFS= read -r relative_path; do
        [ -n "$relative_path" ] || continue
        if [ -f "$drive_c/$relative_path" ]; then
            printf '%s\n' "$drive_c/$relative_path"
            return 0
        fi
    done <<< "$LAUNCHER_TARGET_RELATIVES"
    return 1
}

find_installed_launcher() {
    local steam_root="$1"
    local relative_path candidate_dir candidate

    [ -d "$steam_root/steamapps/compatdata" ] || return 1
    while IFS= read -r relative_path; do
        [ -n "$relative_path" ] || continue
        for candidate_dir in "$steam_root/steamapps/compatdata"/*/; do
            [ -d "$candidate_dir" ] || continue
            candidate_dir="${candidate_dir%/}"
            candidate="$candidate_dir/pfx/drive_c/$relative_path"
            if [ -f "$candidate" ]; then
                printf '%s\n' "$candidate"
                return 0
            fi
        done
    done <<< "$LAUNCHER_TARGET_RELATIVES"
    return 1
}

installer_is_msi() {
    local file="$1" magic

    magic="$(od -An -tx1 -N4 "$file" 2>/dev/null | tr -d ' \n')"
    case "$magic" in
        d0cf11e0*) return 0 ;;
        *) return 1 ;;
    esac
}


run_launcher_installer() {
    local target="$1"
    local steam_root="$2"
    local installer_file="$3"
    local prefix_dir="$4"
    local proton_runner="$5"
    local status=0
    local elapsed=0
    local installed_file
    local timeout="${6:-$POST_INSTALL_TIMEOUT}"
    local install_mode="${7:-interactive}"

    launcher_details "$target" || return 1
    mkdir -p "$prefix_dir" || return 1
    if [ "$install_mode" = "silent" ]; then
        echo "正在静默安装 $LAUNCHER_NAME..." >&2
    else
        echo "正在打开 $LAUNCHER_NAME 官方安装器..." >&2
    fi
    case "$target:$install_mode" in
        epic:interactive) echo "弹出 Epic 安装窗口后，点击 Install（安装）；完成后点击 Finish（完成）。" >&2 ;;
        heihe:interactive) echo "弹出黑盒工坊安装窗口后，点击安装并等待完成即可。" >&2 ;;
        ubisoft:interactive|uplay:interactive) echo "弹出育碧安装窗口后，选择中文并依次点击接受、安装、完成。" >&2 ;;
    esac

    case "$target" in
        epic)
            if installer_is_msi "$installer_file"; then
                if [ "$install_mode" = "silent" ]; then
                    STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam_root" STEAM_COMPAT_DATA_PATH="$prefix_dir" \
                        STEAM_COMPAT_APP_ID=0 SteamAppId=0 SteamGameId=0 \
                        "$proton_runner" run msiexec /i "$installer_file" /qn /norestart 2>/dev/null || status=$?
                else
                    STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam_root" STEAM_COMPAT_DATA_PATH="$prefix_dir" \
                        STEAM_COMPAT_APP_ID=0 SteamAppId=0 SteamGameId=0 \
                        "$proton_runner" run msiexec /i "$installer_file" 2>/dev/null || status=$?
                fi
            else
                if [ "$install_mode" = "silent" ]; then
                    STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam_root" STEAM_COMPAT_DATA_PATH="$prefix_dir" \
                        STEAM_COMPAT_APP_ID=0 SteamAppId=0 SteamGameId=0 \
                        "$proton_runner" run "$installer_file" /S 2>/dev/null || status=$?
                else
                    STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam_root" STEAM_COMPAT_DATA_PATH="$prefix_dir" \
                        STEAM_COMPAT_APP_ID=0 SteamAppId=0 SteamGameId=0 \
                        "$proton_runner" run "$installer_file" 2>/dev/null || status=$?
                fi
            fi
            ;;
        battlenet|heihe|ubisoft|uplay)
            if [ "$install_mode" = "silent" ]; then
                STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam_root" STEAM_COMPAT_DATA_PATH="$prefix_dir" \
                    STEAM_COMPAT_APP_ID=0 SteamAppId=0 SteamGameId=0 \
                    "$proton_runner" run "$installer_file" /S 2>/dev/null || status=$?
            else
                STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam_root" STEAM_COMPAT_DATA_PATH="$prefix_dir" \
                    STEAM_COMPAT_APP_ID=0 SteamAppId=0 SteamGameId=0 \
                    "$proton_runner" run "$installer_file" 2>/dev/null || status=$?
            fi
            ;;
    esac
    printf '%s\n' "$status" > "$prefix_dir/.zhoukeer-installer-status" 2>/dev/null || true
    while [ "$elapsed" -le "$timeout" ]; do
        installed_file="$(find_launcher_in_prefix "$prefix_dir" || true)"
        if [ -n "$installed_file" ]; then
            printf '%s
' "$installed_file"
            return 0
        fi
        [ "$elapsed" -eq 0 ] && echo "官方安装器已退出，正在确认主程序文件..." >&2
        sleep "$POST_INSTALL_INTERVAL"
        elapsed=$((elapsed + POST_INSTALL_INTERVAL))
    done
    echo "没有在预期位置找到 $LAUNCHER_NAME 主程序。" >&2
    if [ "$status" -ne 0 ]; then
        echo "官方安装器退出码：$status" >&2
    fi
    echo "请确认没有在官方安装窗口中取消安装，然后重试。已下载的安装包和前缀会保留。" >&2
    return 1
}

find_proton_runner() {
    local steam_root="$1"
    local candidate

    if [ -n "${ZHOUKEER_PROTON_RUNNER:-}" ] && [ -x "$ZHOUKEER_PROTON_RUNNER" ]; then
        printf '%s
' "$ZHOUKEER_PROTON_RUNNER"
        return 0
    fi

    # 长期装机验证：优先 Proton 10.0-4，失败时仅回退到 Proton Experimental。
    candidate="$(find_proton_10_runner "$steam_root" || true)"
    if [ -n "$candidate" ]; then
        printf '%s\n' "$candidate"
        return 0
    fi
    find_proton_experimental_runner "$steam_root"

    return 1
}

find_proton_experimental_runner() {
    local steam_root="$1"
    local candidate

    for candidate in \
        "$steam_root/steamapps/common/Proton - Experimental/proton" \
        "$HOME/.steam/root/compatibilitytools.d/Proton - Experimental/proton"; do
        if [ -x "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done
    return 1
}

find_proton_10_runner() {
    local steam_root="$1"
    local candidate version_file

    candidate="$steam_root/steamapps/common/Proton 10.0-4/proton"
    if [ -x "$candidate" ]; then
        printf '%s\n' "$candidate"
        return 0
    fi
    candidate="$steam_root/steamapps/common/Proton 10.0/proton"
    version_file="$(dirname "$candidate")/version"
    if [ -x "$candidate" ] && [ -f "$version_file" ] && [ ! -L "$version_file" ] && \
       grep -Eqi '(^|[^0-9])10\.0-4([^0-9]|$)' "$version_file"; then
        printf '%s\n' "$candidate"
        return 0
    fi
    return 1
}

install_official_proton_10() {
    local steam_root="$1"
    local steam_bin runner elapsed=0

    case "$PROTON_INSTALL_TIMEOUT:$PROTON_INSTALL_INTERVAL" in
        *[!0-9:]*|:*|*:0) echo "安装环境等待参数无效。" >&2; return 1 ;;
    esac
    steam_bin="$(steam_command)" || {
        echo "找不到 Steam 客户端，无法自动准备安装环境。" >&2
        return 1
    }
    echo "正在通过 Steam 自动准备安装环境..." >&2
    "$steam_bin" "steam://install/$PROTON_10_APP_ID" >/dev/null 2>&1 &
    while [ "$elapsed" -le "$PROTON_INSTALL_TIMEOUT" ]; do
        runner="$(find_proton_10_runner "$steam_root" || true)"
        if [ -n "$runner" ]; then
            echo "安装环境已准备完成。" >&2
            printf '%s\n' "$runner"
            return 0
        fi
        sleep "$PROTON_INSTALL_INTERVAL"
        elapsed=$((elapsed + PROTON_INSTALL_INTERVAL))
    done
    echo "等待安装环境准备超时。请确认 Steam 在线且已登录后重试。" >&2
    return 1
}

ensure_proton_runner() {
    local steam_root="$1"
    local runner

    runner="$(find_proton_runner "$steam_root" || true)"
    if [ -n "$runner" ]; then
        printf '%s\n' "$runner"
        return 0
    fi
    install_official_proton_10 "$steam_root"
}

ensure_launcher_proton_runner() {
    local target="$1"
    local steam_root="$2"
    local runner

    if [ "$target" = "battlenet" ] || [ "$target" = "heihe" ]; then
        runner="$(find_proton_10_runner "$steam_root" || true)"
        if [ -n "$runner" ]; then
            printf '%s\n' "$runner"
            return 0
        fi
        install_official_proton_10 "$steam_root"
        return
    fi
    runner="$(find_proton_experimental_runner "$steam_root" || true)"
    [ -n "$runner" ] || runner="$(find_proton_10_runner "$steam_root" || true)"
    if [ -n "$runner" ]; then
        printf '%s\n' "$runner"
        return 0
    fi
    install_official_proton_10 "$steam_root"
}

install_official_proton_experimental() {
    local steam_root="$1"
    local steam_bin runner elapsed=0

    case "$PROTON_INSTALL_TIMEOUT:$PROTON_INSTALL_INTERVAL" in
        *[!0-9:]*|:*|*:) echo "安装环境等待参数无效。" >&2; return 1 ;;
    esac
    [ "$PROTON_INSTALL_INTERVAL" -gt 0 ] || {
        echo "安装环境检查间隔必须大于 0。" >&2
        return 1
    }
    steam_bin="$(steam_command)" || {
        echo "找不到 Steam 客户端，无法自动准备战网安装环境。" >&2
        return 1
    }
    echo "正在通过 Steam 自动准备战网安装环境..." >&2
    "$steam_bin" "steam://install/$PROTON_EXPERIMENTAL_APP_ID" >/dev/null 2>&1 &
    while [ "$elapsed" -le "$PROTON_INSTALL_TIMEOUT" ]; do
        runner="$(find_proton_experimental_runner "$steam_root" || true)"
        if [ -n "$runner" ]; then
            echo "战网安装环境已准备完成。" >&2
            printf '%s\n' "$runner"
            return 0
        fi
        sleep "$PROTON_INSTALL_INTERVAL"
        elapsed=$((elapsed + PROTON_INSTALL_INTERVAL))
    done
    echo "等待战网安装环境准备超时。请确认 Steam 在线且已登录后重试。" >&2
    return 1
}

create_launcher_wrapper() {
    local target="$1" steam_root="$2" prefix_dir="$3" proton_runner="$4" launcher_exe="$5" destination_dir="$6"
    local steam_app_id="${7:-0}" steam_game_id="${8:-0}"
    local wrapper="$destination_dir/launch-$target.sh"

    case "$steam_app_id:$steam_game_id" in
        *[!0-9:]*|:*)
            echo "Steam 游戏身份参数无效，未创建启动包装器。" >&2
            return 1
            ;;
    esac
    mkdir -p "$destination_dir" || return 1
    cat > "$wrapper" <<EOF
#!/bin/bash
PREFIX_DIR=$(shell_quote "$prefix_dir")
PROTON_RUNNER=$(shell_quote "$proton_runner")
LAUNCHER_EXE=$(shell_quote "$launcher_exe")
STEAM_ROOT=$(shell_quote "$steam_root")
export STEAM_COMPAT_DATA_PATH="\$PREFIX_DIR"
export STEAM_COMPAT_CLIENT_INSTALL_PATH="\$STEAM_ROOT"
export STEAM_COMPAT_APP_ID=$(shell_quote "$steam_app_id")
export SteamAppId=$(shell_quote "$steam_app_id")
export SteamGameId=$(shell_quote "$steam_game_id")
exec "\$PROTON_RUNNER" run "\$LAUNCHER_EXE"
EOF
    chmod +x "$wrapper" || return 1
    printf '%s\n' "$wrapper"
}

shell_quote() {
    local value="$1" escaped

    escaped="${value//\\/\\\\}"
    escaped="${escaped//\"/\\\"}"
    escaped="${escaped//\$/\\\$}"
    escaped="${escaped//\`/\\\`}"
    printf '"%s"' "$escaped"
}

create_launcher_desktop_shortcut() {
    local target="$1" wrapper="$2" name icon
    case "$target" in
        epic) name="Epic Games 启动器"; icon="$(launcher_cover_file "$target" "epic.png" || true)" ;;
        battlenet) name="战网启动器"; icon="$(launcher_cover_file "$target" "battlenet.png" || true)" ;;
        ubisoft|uplay) name="育碧"; icon="$(launcher_cover_file "$target" "ubisoft.png" || true)" ;;
        heihe) name="黑盒工坊"; icon="$(launcher_cover_file "$target" "heihe.png" || true)" ;;
        hmcl) name="HMCL 启动器"; icon="$PROJECT_ROOT/assets/icon-toolbox-deck.png" ;;
        *) return 1 ;;
    esac
    [ -s "$icon" ] || icon="$PROJECT_ROOT/assets/icon-toolbox-deck.png"
    mkdir -p "$HOME/Desktop" || return 1
    if [ "$target" = "ubisoft" ] || [ "$target" = "uplay" ]; then
        local old_shortcut="$HOME/Desktop/Ubisoft Connect（Uplay）.desktop"
        local old_cn_shortcut="$HOME/Desktop/育碧服务.desktop"
        if [ -f "$old_shortcut" ] && [ ! -L "$old_shortcut" ] && \
           grep -Eq '^Exec=.*/game-launchers/(ubisoft|uplay)/launch-(ubisoft|uplay)\.sh$' "$old_shortcut"; then
            rm -f -- "$old_shortcut"
        fi
        if [ -f "$old_cn_shortcut" ] && [ ! -L "$old_cn_shortcut" ] && \
           grep -Eq '^Exec=.*/game-launchers/(ubisoft|uplay)/launch-(ubisoft|uplay)\.sh$' "$old_cn_shortcut"; then
            rm -f -- "$old_cn_shortcut"
        fi
    fi
    cat > "$HOME/Desktop/$name.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$name
Exec=$wrapper
Terminal=false
Icon=$icon
Categories=Game;
X-Zhoukeer-Managed=true
EOF
    chmod +x "$HOME/Desktop/$name.desktop"
}

create_steam_desktop_shortcut() {
    local target="$1" game_id="$2" name icon
    case "$target" in
        battlenet) name="战网启动器"; icon="$(launcher_cover_file "$target" "battlenet.png" || true)" ;;
        *) return 1 ;;
    esac
    [ -s "$icon" ] || icon="$PROJECT_ROOT/assets/icon-toolbox-deck.png"
    case "$game_id" in
        ''|*[!0-9]*) echo "Steam 游戏编号无效，未创建桌面入口。"; return 1 ;;
    esac
    mkdir -p "$HOME/Desktop" || return 1
    cat > "$HOME/Desktop/$name.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$name
Exec=steam steam://rungameid/$game_id
Terminal=false
Icon=$icon
Categories=Game;
X-Zhoukeer-Managed=true
EOF
    chmod +x "$HOME/Desktop/$name.desktop"
}

remove_pending_battlenet_desktop_shortcut() {
    local shortcut="$HOME/Desktop/战网启动器.desktop"

    [ -f "$shortcut" ] && [ ! -L "$shortcut" ] || return 0
    grep -Fqx 'X-Zhoukeer-Managed=true' "$shortcut" && \
        grep -Eq '^Exec=steam steam://rungameid/[0-9]+$' "$shortcut" || return 0
    rm -f -- "$shortcut" || return 1
    echo "已移除未完成安装阶段的旧战网桌面入口。"
}

remove_legacy_battlenet_steam_entries() {
    local shortcut_file="$1" keep_exe="$2" remove_output

    remove_output="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" remove \
        --exe-basename "Battle.net Launcher.exe" \
        --exe-basename "Battle.net.exe" \
        --exe-basename "Battle.net-Setup.exe" \
        --exe-basename "launch-battlenet.sh" \
        --keep-exe "$keep_exe" --keep-name "$LAUNCHER_NAME")" || return 1
    if [ "$remove_output" = "removed" ]; then
        echo "已清理旧版战网 Steam 条目，只保留“战网启动器”。"
    fi
}

remove_legacy_battlenet_desktop_installer() {
    local old_installer="$HOME/Desktop/Battle.net-Setup.exe" size magic

    [ -f "$old_installer" ] && [ ! -L "$old_installer" ] || return 0
    size="$(wc -c < "$old_installer" | tr -d ' ')"
    magic="$(od -An -tx1 -N2 "$old_installer" | tr -d ' \n')"
    case "$size" in
        ''|*[!0-9]*) return 0 ;;
    esac
    [ "$size" -ge "${LAUNCHER_MIN_BYTES:-1048576}" ] || return 0
    [ "$magic" = "4d5a" ] || return 0
    rm -f -- "$old_installer" || return 1
    echo "已移除旧版Renkit下载到桌面的战网安装包。"
}

install_launcher_steam_artwork() {
    local target="$1" shortcut_file="$2"
    local asset_name grid_dir app_id signed_app_id

    shift 2
    [ "$#" -gt 0 ] || return 1

    case "$target" in
        epic) asset_name="epic" ;;
        battlenet) asset_name="battlenet" ;;
        ubisoft|uplay) asset_name="ubisoft" ;;
        heihe) asset_name="heihe" ;;
        *) return 1 ;;
    esac
    grid_dir="$(dirname "$shortcut_file")/grid"
    if [ -L "$grid_dir" ]; then
        echo "Steam 封面目录是符号链接，已停止写入：$grid_dir"
        return 1
    fi
    install -d -m 0755 -- "$grid_dir" || return 1
    for app_id in "$@"; do
        case "$app_id" in
            ''|*[!0-9]*) echo "Steam 非 Steam 游戏编号无效，未写入库封面。"; return 1 ;;
        esac
        if [ "${#app_id}" -gt 10 ]; then
            install_launcher_artwork_for_id "$asset_name" "$grid_dir" "$app_id" || return 1
            continue
        fi
        signed_app_id="$app_id"
        if [ "$app_id" -gt 2147483647 ]; then
            signed_app_id=$((app_id - 4294967296))
        fi
        install_launcher_artwork_for_id "$asset_name" "$grid_dir" "$app_id" || return 1
        install_launcher_artwork_for_id "$asset_name" "$grid_dir" "$signed_app_id" || return 1
    done
}

launcher_cover_magic_ok() {
    local file="$1" magic

    magic="$(od -An -tx1 -N8 "$file" 2>/dev/null | tr -d ' \n')"
    case "$magic" in
        89504e47*) return 0 ;;
        ffd8ff*) return 0 ;;
        *) return 1 ;;
    esac
}

ensure_launcher_covers_cached() {
    local bundle="$LAUNCHER_COVER_CACHE_ROOT/launcher-covers.tar.gz"
    local tmp_dir target target_dir file

    if [ "${ZHOUKEER_TEST_MODE:-0}" = "1" ]; then
        return 1
    fi
    [ -f "$LAUNCHER_COVER_READY_MARKER" ] && return 0
    mkdir -p "$LAUNCHER_COVER_CACHE_ROOT" || return 1
    if ! ( GITEE_MIRROR_REPO="${ZHOUKEER_LAUNCHER_COVER_MIRROR_REPO:-zhoukeer-toolbox-v2}"; \
        export GITEE_MIRROR_REPO; \
        download_gitee_mirror_file "$LAUNCHER_COVER_MIRROR_ID" "$bundle" \
            "" "$LAUNCHER_COVER_BUNDLE_NAME" >/dev/null 2>&1 ); then
        return 1
    fi
    tmp_dir="$(mktemp -d 2>/dev/null)" || {
        rm -f -- "$bundle"
        return 1
    }
    if ! tar --no-xattrs --warning=no-unknown-keyword -xzf "$bundle" -C "$tmp_dir"; then
        rm -f -- "$bundle"
        return 1
    fi
    for target in epic battlenet ubisoft heihe; do
        target_dir="$LAUNCHER_COVER_CACHE_ROOT/$target"
        mkdir -p "$target_dir" || return 1
        if [ -d "$tmp_dir/$target" ]; then
            for file in "$tmp_dir/$target"/*; do
                [ -f "$file" ] && [ ! -L "$file" ] || continue
                cp -f -- "$file" "$target_dir/" || true
            done
        fi
    done
    touch "$LAUNCHER_COVER_READY_MARKER" || true
    rm -f -- "$bundle"
    return 0
}

launcher_cover_file() {
    local target="$1" filename="$2"
    local local_file="$PROJECT_ROOT/assets/game-launchers/$filename"
    local cache_dir="$LAUNCHER_COVER_CACHE_ROOT/$target"
    local cached_file="$cache_dir/$filename"

    if [ -f "$LAUNCHER_COVER_READY_MARKER" ] && \
        [ -s "$cached_file" ] && [ ! -L "$cached_file" ] && \
        launcher_cover_magic_ok "$cached_file"; then
        printf '%s\n' "$cached_file"
        return 0
    fi
    ensure_launcher_covers_cached || true
    if [ -f "$LAUNCHER_COVER_READY_MARKER" ] && \
        [ -s "$cached_file" ] && [ ! -L "$cached_file" ] && \
        launcher_cover_magic_ok "$cached_file"; then
        printf '%s\n' "$cached_file"
        return 0
    fi
    if [ -s "$local_file" ] && [ ! -L "$local_file" ]; then
        printf '%s\n' "$local_file"
        return 0
    fi
    echo "启动器封面素材不可用：$filename" >&2
    return 1
}

launcher_image_has_dimensions() {
    local file="$1" expected_width="$2" expected_height="$3"

    python3 - "$file" "$expected_width" "$expected_height" <<'PY'
import struct
import sys

expected = (int(sys.argv[2]), int(sys.argv[3]))
with open(sys.argv[1], "rb") as handle:
    head = handle.read(24)
if head[:8] == b"\x89PNG\r\n\x1a\n" and len(head) >= 24:
    width, height = struct.unpack(">II", head[16:24])
    sys.exit(0 if (width, height) == expected else 1)
if head[:2] == b"\xff\xd8":
    with open(sys.argv[1], "rb") as handle:
        data = handle.read()
    pos = 2
    while pos + 9 <= len(data):
        if data[pos] != 0xFF:
            pos += 1
            continue
        marker = data[pos + 1]
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            pos += 2
            continue
        if marker == 0xDA:
            break
        length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
        if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            height, width = struct.unpack(">HH", data[pos + 5:pos + 9])
            sys.exit(0 if (width, height) == expected else 1)
        pos += 2 + length
sys.exit(1)
PY
}

install_launcher_artwork_for_id() {
    local asset_name="$1" grid_dir="$2" artwork_id="$3"
    local grid_source portrait_source hero_source icon_source logo_source background_file stage_dir staged_file

    # 先在同一文件系统准备完整的新素材。任一素材失败时保留现有封面，
    # 避免修复过程中先删旧图、再因下载或写入失败留下空白库封面。
    stage_dir="$(mktemp -d "$grid_dir/.renkit-artwork-${artwork_id}.XXXXXX" 2>/dev/null)" || return 1
    icon_source="$(launcher_cover_file "$asset_name" "$asset_name.png" || true)"
    [ -s "$icon_source" ] || { rm -rf -- "$stage_dir"; return 1; }
    install -m 0644 -- "$icon_source" \
        "$stage_dir/${artwork_id}_icon.png" || { rm -rf -- "$stage_dir"; return 1; }
    grid_source="$(launcher_cover_file "$asset_name" "$asset_name-grid.jpg" || true)"
    [ -s "$grid_source" ] || { rm -rf -- "$stage_dir"; return 1; }
    if ! launcher_image_has_dimensions "$grid_source" 920 430; then
        echo "横向胶囊图不是 920x430，已保留 Steam 库现有封面：$asset_name"
        rm -rf -- "$stage_dir"
        return 1
    fi
    install -m 0644 -- "$grid_source" \
        "$stage_dir/${artwork_id}.jpg" || { rm -rf -- "$stage_dir"; return 1; }
    portrait_source="$(launcher_cover_file "$asset_name" "$asset_name-portrait.jpg" || true)"
    [ -s "$portrait_source" ] || { rm -rf -- "$stage_dir"; return 1; }
    if ! launcher_image_has_dimensions "$portrait_source" 600 900; then
        echo "竖版胶囊图不是 600x900，已保留 Steam 库现有封面：$asset_name"
        rm -rf -- "$stage_dir"
        return 1
    fi
    install -m 0644 -- "$portrait_source" \
        "$stage_dir/${artwork_id}p.jpg" || { rm -rf -- "$stage_dir"; return 1; }
    hero_source="$(launcher_cover_file "$asset_name" "$asset_name-hero.jpg" || true)"
    [ -s "$hero_source" ] || { rm -rf -- "$stage_dir"; return 1; }
    install -m 0644 -- "$hero_source" \
        "$stage_dir/${artwork_id}_hero.jpg" || { rm -rf -- "$stage_dir"; return 1; }
    logo_source="$(launcher_cover_file "$asset_name" "$asset_name-logo.png" || true)"
    [ -s "$logo_source" ] || logo_source="$icon_source"
    install -m 0644 -- "$logo_source" \
        "$stage_dir/${artwork_id}_logo.png" || { rm -rf -- "$stage_dir"; return 1; }
    background_file="$(launcher_cover_file "$asset_name" "$asset_name-background.jpg" || true)"
    [ -s "$background_file" ] || { rm -rf -- "$stage_dir"; return 1; }
    install -m 0644 -- "$background_file" \
        "$stage_dir/${artwork_id}_background.jpg" || { rm -rf -- "$stage_dir"; return 1; }

    # 新素材完整后才清理不同扩展名的旧文件；目标文件由同文件系统 mv 原子替换。
    rm -f -- \
        "$grid_dir/${artwork_id}.jpeg" \
        "$grid_dir/${artwork_id}.png" \
        "$grid_dir/${artwork_id}p.jpeg" \
        "$grid_dir/${artwork_id}p.png" \
        "$grid_dir/${artwork_id}_hero.jpeg" \
        "$grid_dir/${artwork_id}_hero.png" \
        "$grid_dir/${artwork_id}_logo.jpg" \
        "$grid_dir/${artwork_id}_logo.jpeg" \
        "$grid_dir/${artwork_id}_icon.jpg" \
        "$grid_dir/${artwork_id}_icon.jpeg" \
        "$grid_dir/${artwork_id}_background.png" || { rm -rf -- "$stage_dir"; return 1; }
    for staged_file in "$stage_dir"/*; do
        mv -f -- "$staged_file" "$grid_dir/" || { rm -rf -- "$stage_dir"; return 1; }
    done
    rmdir -- "$stage_dir" || return 1
    chmod 0755 -R -- "$grid_dir" 2>/dev/null || true
}

apply_launcher_decky_artwork() {
    local target="$1"
    local attempt
    shift

    [ "${IS_STEAMOS:-0}" -eq 1 ] || [ "${IS_BAZZITE:-0}" -eq 1 ] || return 0
    for attempt in 1 2; do
        if bash "$PROJECT_ROOT/scripts/apply_steam_artwork.sh" "$target" "$@" >/dev/null 2>&1; then
            echo "$LAUNCHER_NAME Steam 库封面已即时应用。"
            return 0
        fi
        sleep 2
    done
    echo "$LAUNCHER_NAME Steam 库封面已写入，Steam 重启后生效。"
}

set_steam_proton_10() {
    local steam_root="$1" app_id="$2"
    local config_file="$steam_root/config/config.vdf"

    python3 "$STEAM_COMPAT_HELPER" --config-file "$config_file" \
        --app-id "$app_id" --tool proton_10 >/dev/null
}

prepare_launcher_steam_installer() {
    local target="$1" steam_root="$2" installer_file="$3" shortcut_file="$4"
    local app_id artwork_alt_app_id game_id icon_path

    launcher_details "$target" || return 1
    case "$target" in
        battlenet) icon_path="$(launcher_cover_file "$target" "battlenet.png" || true)" ;;
        heihe) icon_path="$(launcher_cover_file "$target" "heihe.png" || true)" ;;
        *) return 1 ;;
    esac
    [ -s "$icon_path" ] || icon_path="$PROJECT_ROOT/assets/icon-toolbox-deck.png"
    stop_steam_for_vdf || return 1
    ZHOUKEER_STEAM_STOPPED=1
    trap 'if [ "${ZHOUKEER_STEAM_STOPPED:-0}" = "1" ]; then ZHOUKEER_STEAM_STOPPED=0; start_steam >/dev/null 2>&1 || true; fi' RETURN
    if [ "$target" = "battlenet" ]; then
        remove_pending_battlenet_desktop_shortcut || return 1
    fi
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" add \
        --name "$LAUNCHER_NAME" --exe "$installer_file" --start-dir "$(dirname "$installer_file")" \
        >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" set-icon \
        --name "$LAUNCHER_NAME" --exe "$installer_file" --icon "$icon_path" >/dev/null || return 1
    app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" find-appid \
        --name "$LAUNCHER_NAME" --exe "$installer_file")" || return 1
    artwork_alt_app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" appid-raw \
        --name "$LAUNCHER_NAME" --exe "$installer_file")" || return 1
    game_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" gameid \
        --name "$LAUNCHER_NAME" --exe "$installer_file")" || return 1
    set_steam_proton_10 "$steam_root" "$app_id" || return 1
    install_launcher_steam_artwork "$target" "$shortcut_file" "$app_id" "$artwork_alt_app_id" "$game_id" || {
        echo "$LAUNCHER_NAME 封面写入未完成，不影响 Steam 条目；可稍后运行“修复启动器封面”。"
    }
    echo "Steam 已停止，安装条目、兼容层和封面已写入文件。"
    echo "正在启动 Steam..."
    start_steam
    ZHOUKEER_STEAM_STOPPED=0
    echo "Steam 已启动，请在 Steam 库中点击“${LAUNCHER_NAME}”完成安装。"
    echo "安装阶段不会创建桌面入口，请只在 Steam 库点击“${LAUNCHER_NAME}”完成安装。"
    echo "安装完成后，再点击一次Renkit的 $LAUNCHER_NAME 入口即可自动转为正式启动器并创建可用桌面入口。"
}

prepare_battlenet_steam_installer() {
    prepare_launcher_steam_installer battlenet "$@"
}

finish_launcher_steam_entry() {
    local target="$1" steam_root="$2" shortcut_file="$3" launcher_exe="$4" prefix_dir="$5" proton_runner="$6"
    local app_id artwork_alt_app_id game_id icon_path wrapper grid_dir grid_icon

    launcher_details "$target" || return 1
    case "$target" in
        battlenet) icon_path="$(launcher_cover_file "$target" "battlenet.png" || true)" ;;
        heihe) icon_path="$(launcher_cover_file "$target" "heihe.png" || true)" ;;
        *) return 1 ;;
    esac
    [ -s "$icon_path" ] || icon_path="$PROJECT_ROOT/assets/icon-toolbox-deck.png"
    stop_steam_for_vdf || return 1
    ZHOUKEER_STEAM_STOPPED=1
    trap 'if [ "${ZHOUKEER_STEAM_STOPPED:-0}" = "1" ]; then ZHOUKEER_STEAM_STOPPED=0; start_steam >/dev/null 2>&1 || true; fi' RETURN
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" add \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe" --start-dir "$(dirname "$launcher_exe")" \
        >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" set-icon \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe" --icon "$icon_path" >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" verify \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe" --icon "$icon_path" \
        >/dev/null || return 1
    if [ "$target" = "battlenet" ]; then
        remove_legacy_battlenet_steam_entries "$shortcut_file" "$launcher_exe" || return 1
    fi
    app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" find-appid \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe")" || return 1
    artwork_alt_app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" appid-raw \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe")" || return 1
    game_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" gameid \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe")" || return 1
    link_steam_compatdata_drive "$steam_root" "$app_id" "$prefix_dir" || return 1
    link_steam_compatdata_drive "$steam_root" "$artwork_alt_app_id" "$prefix_dir" || true
    install_launcher_steam_artwork "$target" "$shortcut_file" "$app_id" "$artwork_alt_app_id" "$game_id" || {
        echo "$LAUNCHER_NAME 封面写入未完成，不影响 Steam 条目；可稍后运行“修复启动器封面”。"
    }
    grid_dir="$(dirname "$shortcut_file")/grid"
    grid_icon="$(set_launcher_grid_icon "$shortcut_file" "$LAUNCHER_NAME" "$launcher_exe" \
        "$grid_dir" "$app_id" "$artwork_alt_app_id" "$game_id" || true)"
    if [ -n "$grid_icon" ]; then
        icon_path="$grid_icon"
        python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" verify \
            --name "$LAUNCHER_NAME" --exe "$launcher_exe" --icon "$icon_path" \
            >/dev/null || return 1
    fi
    # 部分 Steam 客户端会在桌面 steam://rungameid 链接启动时丢失非 Steam
    # 游戏配置，改用与 Steam 条目同一前缀的包装器，避免“游戏配置文件不可用”。
    wrapper="$(create_launcher_wrapper "$target" "$steam_root" "$prefix_dir" "$proton_runner" \
        "$launcher_exe" "$APP_DIR/game-launchers/$target" "$app_id" "$game_id")" || return 1
    create_launcher_desktop_shortcut "$target" "$wrapper" || return 1
    if [ "$target" = "battlenet" ]; then
        remove_legacy_battlenet_desktop_installer || return 1
    fi
    echo "正在写入 Proton 10.0-4 兼容层..."
    set_steam_proton_10 "$steam_root" "$app_id" || return 1
    set_steam_proton_10 "$steam_root" "$artwork_alt_app_id" || true
    echo "正式条目、兼容层和封面已写入文件。"
    echo "正在启动 Steam..."
    start_steam
    ZHOUKEER_STEAM_STOPPED=0
    echo "Steam 已启动；兼容层和封面已写入文件，Steam 读取后生效。"
    echo "若库中封面仍是旧图，请在游戏模式运行“修复启动器封面”。"
    if [ "$target" = "battlenet" ]; then
        echo "战网登录页：https://account.battle.net/login"
        echo "提示：点击战网启动器右边手柄图标，将右触控板行为改为“用作鼠标”。"
    fi
    echo "$LAUNCHER_NAME 已添加到 Steam 库，桌面入口、封面与Renkit标识均已设置。"
}

finish_battlenet_steam_entry() {
    finish_launcher_steam_entry battlenet "$@"
}

install_hmcl_jar() {
    local hmcl_base="$1" temporary

    mkdir -p "$hmcl_base" || return 1
    if [ -f "$hmcl_base/HMCL.jar" ] && [ ! -L "$hmcl_base/HMCL.jar" ] && \
        [ "$(launcher_file_sha256 "$hmcl_base/HMCL.jar")" = "$LAUNCHER_SHA256" ]; then
        echo "[已安装] HMCL 主程序已存在且校验通过，无需重复下载。"
        return 0
    fi
    temporary="$hmcl_base/.HMCL.jar.new.$$"
    rm -f -- "$temporary"
    download_hmcl_artifact "$LAUNCHER_URL" "$LAUNCHER_SHA256" "$temporary" \
        "$LAUNCHER_MIN_BYTES" "$LAUNCHER_MAGIC" "$LAUNCHER_NAME" || return 1
    mv -f -- "$temporary" "$hmcl_base/HMCL.jar" || {
        rm -f -- "$temporary"
        return 1
    }
}

install_hmcl_java() {
    local hmcl_base="$1" download stage new_root jre_dir backup

    if [ -x "$hmcl_base/java/bin/java" ]; then
        echo "[已安装] HMCL Java 运行环境已存在，无需重复下载。"
        return 0
    fi
    download="$hmcl_base/.java-download.$$"
    stage="$hmcl_base/.java-stage.$$"
    new_root="$hmcl_base/.java-new.$$"
    rm -rf -- "$download" "$stage" "$new_root"
    mkdir -p "$stage" || return 1
    if ! download_hmcl_artifact "$LAUNCHER_HMCL_JAVA_URL" "$LAUNCHER_HMCL_JAVA_SHA256" "$download" \
        "$LAUNCHER_HMCL_JAVA_MIN_BYTES" "$LAUNCHER_HMCL_JAVA_MAGIC" "HMCL Java 运行环境"; then
        rm -rf -- "$download" "$stage"
        return 1
    fi
    if ! tar --no-same-owner --no-same-permissions --no-acls --no-xattrs \
        -xzf "$download" -C "$stage"; then
        rm -rf -- "$download" "$stage"
        echo "HMCL Java 运行环境解压失败，旧版本保持不变。"
        return 1
    fi
    jre_dir="$(find "$stage" -mindepth 1 -maxdepth 1 -type d -print -quit 2>/dev/null)"
    [ -n "$jre_dir" ] && [ -x "$jre_dir/bin/java" ] || {
        rm -rf -- "$download" "$stage"
        echo "HMCL Java 运行环境缺少 bin/java。"
        return 1
    }
    mkdir -p "$new_root" || { rm -rf -- "$download" "$stage"; return 1; }
    if ! cp -R -- "$jre_dir/." "$new_root/"; then
        rm -rf -- "$download" "$stage" "$new_root"
        echo "HMCL Java 运行环境写入失败，旧版本保持不变。"
        return 1
    fi
    rm -rf -- "$download" "$stage"
    if [ -e "$hmcl_base/java" ]; then
        backup="$hmcl_base/.java-backup.$$"
        rm -rf -- "$backup"
        mv -- "$hmcl_base/java" "$backup" || { rm -rf -- "$new_root"; return 1; }
        if ! mv -- "$new_root" "$hmcl_base/java"; then
            mv -- "$backup" "$hmcl_base/java" 2>/dev/null || true
            rm -rf -- "$new_root"
            return 1
        fi
        rm -rf -- "$backup"
    else
        mv -- "$new_root" "$hmcl_base/java" || { rm -rf -- "$new_root"; return 1; }
    fi
    [ -x "$hmcl_base/java/bin/java" ] || return 1
    echo "HMCL Java 运行环境已就绪：$hmcl_base/java"
}

install_hmcl_launcher() {
    local steam_root hmcl_base jar_path wrapper shortcut_file icon_path
    local app_id artwork_alt_app_id game_id

    detect_platform
    if [ "$IS_STEAMOS" -ne 1 ] && [ "$IS_BAZZITE" -ne 1 ]; then
        echo "HMCL 启动器安装仅支持 SteamOS 或 Bazzite。"
        return 1
    fi
    launcher_details hmcl || return 1
    steam_root="$(find_steam_root)" || return 1
    hmcl_base="$LAUNCHER_BASE/hmcl"
    mkdir -p "$hmcl_base" || return 1
    install_hmcl_jar "$hmcl_base" || return 1
    install_hmcl_java "$hmcl_base" || return 1
    jar_path="$hmcl_base/HMCL.jar"
    wrapper="$APP_DIR/game-launchers/hmcl/launch-hmcl.sh"
    mkdir -p "$(dirname "$wrapper")" || return 1
    cat > "$wrapper" <<EOF
#!/bin/bash
JAVA_BIN=$(shell_quote "$hmcl_base/java/bin/java")
HMCL_JAR=$(shell_quote "$jar_path")
exec "\$JAVA_BIN" -jar "\$HMCL_JAR"
EOF
    chmod +x "$wrapper" || return 1
    shortcut_file="$(find_shortcut_file "$steam_root")" || return 1
    icon_path="$PROJECT_ROOT/assets/icon-toolbox-deck.png"
    stop_steam_for_vdf || return 1
    ZHOUKEER_STEAM_STOPPED=1
    trap 'if [ "${ZHOUKEER_STEAM_STOPPED:-0}" = "1" ]; then ZHOUKEER_STEAM_STOPPED=0; start_steam >/dev/null 2>&1 || true; fi' RETURN
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" add \
        --name "$LAUNCHER_NAME" --exe "$wrapper" --start-dir "$hmcl_base" \
        >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" set-icon \
        --name "$LAUNCHER_NAME" --exe "$wrapper" --icon "$icon_path" >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" verify \
        --name "$LAUNCHER_NAME" --exe "$wrapper" --icon "$icon_path" \
        >/dev/null || {
            echo "$LAUNCHER_NAME 的 Steam 条目写入后校验失败，桌面图标仍可使用。"
            return 1
        }
    app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" find-appid \
        --name "$LAUNCHER_NAME" --exe "$wrapper")" || return 1
    artwork_alt_app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" appid-raw \
        --name "$LAUNCHER_NAME" --exe "$wrapper")" || return 1
    game_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" gameid \
        --name "$LAUNCHER_NAME" --exe "$wrapper")" || return 1
    create_launcher_desktop_shortcut hmcl "$wrapper" || return 1
    echo "正在启动 Steam..."
    start_steam
    ZHOUKEER_STEAM_STOPPED=0
    echo "Steam 已启动；$LAUNCHER_NAME 已添加到 Steam 库与桌面。"
    echo "首次运行请用 Microsoft 账号登录，并在 HMCL 中安装 Java/Minecraft 后游玩。"
    log "HMCL 启动器安装完成"
}

install_launcher() {
    local target="$1" steam_root launcher_exe runner app_dir prefix wrapper shortcut_file installer_file app_id artwork_alt_app_id game_id icon_path workdir platform_drive_c grid_dir grid_icon visible_exe
    detect_platform
    if [ "$IS_STEAMOS" -ne 1 ] && [ "$IS_BAZZITE" -ne 1 ]; then
        echo "游戏启动器安装仅支持 SteamOS 或 Bazzite。"
        return 1
    fi
    launcher_details "$target" || return 1
    steam_root="$(find_steam_root)" || return 1
    app_dir="$APP_DIR/game-launchers/$target"
    mkdir -p "$app_dir" || return 1
    prefix="$app_dir/compatdata"
    launcher_exe="$(find_launcher_in_prefix "$prefix" || find_installed_launcher "$steam_root" || true)"
    runner="$(ensure_launcher_proton_runner "$target" "$steam_root")" || return 1

    if [ "$target" = "battlenet" ] || [ "$target" = "heihe" ]; then
        shortcut_file="$(find_shortcut_file "$steam_root")" || return 1
        if [ -n "$launcher_exe" ]; then
            echo "检测到已安装的 ${LAUNCHER_NAME}，跳过安装包下载。"
            case "$launcher_exe" in
                */pfx/drive_c/*) prefix="${launcher_exe%/pfx/drive_c/*}" ;;
                *) echo "无法确定 $LAUNCHER_NAME 安装环境，已停止写入 Steam 条目。"; return 1 ;;
            esac
            migrate_launcher_drive_to_visible "$target" "$prefix" || return 1
            launcher_exe="$(find_launcher_in_prefix "$prefix" || find_installed_launcher "$steam_root" || true)"
            [ -n "$launcher_exe" ] || {
                echo "$LAUNCHER_NAME 虚拟目录迁移后未找到主程序。"
                return 1
            }
            if [ "$target" = "battlenet" ]; then
                visible_exe="$(launcher_drive_c battlenet)/Program Files (x86)/$LAUNCHER_PREINSTALLED_TARGET_RELATIVE"
            elif [ "$target" = "heihe" ]; then
                visible_exe="$(find_battle_platform_drive_c "$steam_root" 2>/dev/null || true)/Program Files (x86)/$LAUNCHER_PREINSTALLED_TARGET_RELATIVE"
            fi
            if [ -n "${visible_exe:-}" ] && [ -f "$visible_exe" ] && [ ! -L "$visible_exe" ]; then
                launcher_exe="$visible_exe"
            fi
        else
            if [ "$target" = "heihe" ]; then
                platform_drive_c="$(find_battle_platform_drive_c "$steam_root" || true)"
                if [ -z "$platform_drive_c" ]; then
                    echo "未检测到战网启动器，请先安装战网启动器再安装黑盒工坊。"
                    return 1
                fi
            else
                platform_drive_c="$(launcher_drive_c battlenet)"
                mkdir -p "$platform_drive_c" || return 1
            fi
            workdir="$app_dir/.download"
            if [ "${LAUNCHER_PREINSTALLED:-0}" = "1" ] && \
                download_preinstalled_launcher "$workdir" && \
                extract_preinstalled_launcher "$workdir/$LAUNCHER_PREINSTALLED_FILE" "$platform_drive_c"; then
                rm -rf -- "$workdir"
                prefix="$(prepare_launcher_shared_prefix "$target" "$platform_drive_c")" || return 1
                launcher_exe="$platform_drive_c/Program Files (x86)/$LAUNCHER_PREINSTALLED_TARGET_RELATIVE"
                [ -f "$launcher_exe" ] && [ ! -L "$launcher_exe" ] || {
                    echo "解压后未找到 $LAUNCHER_NAME 主程序。"
                    return 1
                }
            else
                rm -rf -- "$workdir"
                echo "$LAUNCHER_NAME 预装客户端不可用，正在回退到 Steam 库安装流程。"
                installer_file="$app_dir/$LAUNCHER_FILE_NAME"
                download_launcher_installer "$installer_file" || return 1
                prepare_launcher_steam_installer "$target" "$steam_root" "$installer_file" "$shortcut_file"
                return
            fi
        fi
        finish_launcher_steam_entry "$target" "$steam_root" "$shortcut_file" "$launcher_exe" "$prefix" "$runner"
        return
    fi

    if [ -n "$launcher_exe" ]; then
        echo "检测到已安装的 ${LAUNCHER_NAME}，跳过安装包下载。"
        case "$launcher_exe" in
            "$prefix"/pfx/drive_c/*) ;;
            *) prefix="${launcher_exe%/pfx/drive_c/*}" ;;
        esac
        migrate_launcher_drive_to_visible "$target" "$prefix" || return 1
        launcher_exe="$(find_launcher_in_prefix "$prefix" || find_installed_launcher "$steam_root" || true)"
        [ -n "$launcher_exe" ] || {
            echo "$LAUNCHER_NAME 虚拟目录迁移后未找到主程序。"
            return 1
        }
        if visible_exe="$(find_launcher_in_drive "$(launcher_drive_c "$target")")" && \
            [ -n "$visible_exe" ]; then
            launcher_exe="$visible_exe"
        fi
    else
        platform_drive_c="$(launcher_drive_c "$target")"
        mkdir -p "$platform_drive_c" || return 1
        prefix="$(prepare_launcher_shared_prefix "$target" "$platform_drive_c")" || return 1
        installer_file="$app_dir/$LAUNCHER_FILE_NAME"
        download_launcher_installer "$installer_file" || return 1
        case "$target" in
            epic|ubisoft|uplay)
                launcher_exe="$(run_launcher_installer "$target" "$steam_root" "$installer_file" "$prefix" "$runner" 120 silent || true)"
                if [ -z "$launcher_exe" ]; then
                    echo "$LAUNCHER_NAME 静默安装未完成，正在回退到官方可见安装窗口。"
                    launcher_exe="$(run_launcher_installer "$target" "$steam_root" "$installer_file" "$prefix" "$runner")" || return 1
                fi
                ;;
            *)
                launcher_exe="$(run_launcher_installer "$target" "$steam_root" "$installer_file" "$prefix" "$runner")" || return 1
                ;;
        esac
        launcher_exe="$(find_launcher_in_drive "$platform_drive_c" || true)"
        [ -n "$launcher_exe" ] || {
            echo "$LAUNCHER_NAME 安装后未找到主程序。"
            return 1
        }
    fi
    case "$target" in
        epic) icon_path="$(launcher_cover_file "$target" "epic.png" || true)" ;;
        battlenet) icon_path="$(launcher_cover_file "$target" "battlenet.png" || true)" ;;
        ubisoft|uplay) icon_path="$(launcher_cover_file "$target" "ubisoft.png" || true)" ;;
        heihe) icon_path="$(launcher_cover_file "$target" "heihe.png" || true)" ;;
        *) return 1 ;;
    esac
    [ -s "$icon_path" ] || icon_path="$PROJECT_ROOT/assets/icon-toolbox-deck.png"
    shortcut_file="$(find_shortcut_file "$steam_root")" || return 1
    stop_steam_for_vdf || return 1
    ZHOUKEER_STEAM_STOPPED=1
    trap 'if [ "${ZHOUKEER_STEAM_STOPPED:-0}" = "1" ]; then ZHOUKEER_STEAM_STOPPED=0; start_steam >/dev/null 2>&1 || true; fi' RETURN
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" add \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe" --start-dir "$(dirname "$launcher_exe")" \
        >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" set-icon \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe" --icon "$icon_path" >/dev/null || return 1
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" verify \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe" --icon "$icon_path" >/dev/null || {
        echo "$LAUNCHER_NAME 的 Steam 条目写入后校验失败，桌面图标仍可使用。"
        return 1
    }
    app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" find-appid \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe")" || return 1
    artwork_alt_app_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" appid-raw \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe")" || return 1
    game_id="$(python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" gameid \
        --name "$LAUNCHER_NAME" --exe "$launcher_exe")" || return 1
    wrapper="$(create_launcher_wrapper "$target" "$steam_root" "$prefix" "$runner" "$launcher_exe" \
        "$app_dir" "$app_id" "$game_id")" || return 1
    create_launcher_desktop_shortcut "$target" "$wrapper" || return 1
    set_steam_proton_10 "$steam_root" "$app_id" || return 1
    set_steam_proton_10 "$steam_root" "$artwork_alt_app_id" || true
    link_steam_compatdata_drive "$steam_root" "$app_id" "$prefix" || return 1
    link_steam_compatdata_drive "$steam_root" "$artwork_alt_app_id" "$prefix" || true
    install_launcher_steam_artwork "$target" "$shortcut_file" "$app_id" "$artwork_alt_app_id" "$game_id" || {
        echo "$LAUNCHER_NAME 封面写入未完成，不影响 Steam 条目；可稍后运行“修复启动器封面”。"
    }
    grid_dir="$(dirname "$shortcut_file")/grid"
    grid_icon="$(set_launcher_grid_icon "$shortcut_file" "$LAUNCHER_NAME" "$launcher_exe" \
        "$grid_dir" "$app_id" "$artwork_alt_app_id" "$game_id" || true)"
    if [ -n "$grid_icon" ]; then
        icon_path="$grid_icon"
        python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" verify \
            --name "$LAUNCHER_NAME" --exe "$launcher_exe" --icon "$icon_path" \
            >/dev/null || return 1
    fi
    echo "Steam 条目与封面已写入文件。"
    echo "正在启动 Steam..."
    start_steam
    ZHOUKEER_STEAM_STOPPED=0
    echo "Steam 已启动；封面已写入文件，Steam 读取后生效。"
    echo "若库中封面仍是旧图，请在游戏模式运行“修复启动器封面”。"
    echo "$LAUNCHER_NAME 已添加到 Steam 库，桌面入口、封面与Renkit标识均已设置。"
    if [ "$target" = "epic" ]; then
        echo "Epic 改中文：右上角头像 → Settings → Language → 中文（简体）→ Restart Now。"
        echo "若下载管理器仍显示英文，请选择不带 System Default 的中文（简体）后重启。"
    fi
}

confirm_launcher_uninstall() {
    local name="$1" answer

    echo "将卸载：$name"
    echo "会移除 Steam 库条目、桌面入口和Renkit包装器。"
    echo "$name 的账号、游戏与下载文件会保留，不会被删除。"
    if [ "${ZHOUKEER_AUTO_CONFIRM:-0}" = "1" ]; then
        return 0
    fi
    read -r -p "确认卸载请输入 UNINSTALL：" answer
    [ "$answer" = "UNINSTALL" ]
}

launcher_steam_exe_basenames() {
    case "$1" in
        epic) printf '%s\n' "EpicGamesLauncherInstaller.msi" "EpicGamesLauncher.exe" "launch-epic.sh" ;;
        battlenet) printf '%s\n' "Battle.net-Setup.exe" "Battle.net Launcher.exe" "Battle.net.exe" "launch-battlenet.sh" ;;
        ubisoft|uplay) printf '%s\n' "UbisoftConnectInstaller.exe" "UbisoftConnect.exe" "upc.exe" "launch-ubisoft.sh" "launch-uplay.sh" ;;
        heihe) printf '%s\n' "wow_installer_1.9.51.0.exe" "heyboxwow.exe" "HeyboxWow.exe" "黑盒工坊.exe" "HeiHe.exe" "launch-heihe.sh" ;;
        hmcl) printf '%s\n' "HMCL.jar" "launch-hmcl.sh" ;;
    esac
}

find_launcher_artwork_ids() {
    local target="$1" shortcut_file="$2" launcher_exe="$3" basename
    local -a match_args=(--name "$LAUNCHER_NAME" --exe "$launcher_exe")

    while IFS= read -r basename; do
        [ -n "$basename" ] || continue
        match_args+=(--exe-basename "$basename")
    done < <(launcher_steam_exe_basenames "$target")
    python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" \
        find-artwork-ids "${match_args[@]}" 2>/dev/null || {
        echo "未找到唯一的 $LAUNCHER_NAME Steam 条目，请保留一个该启动器条目后重试。" >&2
        return 1
    }
}

remove_launcher_desktop_file() {
    local file="$1"

    [ -f "$file" ] && [ ! -L "$file" ] || return 0
    grep -Fqx 'X-Zhoukeer-Managed=true' "$file" || return 0
    rm -f -- "$file" || return 1
}

uninstall_launcher() {
    local target="$1" steam_root shortcut_file desktop_name
    local display_target="$target"
    local -a remove_args=()
    local basename

    detect_platform
    if [ "$IS_STEAMOS" -ne 1 ] && [ "$IS_BAZZITE" -ne 1 ]; then
        echo "游戏启动器卸载仅支持 SteamOS 或 Bazzite。"
        return 1
    fi
    launcher_details "$target" || return 1
    confirm_launcher_uninstall "$LAUNCHER_NAME" || { echo "已取消卸载。"; return 0; }

    steam_root="$(find_steam_root 2>/dev/null || true)"
    if [ -n "$steam_root" ]; then
        shortcut_file="$(find_shortcut_file "$steam_root" 2>/dev/null || true)"
        if [ -n "$shortcut_file" ]; then
            stop_steam_for_vdf || true
            while IFS= read -r basename; do
                remove_args+=(--exe-basename "$basename")
            done < <(launcher_steam_exe_basenames "$target")
            python3 "$STEAM_SHORTCUT_HELPER" --shortcut-file "$shortcut_file" remove \
                "${remove_args[@]}" >/dev/null || true
            start_steam || true
        fi
    fi

    case "$target" in
        epic) desktop_name="Epic Games 启动器" ;;
        battlenet) desktop_name="战网启动器" ;;
        ubisoft|uplay) desktop_name="育碧" ;;
        heihe) desktop_name="黑盒工坊" ;;
        hmcl) desktop_name="HMCL 启动器" ;;
    esac
    remove_launcher_desktop_file "$HOME/Desktop/$desktop_name.desktop" || return 1
    case "$target" in
        ubisoft|uplay)
            remove_launcher_desktop_file "$HOME/Desktop/Ubisoft Connect（Uplay）.desktop" || return 1
            remove_launcher_desktop_file "$HOME/Desktop/育碧服务.desktop" || return 1
            ;;
        battlenet)
            remove_legacy_battlenet_desktop_installer || true
            ;;
    esac
    rm -rf -- "$APP_DIR/game-launchers/$target" || return 1

    echo "$LAUNCHER_NAME 已从 Steam 库和桌面移除。"
    [ "$display_target" = "uplay" ] && display_target="ubisoft"
    echo "游戏、账号与下载文件保留在 $LAUNCHER_BASE/$display_target/drive_c。"
    log "$LAUNCHER_NAME 已卸载"
}

repair_launcher_artwork() {
    local target="$1"
    local steam_root shortcut_file launcher_exe drive_c artwork_ids
    local app_id artwork_alt_app_id game_id

    detect_platform
    if [ "$IS_STEAMOS" -ne 1 ] && [ "$IS_BAZZITE" -ne 1 ]; then
        echo "封面修复仅支持 SteamOS 或 Bazzite。"
        return 1
    fi
    [ "$target" = "uplay" ] && target="ubisoft"
    launcher_details "$target" || return 1
    steam_root="$(find_steam_root)" || return 1
    shortcut_file="$(find_shortcut_file "$steam_root")" || return 1
    if [ "$target" = "heihe" ]; then
        drive_c="$(find_battle_platform_drive_c "$steam_root" || true)"
    else
        drive_c="$(launcher_drive_c "$target")"
    fi
    launcher_exe="$(find_launcher_in_drive "$drive_c" 2>/dev/null || \
        find_installed_launcher "$steam_root" || true)"
    [ -n "$launcher_exe" ] || {
        echo "未找到 $LAUNCHER_NAME 主程序，无法修复封面。"
        return 1
    }
    artwork_ids="$(find_launcher_artwork_ids "$target" "$shortcut_file" "$launcher_exe")" || return 1
    read -r app_id artwork_alt_app_id game_id <<< "$artwork_ids"
    case "$app_id:$artwork_alt_app_id:$game_id" in
        *[!0-9:]*|::*|*::*|*::)
            echo "$LAUNCHER_NAME 的 Steam 编号解析失败，未改动封面。"
            return 1
            ;;
    esac

    echo "正在重写 $LAUNCHER_NAME 的 Steam 库封面..."
    stop_steam_for_vdf || {
        echo "Steam 未能安全退出，请关闭游戏后重试。"
        return 1
    }
    install_launcher_steam_artwork "$target" "$shortcut_file" \
        "$app_id" "$artwork_alt_app_id" "$game_id" || {
        start_steam || true
        echo "$LAUNCHER_NAME 封面写入失败，Steam 已重新启动；可稍后重试。"
        return 1
    }
    start_steam || true
    echo "$LAUNCHER_NAME 封面已重新写入，Steam 重启后生效。"
    echo "修复不依赖 Decky；若仍显示旧封面，请完全退出 Steam 后再进入游戏模式。"
    log "$LAUNCHER_NAME 封面已重新写入"
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    case "${1:-}" in
        epic|battlenet|ubisoft|uplay|heihe) install_launcher "$1" ;;
        hmcl) install_hmcl_launcher ;;
        uninstall)
            [ -n "${2:-}" ] || { echo "用法: $0 uninstall 目标"; exit 1; }
            uninstall_launcher "$2"
            ;;
        apply-artwork)
            [ -n "${2:-}" ] || { echo "用法: $0 apply-artwork 目标"; exit 1; }
            repair_launcher_artwork "$2"
            ;;
        *) echo "用法: $0 {epic|battlenet|ubisoft|heihe|hmcl|uninstall 目标|apply-artwork 目标}"; exit 1 ;;
    esac
fi
