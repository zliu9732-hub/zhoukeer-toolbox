#!/bin/bash

set -u

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 直接在 Konsole 中运行 main.sh 时，自动转入专用主题窗口。
# launch.sh 会设置标记，避免新窗口再次重启形成循环。
if [ "${ZHOUKEER_LAUNCHED:-0}" != "1" ] && \
    [ -x "$PROJECT_ROOT/launch.sh" ] && \
    command -v konsole >/dev/null 2>&1; then
    exec bash "$PROJECT_ROOT/launch.sh"
fi

# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/env.sh"
# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/ui.sh"
# shellcheck disable=SC1091
source "$PROJECT_ROOT/core/logger.sh"

ensure_runtime_dirs

# V4 默认就是纯触控界面。不再提供数字或字母菜单，避免键盘和触屏事件冲突。
case "${1:-}" in
    ""|--touch) ;;
    --gui) exec bash "$PROJECT_ROOT/core/gui.sh" ;;
    *) echo "请从桌面的“周克儿工具箱”图标启动。"; exit 1 ;;
esac

enable_mouse_tracking
trap 'disable_mouse_tracking' EXIT INT TERM

NEXT_CATEGORY="home"

# Decky 官方插件的中文短说明。触控界面每页仅显示 5 个，避免小屏幕按钮拥挤。
DECKY_OFFICIAL_PLUGIN_NAMES=(
    "CSS Loader" "vibrantDeck" "Animation Changer" "Audio Loader" "SteamGridDB"
    "PowerTools" "Storage Cleaner" "AutoFlatpaks" "Bluetooth" "ProtonDB Badges"
    "Deck Settings" "HLTB for Deck" "PlayCount" "TabMaster"
    "Wine Cellar" "Pause Games" "Controller Tools" "Volume Mixer" "Battery Tracker"
    "PlayTime" "Free Loader" "DeckMTP" "MangoPeel"
)
DECKY_OFFICIAL_PLUGIN_DESCRIPTIONS=(
    "自定义界面样式" "调整界面配色" "更换开机动画" "更换系统音效" "自动补游戏封面"
    "性能与功耗控制" "清理游戏缓存" "自动更新应用" "管理蓝牙设备" "显示兼容性评分"
    "更多 Deck 设置" "显示通关时长" "记录游玩次数" "整理游戏库标签"
    "管理 Wine 与 Proton" "后台自动暂停游戏" "手柄辅助工具" "分应用调节音量" "查看电池状态"
    "记录游戏时长" "下载功能扩展" "USB 文件传输" "优化 Steam 界面"
)
DECKY_TOUCH_PAGE_SIZE=5

pause_menu() {
    echo ""
    echo "请点击窗口任意位置返回工具箱"
    enable_mouse_tracking
    read_touch_click || true
}

run_action() {
    local status
    local title="$1"
    shift

    disable_mouse_tracking
    print_header
    print_section_title "$title"
    echo ""
    "$@"
    status=$?

    # 自更新会原子替换整个安装目录；父菜单必须主动进入新目录。
    if ! cd "$PROJECT_ROOT" 2>/dev/null; then
        cd "$HOME" 2>/dev/null || true
    fi

    if [ "$status" -eq 0 ]; then
        echo ""
        echo "✓ 操作完成"
    else
        echo ""
        echo "✗ 操作未完成，请查看上方提示"
    fi
    pause_menu
}

confirm_and_run() {
    local title="$1"
    local message="$2"
    local choice
    shift 2

    draw_category_frame "" "$title" "$message"
    ui_panel_line 8 '\033[1;38;5;220m' "请确认是否继续这项操作"
    ui_touch_button 10 '\033[1;30;48;5;114m' "继续执行" "已授权工具箱完成该操作"
    ui_touch_button 15 '\033[1;97;48;5;160m' "返回主菜单" "不做任何更改"
    ui_prompt
    choice="$(read_touch_menu right:10-11:yes right:15-16:no)"
    if apply_navigation "$choice"; then
        return 0
    fi
    if [ "$choice" = "yes" ]; then
        run_action "$title" env ZHOUKEER_AUTO_CONFIRM=1 "$@"
    fi
}

show_disclaimer() {
    local choice

    while true; do
        # 免责声明独占整个窗口，避免侧栏和长句把确认按钮挤出可见区域。
        draw_disclaimer_frame
        ui_disclaimer_line 8 '\033[1;38;5;220m' "本脚本由 闲鱼：超级妹宝双叶 制作"
        ui_disclaimer_line 9 '\033[38;5;45m' "支持免费使用；禁止商业、销售、转卖或借此盈利"
        ui_disclaimer_line 10 '\033[38;5;45m' "下载内容均来自官方免费发布或开源项目"
        ui_disclaimer_line 11 '\033[38;5;45m' "不包含付费软件本体、破解或商业授权"
        ui_disclaimer_line 12 '\033[38;5;220m' "部分国内下载分流由作者本人的123云盘提供"
        ui_disclaimer_line 13 '\033[1;38;5;114m' "喜欢本工具，欢迎来闲鱼支持作者"
        ui_disclaimer_line 14 '\033[38;5;220m' "若有侵权，请及时联系作者删除"
        ui_disclaimer_button 15 '\033[1;38;5;114m' "知悉并开始使用" "点击即表示已阅读上述说明"
        ui_disclaimer_button 18 '\033[1;38;5;203m' "退出工具箱" "暂不使用"
        choice="$(read_menu_choice any:15-16:agree any:18-19:exit)"
        case "$choice" in
            agree) return 0 ;;
            exit) exit 0 ;;
        esac
    done
}

read_touch_menu() {
    read_menu_choice \
        left:2-3:nav-init \
        left:4-5:nav-software \
        left:6-7:nav-remote \
        left:8-9:nav-plugins \
        left:10-11:nav-settings \
        left:12-13:nav-dual \
        left:14-15:nav-optimize \
        left:16-17:nav-guides \
        left:18-19:nav-changelog \
        left:20-21:nav-update \
        left:22-23:nav-exit \
        "$@"
}

apply_navigation() {
    case "$1" in
        nav-init) NEXT_CATEGORY="init" ;;
        nav-software) NEXT_CATEGORY="software" ;;
        nav-remote) NEXT_CATEGORY="remote" ;;
        nav-plugins) NEXT_CATEGORY="plugins" ;;
        nav-settings) NEXT_CATEGORY="settings" ;;
        nav-dual) NEXT_CATEGORY="dual" ;;
        nav-optimize) NEXT_CATEGORY="optimize" ;;
        nav-guides) NEXT_CATEGORY="guides" ;;
        nav-changelog) NEXT_CATEGORY="changelog" ;;
        nav-update) NEXT_CATEGORY="update" ;;
        nav-exit) NEXT_CATEGORY="exit" ;;
        *) return 1 ;;
    esac
    return 0
}

common_software_menu() {
    local choice

    while true; do
        draw_category_frame software "常用软件" "Linux 软件与 Windows 游戏启动器集中安装"
        ui_touch_button 5 '\033[1;97;48;5;24m' "微信" "安装或修复微信，同步创建桌面快捷方式"
        ui_touch_button 8 '\033[1;97;48;5;24m' "QQ" "安装或修复 QQ，同步创建桌面快捷方式"
        ui_touch_button 11 '\033[1;97;48;5;24m' "Firefox 浏览器" "官方 Flathub 安装，支持自动更新"
        ui_touch_button 14 '\033[1;97;48;5;24m' "Epic Games 启动器" "自动兼容安装并入库，完成后直接启动"
        ui_touch_button 17 '\033[1;97;48;5;24m' "战网启动器" "自动兼容安装并入库，完成后直接启动"
        ui_touch_button 20 '\033[1;97;48;5;24m' "GE-Proton 兼容层" "安装到 Steam 兼容工具目录，无需管理员权限"
        ui_touch_button 22 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:5-6:wechat right:8-9:qq right:11-12:browser right:14-15:epic right:17-18:battlenet right:20-21:ge-proton right:22-23:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            wechat) confirm_and_run "安装微信" "腾讯官网AppImage；失败时保留原有版本" bash "$PROJECT_ROOT/modules/software.sh" wechat ;;
            qq) confirm_and_run "安装QQ" "通过上海交大与中科大 Flathub 国内缓存安装；完成后自动创建桌面图标" bash "$PROJECT_ROOT/modules/software.sh" qq ;;
            browser) confirm_and_run "安装Firefox浏览器" "完整包安装；失败时保留原有版本" bash "$PROJECT_ROOT/modules/software.sh" browser ;;
            epic) launcher_install_touch_guide epic ;;
            battlenet) launcher_install_touch_guide battlenet ;;
            ge-proton) confirm_and_run "安装GE-Proton兼容层" "安装到Steam compatibilitytools.d目录；完成后需要重启Steam" bash "$PROJECT_ROOT/modules/ge_proton.sh" install ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "software" ] || return 0
    done
}

launcher_install_touch_guide() {
    local target="$1"
    local title
    local choice

    case "$target" in
        epic) title="Epic Games 启动器" ;;
        battlenet) title="战网启动器" ;;
        *) return 1 ;;
    esac

    draw_category_frame software "$title 一键安装" "兼容层选择、安装前缀和 Steam 入库由工具箱处理"
    ui_panel_line 7 '\033[1;38;5;114m' "① 自动下载官方 Windows 安装程序"
    ui_panel_line 9 '\033[1;38;5;45m' "② 自动选择现有 GE-Proton / PE；缺少时自动安装 GE-Proton"
    ui_panel_line 11 '\033[1;38;5;220m' "③ 弹出官方安装窗口后，只需按官方向导点击安装"
    ui_panel_line 13 '\033[1;38;5;45m' "④ 安装完成后自动找到主 EXE，并生成 Linux 启动包装器"
    ui_panel_line 15 '\033[1;38;5;114m' "⑤ 自动写入并重新打开 Steam，库中可直接启动"
    ui_panel_line 17 '\033[1;38;5;220m' "无需进入兼容性页面，也无需手动点安装器的“开始游戏”"
    ui_touch_button 20 '\033[1;30;48;5;114m' "开始一键安装" "仅官方安装窗口中的协议与安装按钮需本人确认"
    ui_touch_button 22 '\033[1;97;48;5;238m' "返回常用软件" "暂不安装"
    ui_prompt
    choice="$(read_touch_menu right:20-21:start right:22-23:software)"
    if apply_navigation "$choice"; then return 0; fi
    case "$choice" in
        start) run_action "安装 $title 并自动入库" env ZHOUKEER_AUTO_CONFIRM=1 bash "$PROJECT_ROOT/modules/game_launchers.sh" "$target" ;;
        software) NEXT_CATEGORY="software" ;;
    esac
}

remote_assistance_menu() {
    local choice

    while true; do
        draw_category_frame remote "远程协助" "安装完成后会自动在桌面创建启动图标"
        ui_touch_button 7 '\033[1;97;48;5;24m' "下载 RustDesk" "123云盘国内直链；无需系统权限"
        ui_touch_button 11 '\033[1;97;48;5;24m' "查看设置步骤并安装 ToDesk" "需先开启开发者模式和旧版 X11 桌面模式"
        ui_touch_button 17 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:7-8:rustdesk right:11-12:todesk right:17-18:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            rustdesk) confirm_and_run "下载 RustDesk" "从123云盘国内直链安装，不会写入或修改你的 RustDesk 服务器配置" bash "$PROJECT_ROOT/modules/software.sh" rustdesk ;;
            todesk) todesk_preflight ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "remote" ] || return 0
    done
}

todesk_preflight() {
    local choice

    while true; do
        draw_category_frame remote "ToDesk 使用前设置" "请先切回 Steam 游戏模式，按顺序完成全部步骤"
        ui_panel_line 7 '\033[1;38;5;220m' "① 按 Steam 键 → 设置 → 系统"
        ui_panel_line 9 '\033[1;38;5;45m' "② 开启“启用开发者模式”"
        ui_panel_line 11 '\033[1;38;5;45m' "③ 设置侧栏进入“开发者” → 找到“杂项”"
        ui_panel_line 13 '\033[1;38;5;45m' "④ 开启“使用旧版 X11 桌面模式”"
        ui_panel_line 15 '\033[1;38;5;220m' "⑤ 重新进入桌面模式，再安装并启动 ToDesk"
        ui_touch_button 16 '\033[1;30;48;5;114m' "以上设置已完成，继续安装" "点击即确认两项开关均已开启"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回远程协助" "暂不安装"
        choice="$(read_touch_menu right:16-17:continue right:18-19:back)"
        if apply_navigation "$choice"; then return 0; fi
        case "$choice" in
            continue)
                confirm_and_run "ToDesk远程工具" "将自动使用桌面管理员密码.txt验证；缺失时由系统询问" bash "$PROJECT_ROOT/modules/todesk.sh" --install
                return 0
                ;;
            back) NEXT_CATEGORY="remote"; return 0 ;;
        esac
    done
}

new_machine_preflight() {
    local choice

    while true; do
        draw_category_frame init "新机初始化前准备" "初始化包含 ToDesk，请先在 Steam 游戏模式完成设置"
        ui_panel_line 7 '\033[1;38;5;220m' "① Steam 键 → 设置 → 系统 → 启用开发者模式"
        ui_panel_line 9 '\033[1;38;5;45m' "② 设置侧栏 → 开发者 → 杂项"
        ui_panel_line 11 '\033[1;38;5;45m' "③ 开启“使用旧版 X11 桌面模式”"
        ui_panel_line 13 '\033[1;38;5;220m' "④ 重新进入桌面模式，再开始初始化"
        ui_panel_line 14 '\033[1;38;5;45m' "继续后将安装国内源、常用软件、Decky 和 ToDesk"
        ui_touch_button 16 '\033[1;30;48;5;114m' "设置已完成，开始新机初始化" "点击即确认已开启开发者模式和旧版 X11"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回首页" "暂不初始化"
        choice="$(read_touch_menu right:16-17:start right:18-19:home)"
        if apply_navigation "$choice"; then return 0; fi
        case "$choice" in
            start)
                run_action "一键新机初始化" env ZHOUKEER_AUTO_CONFIRM=1 bash "$PROJECT_ROOT/modules/new_machine.sh"
                NEXT_CATEGORY="home"
                return 0
                ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
    done
}

steam_touch_menu() {
    local choice

    while true; do
        draw_category_frame optimize "SteamOS 掌机优化" "安全处理 Steam 缓存，并查看性能建议"
        ui_touch_button 8 '\033[1;97;48;5;24m' "清理 Steam 下载缓存" "删除未完成的下载残留"
        ui_touch_button 11 '\033[1;97;48;5;24m' "查看性能模式建议" "只读检查，不修改系统"
        ui_touch_button 14 '\033[1;97;48;5;24m' "清理着色器缓存" "释放空间，游戏会在下次启动时重建"
        ui_touch_button 17 '\033[1;97;48;5;238m' "返回系统优化" "查看其他优化功能"
        ui_prompt
        choice="$(read_touch_menu right:8-9:download-cache right:11-12:performance right:14-15:shader-cache right:17-18:back)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            download-cache) confirm_and_run "清理下载缓存" "清理后未完成的 Steam 下载需要重新开始" bash "$PROJECT_ROOT/modules/steam.sh" download-cache ;;
            performance) run_action "性能模式建议" bash "$PROJECT_ROOT/modules/steam.sh" performance ;;
            shader-cache) confirm_and_run "清理着色器缓存" "清理后游戏着色器需要重新生成" bash "$PROJECT_ROOT/modules/steam.sh" shader-cache ;;
            back) return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "optimize" ] || return 0
    done
}

clean_touch_menu() {
    local choice

    while true; do
        draw_category_frame optimize "系统清理" "只处理可重建的缓存，不删除游戏和个人文件"
        ui_touch_button 8 '\033[1;97;48;5;24m' "清理 Steam 下载残留" "释放未完成下载占用的空间"
        ui_touch_button 11 '\033[1;97;48;5;24m' "清理 Steam 着色器缓存" "下次运行游戏时会自动重建"
        ui_touch_button 14 '\033[1;97;48;5;24m' "清理 Linux 用户缓存" "不触碰 SteamOS 只读系统分区"
        ui_touch_button 17 '\033[1;97;48;5;238m' "返回系统优化" "查看其他优化功能"
        ui_prompt
        choice="$(read_touch_menu right:8-9:download-cache right:11-12:shader-cache right:14-15:user-cache right:17-18:back)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            download-cache) confirm_and_run "清理下载残留" "将删除 Steam 未完成的下载残留" bash "$PROJECT_ROOT/modules/clean.sh" download-cache ;;
            shader-cache) confirm_and_run "清理着色器缓存" "着色器会在下次运行游戏时重新生成" bash "$PROJECT_ROOT/modules/clean.sh" shader-cache ;;
            user-cache) confirm_and_run "清理用户缓存" "部分应用会在下次启动时重新生成缓存" bash "$PROJECT_ROOT/modules/clean.sh" user-cache ;;
            back) return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "optimize" ] || return 0
    done
}

plugin_store_menu() {
    local choice

    while true; do
        draw_category_frame plugins "插件商城" "Decky内置安装器、28款插件与商店最新版"
        ui_touch_button 6 '\033[1;97;48;5;24m' "安装或更新 Decky Loader" "使用经过固定校验的国内安装源"
        ui_touch_button 8 '\033[1;97;48;5;24m' "一键安装常用功能插件" "小黄鸭、FSR4、CheatDeck 一次装好"
        ui_touch_button 10 '\033[1;97;48;5;30m' "一键安装当前列表全部插件" "3款独立功能 + 25款精选插件，共28款"
        ui_touch_button 12 '\033[1;97;48;5;24m' "浏览官方插件（分页）" "每页 5 个插件，均附中文功能说明"
        ui_touch_button 14 '\033[1;97;48;5;24m' "安装周克儿汉化（修复版）" "持续扫描已知文案，不修改原插件文件"
        ui_touch_button 16 '\033[1;97;48;5;124m' "一键清空已装插件" "删除插件根目录全部内容，不删除 Decky 本体"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:6-7:install right:8-9:features right:10-11:all right:12-13:browse right:14-15:localizer right:16-17:uninstall right:18-19:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            install) confirm_and_run "Decky Loader插件商城" "安装前请先回游戏模式：Steam键→设置→系统→开启“启用开发者模式”；再到开发者菜单开启“CEF远程调试”。完成后回桌面模式继续。将使用国内镜像安装器，执行前会校验固定 SHA256" bash "$PROJECT_ROOT/modules/plugin_store.sh" store ;;
            features) confirm_and_run "安装常用功能插件" "安装前请先在游戏模式开启“启用开发者模式”和“CEF远程调试”。将依次安装小黄鸭、FSR4 和 CheatDeck；单项失败不会覆盖旧版本" bash "$PROJECT_ROOT/modules/plugin_store.sh" features ;;
            all) confirm_and_run "安装当前列表全部插件" "安装前请先在游戏模式开启“启用开发者模式”和“CEF远程调试”。将安装 Decky、3款独立功能插件和25款精选插件，其中包括 SimpleDeckyTDP 与 Unifideck；商店插件仍需在Steam界面确认" bash "$PROJECT_ROOT/modules/plugin_store.sh" all ;;
            browse) plugin_official_touch_pages ;;
            localizer) confirm_and_run "安装周克儿汉化" "这是独立的 Decky 汉化层修复版：不会改写原插件文件，会持续处理已知可见文案。安装后请回游戏模式，在 Decky 菜单中启用。是否继续？" bash "$PROJECT_ROOT/modules/plugin_store.sh" localizer ;;
            uninstall) confirm_and_run "清空已装 Decky 插件" "将删除 homebrew/plugins 根目录内的全部插件文件和插件设置；Decky Loader 本体不会被删除。是否继续？" bash "$PROJECT_ROOT/modules/plugin_store.sh" uninstall ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "plugins" ] || return 0
    done
}

plugin_store_preflight() {
    local choice

    while true; do
        draw_category_frame plugins "插件商城使用前设置" "Decky 插件安装前，请先在游戏模式完成以下两项设置"
        ui_panel_line 7 '\033[1;38;5;220m' "① 按 Steam 键 → 设置 → 系统"
        ui_panel_line 9 '\033[1;38;5;45m' "② 开启“启用开发者模式”"
        ui_panel_line 11 '\033[1;38;5;45m' "③ 在设置侧栏进入“开发者”菜单"
        ui_panel_line 13 '\033[1;38;5;45m' "④ 开启“CEF 远程调试”"
        ui_panel_line 15 '\033[1;38;5;220m' "⑤ 完成后回到桌面模式，再打开插件商城"
        ui_touch_button 16 '\033[1;30;48;5;114m' "以上设置已完成，进入插件商城" "Decky 官方插件安装需要这两项设置"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回首页" "暂不进入插件商城"
        choice="$(read_touch_menu right:16-17:continue right:18-19:home)"
        if apply_navigation "$choice"; then return 0; fi
        case "$choice" in
            continue) NEXT_CATEGORY="plugins-menu"; return 0 ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
    done
}

plugin_official_touch_pages() {
    local choice
    local page=0
    local total="${#DECKY_OFFICIAL_PLUGIN_NAMES[@]}"
    local total_pages=$(((total + DECKY_TOUCH_PAGE_SIZE - 1) / DECKY_TOUCH_PAGE_SIZE))
    local start
    local index
    local slot
    local row

    while true; do
        draw_category_frame plugins "官方插件（第 $((page + 1)) / $total_pages 页）" "点击插件即可安装；每项均来自 Decky 官方商店"
        start=$((page * DECKY_TOUCH_PAGE_SIZE))
        for slot in 0 1 2 3 4; do
            index=$((start + slot))
            [ "$index" -lt "$total" ] || break
            row=$((6 + slot * 2))
            ui_touch_button "$row" '\033[1;97;48;5;24m' \
                "${DECKY_OFFICIAL_PLUGIN_NAMES[$index]}" \
                "${DECKY_OFFICIAL_PLUGIN_DESCRIPTIONS[$index]}"
        done
        if [ "$page" -gt 0 ]; then
            ui_touch_button 16 '\033[1;97;48;5;238m' "上一页" "查看前一组插件"
        else
            ui_touch_button 16 '\033[1;97;48;5;238m' "返回插件商城" "查看一键安装功能"
        fi
        if [ "$page" -lt $((total_pages - 1)) ]; then
            ui_touch_button 18 '\033[1;97;48;5;30m' "下一页" "继续查看更多插件"
        else
            ui_touch_button 18 '\033[1;97;48;5;238m' "返回插件商城" "已是最后一页"
        fi
        ui_prompt
        choice="$(read_touch_menu \
            right:6-7:plugin-$((start)) \
            right:8-9:plugin-$((start + 1)) \
            right:10-11:plugin-$((start + 2)) \
            right:12-13:plugin-$((start + 3)) \
            right:14-15:plugin-$((start + 4)) \
            right:16-17:previous \
            right:18-19:next)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            plugin-*)
                index="${choice#plugin-}"
                if [ "$index" -lt "$total" ]; then
                    confirm_and_run "${DECKY_OFFICIAL_PLUGIN_NAMES[$index]}" \
                        "${DECKY_OFFICIAL_PLUGIN_DESCRIPTIONS[$index]}；安装前请先在游戏模式开启“启用开发者模式”和“CEF远程调试”。将由 Decky 官方商店安装" \
                        env ZHOUKEER_AUTO_CONFIRM=1 \
                        bash "$PROJECT_ROOT/modules/decky_bundle.sh" plugin "${DECKY_OFFICIAL_PLUGIN_NAMES[$index]}"
                fi
                ;;
            previous)
                if [ "$page" -gt 0 ]; then
                    page=$((page - 1))
                else
                    return 0
                fi
                ;;
            next)
                if [ "$page" -lt $((total_pages - 1)) ]; then
                    page=$((page + 1))
                else
                    return 0
                fi
                ;;
        esac
        [ "$NEXT_CATEGORY" = "plugins" ] || return 0
    done
}

dual_system_menu() {
    local choice

    while true; do
        draw_category_frame dual "双系统设置" "互通盘挂载与已存在的 systemd-boot 菜单设置"
        ui_touch_button 7 '\033[1;97;48;5;24m' "一键挂载互通盘" "仅自动挂载唯一的未挂载 NTFS/exFAT 分区"
        ui_touch_button 9 '\033[1;97;48;5;30m' "保护双系统互通盘" "只读挂载，防止 SteamOS 下误写入或误删除"
        ui_touch_button 11 '\033[1;97;48;5;24m' "恢复互通盘写入" "重新以可写模式挂载互通盘"
        ui_touch_button 13 '\033[1;97;48;5;30m' "添加 Steam Deck 双引导" "启用启动菜单，默认等待 5 秒"
        ui_touch_button 15 '\033[1;97;48;5;160m' "删除 Steam Deck 双引导" "仅将菜单等待时间改为 0 秒，不删除系统"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:7-8:mount right:9-10:protect right:11-12:unprotect right:13-14:add right:15-16:remove right:18-19:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            mount)
                confirm_and_run "挂载互通盘" "将自动识别唯一的未挂载 NTFS/exFAT 分区并创建快捷入口" \
                    bash "$PROJECT_ROOT/modules/dual_system.sh" mount
                ;;
            protect)
                confirm_and_run "保护双系统互通盘" "会重新以只读模式挂载互通盘；SteamOS 下将无法写入或删除该盘文件" \
                    bash "$PROJECT_ROOT/modules/dual_system.sh" protect
                ;;
            unprotect)
                confirm_and_run "恢复互通盘写入" "会重新以可写模式挂载互通盘，恢复 SteamOS 下的正常读写" \
                    bash "$PROJECT_ROOT/modules/dual_system.sh" unprotect
                ;;
            add)
                confirm_and_run "添加 Steam Deck 双引导" "只启用已有 systemd-boot 菜单并备份配置；不会安装或重写 EFI 引导程序" \
                    bash "$PROJECT_ROOT/modules/dual_system.sh" add
                ;;
            remove)
                confirm_and_run "删除 Steam Deck 双引导" "仅把引导菜单等待时间设置为 0 秒；不会删除 SteamOS、Windows 或启动项" \
                    bash "$PROJECT_ROOT/modules/dual_system.sh" remove
                ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "dual" ] || return 0
    done
}

system_settings_menu() {
    local choice

    while true; do
        draw_category_frame settings "系统设置" "下载源、Steam加速、系统密码和一键体检"
        ui_touch_button 7 '\033[1;97;48;5;24m' "添加国内下载源" "自动测速后优先使用更快的用户级 Flatpak 源"
        ui_touch_button 9 '\033[1;97;48;5;24m' "Steamcommunity 302" "一键安装并加速 Steam 与 GitHub"
        ui_touch_button 11 '\033[1;97;48;5;24m' "设置系统密码" "明文保存到桌面；同一用户运行的软件也能读取"
        ui_touch_button 13 '\033[1;97;48;5;24m' "修改系统密码" "同步更新明文记录；同一用户软件也能读取"
        ui_touch_button 15 '\033[1;97;48;5;24m' "一键体检" "检查空间、网络、Steam、Decky 和常用软件；不修改系统"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:7-8:source right:9-10:accelerator right:11-12:set-password right:13-14:change-password right:15-16:info right:18-19:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            source) confirm_and_run "添加国内下载源" "只添加用户级 Flatpak 国内缓存，不修改只读分区" bash "$PROJECT_ROOT/modules/domestic_source.sh" enable ;;
            accelerator) steam_accelerator_touch_menu ;;
            set-password) confirm_and_run "设置系统密码" "新密码将明文保存到桌面管理员密码.txt；所有以当前用户身份运行的软件都可能读取" bash "$PROJECT_ROOT/modules/password.sh" set ;;
            change-password) confirm_and_run "修改系统密码" "将读取旧记录并明文保存新密码；所有以当前用户身份运行的软件都可能读取" bash "$PROJECT_ROOT/modules/password.sh" change ;;
            info) run_action "一键体检" bash "$PROJECT_ROOT/core/detect.sh" --health ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "settings" ] || return 0
    done
}

steam_accelerator_touch_menu() {
    local choice

    while true; do
        draw_category_frame settings "Steamcommunity 302" "官方 Linux AMD64 固定版本，内置 Steam + GitHub 加速"
        ui_touch_button 6 '\033[1;97;48;5;24m' "安装或更新" "下载并校验官方程序与内置规则"
        ui_touch_button 9 '\033[1;97;48;5;30m' "一键开启加速" "自动准备并启动 Steam + GitHub 后台加速"
        ui_touch_button 12 '\033[1;97;48;5;24m' "查看运行状态" "查看版本、内置进程和后台服务状态"
        ui_touch_button 15 '\033[1;97;48;5;160m' "安全卸载" "先停止工具箱进程，再删除程序文件"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回系统设置" "查看其他系统功能"
        ui_prompt
        choice="$(read_touch_menu right:6-7:install right:9-10:start right:12-13:status right:15-16:uninstall right:18-19:settings)"
        if apply_navigation "$choice"; then return 0; fi
        case "$choice" in
            install)
                confirm_and_run "Steamcommunity 302" "下载官方程序并生成 Steam + GitHub 内置规则；首次开启可能请求管理员权限" bash "$PROJECT_ROOT/modules/steam_accelerator.sh" install
                ;;
            start)
                confirm_and_run "开启 Steamcommunity 302 加速" "工具箱会自动安装（如缺失）并启动官方 CLI，只接管 Steam 与 GitHub" bash "$PROJECT_ROOT/modules/steam_accelerator.sh" enable
                ;;
            status) run_action "Steamcommunity 302 状态" bash "$PROJECT_ROOT/modules/steam_accelerator.sh" status ;;
            uninstall)
                confirm_and_run "卸载 Steamcommunity 302" "会停止工具箱启动的进程；官方 systemd、hosts、DNS 和证书需按官方程序另行处理" bash "$PROJECT_ROOT/modules/steam_accelerator.sh" uninstall
                ;;
            settings) NEXT_CATEGORY="settings"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "settings" ] || return 0
    done
}

system_optimization_menu() {
    local choice

    while true; do
        draw_category_frame optimize "系统优化" "缓存清理、性能建议和常见问题修复"
        ui_touch_button 7 '\033[1;97;48;5;24m' "游戏启动诊断" "检查 Steam、兼容层、空间和日志；不删除游戏文件"
        ui_touch_button 10 '\033[1;97;48;5;24m' "SteamOS 掌机优化" "下载缓存、着色器缓存和性能建议"
        ui_touch_button 13 '\033[1;97;48;5;24m' "系统清理" "安全释放用户缓存和 Steam 缓存"
        ui_touch_button 16 '\033[1;97;48;5;24m' "一键修复模式" "检测网络并处理常见下载问题"
        ui_touch_button 20 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:7-8:diagnose right:10-11:steam right:13-14:clean right:16-17:fix right:20-21:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            diagnose) run_action "游戏启动诊断" bash "$PROJECT_ROOT/modules/game_diagnose.sh" diagnose ;;
            steam) steam_touch_menu ;;
            clean) clean_touch_menu ;;
            fix) confirm_and_run "一键修复模式" "检测网络并安全清理 Steam 下载缓存" bash "$PROJECT_ROOT/modules/fixall.sh" ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "optimize" ] || return 0
    done
}

practical_guides_touch_menu() {
    local choice

    while true; do
        draw_category_frame guides "实用指南" "常见中文兼容指引、掌机说明和可导出的操作记录"
        ui_touch_button 7 '\033[1;97;48;5;24m' "中文兼容攻略卡" "启动器、Proton、手柄、反作弊、性能和空间建议"
        ui_touch_button 10 '\033[1;97;48;5;24m' "掌机常用快捷键" "键盘、触控板、扳机鼠标与回游戏模式说明"
        ui_touch_button 13 '\033[1;97;48;5;24m' "外接设备检查" "只读检查显示器和蓝牙设备状态"
        ui_touch_button 16 '\033[1;97;48;5;24m' "新手安全与操作记录" "说明高风险操作并导出最近 80 条工具箱记录"
        ui_touch_button 18 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:7-8:guides-card right:10-11:shortcuts right:13-14:peripherals right:16-17:records right:18-19:home)"
        if apply_navigation "$choice"; then return 0; fi

        case "$choice" in
            guides-card) run_action "中文兼容攻略卡" bash "$PROJECT_ROOT/modules/game_guides.sh" show ;;
            shortcuts) run_action "掌机常用快捷键" bash "$PROJECT_ROOT/modules/handheld_helper.sh" shortcuts ;;
            peripherals) run_action "外接设备检查" bash "$PROJECT_ROOT/modules/handheld_helper.sh" peripherals ;;
            records)
                run_action "新手安全说明" bash "$PROJECT_ROOT/modules/safety_center.sh" guide
                run_action "操作记录" bash "$PROJECT_ROOT/modules/safety_center.sh" records
                ;;
            home) NEXT_CATEGORY="home"; return 0 ;;
        esac
        [ "$NEXT_CATEGORY" = "guides" ] || return 0
    done
}

changelog_menu() {
    local choice
    local release_heading="当前版本"
    local line
    local in_latest_release=0
    local -a release_notes=()

    if [ -r "$PROJECT_ROOT/CHANGELOG.md" ]; then
        while IFS= read -r line; do
            case "$line" in
                "## "*)
                    if [ "$in_latest_release" -eq 1 ]; then
                        break
                    fi
                    release_heading="${line#\#\# }"
                    in_latest_release=1
                    ;;
                "- "*)
                    if [ "$in_latest_release" -eq 1 ]; then
                        release_notes+=("${line#- }")
                    fi
                    ;;
            esac
        done < "$PROJECT_ROOT/CHANGELOG.md"
    fi

    if [ -r "$PROJECT_ROOT/VERSION" ]; then
        release_heading="V$(tr -d '\r\n' < "$PROJECT_ROOT/VERSION") · ${release_heading#*— }"
    fi

    while true; do
        draw_category_frame changelog "更新日志" "$release_heading"
        ui_panel_line 7 '\033[1;38;5;114m' "✓ ${release_notes[0]:-当前版本已安装，暂无摘要}"
        ui_panel_line 10 '\033[1;38;5;45m' "✓ ${release_notes[1]:-完整改动以 CHANGELOG.md 为准}"
        ui_panel_line 13 '\033[1;38;5;220m' "完整日志随工具箱自动更新，不再显示旧版固定日期"
        ui_touch_button 17 '\033[1;97;48;5;238m' "返回首页" "查看全部功能分类"
        ui_prompt
        choice="$(read_touch_menu right:17-18:home)"
        if apply_navigation "$choice"; then return 0; fi
        [ "$choice" = "home" ] && { NEXT_CATEGORY="home"; return 0; }
    done
}

home_menu() {
    local choice

    draw_category_frame "" "欢迎使用" "全界面只需点击，无需输入任何数字或字母"
    ui_panel_line 8 '\033[1;38;5;220m' "⭐ 新机初始化：国内源、软件、Decky、ToDesk"
    ui_panel_line 9 '\033[1;38;5;45m' "💻 常用软件：微信、QQ、Firefox 浏览器"
    ui_panel_line 10 '\033[1;38;5;45m' "📡 远程协助：RustDesk、ToDesk"
    ui_panel_line 11 '\033[1;38;5;45m' "🧩 插件商城：Decky、28款插件、官方商城分页"
    ui_panel_line 12 '\033[1;38;5;45m' "⚙ 系统设置：国内源、加速器、密码、设备信息"
    ui_panel_line 13 '\033[1;38;5;45m' "💿 双系统设置：互通盘、双引导菜单"
    ui_panel_line 14 '\033[1;38;5;114m' "🚀 系统优化：缓存清理、性能建议、问题修复"
    ui_panel_line 16 '\033[1;38;5;114m' "📖 实用指南：兼容攻略、快捷键、外接设备和记录"
    ui_panel_line 17 '\033[1;38;5;114m' "📋 更新日志：查看版本改动和修复内容"
    ui_panel_line 18 '\033[1;38;5;114m' "🔄 工具箱更新：检查并更新到最新版本"
    ui_prompt
    choice="$(read_touch_menu)"
    apply_navigation "$choice" || true
}

show_disclaimer

while true; do
    case "$NEXT_CATEGORY" in
        home) home_menu ;;
        init) new_machine_preflight ;;
        software) common_software_menu ;;
        remote) remote_assistance_menu ;;
        plugins) plugin_store_preflight ;;
        plugins-menu) plugin_store_menu ;;
        settings) system_settings_menu ;;
        dual) dual_system_menu ;;
        optimize) system_optimization_menu ;;
        guides) practical_guides_touch_menu ;;
        changelog) changelog_menu ;;
        update)
            confirm_and_run "更新工具箱" "下载、校验并安全替换为最新版本" bash "$PROJECT_ROOT/update.sh"
            [ "$NEXT_CATEGORY" = "update" ] && NEXT_CATEGORY="home"
            ;;
        exit)
            log "用户退出工具箱"
            exit 0
            ;;
        *) NEXT_CATEGORY="home" ;;
    esac
done
