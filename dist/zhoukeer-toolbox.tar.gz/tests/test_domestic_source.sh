#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_ROOT="$(mktemp -d)"
BIN_DIR="$TMP_ROOT/bin"
STEAMOS_BIN_DIR="$TMP_ROOT/steamos-bin"
HOME_DIR="$TMP_ROOT/home"
STATE_DIR="$TMP_ROOT/state"

cleanup() {
    rm -rf -- "$TMP_ROOT"
}
trap cleanup EXIT

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

mkdir -p "$BIN_DIR" "$STEAMOS_BIN_DIR" "$HOME_DIR" "$STATE_DIR"

cat > "$BIN_DIR/uname" <<'EOF'
#!/bin/sh
printf 'Linux\n'
EOF

cat > "$STEAMOS_BIN_DIR/steamos-readonly" <<'EOF'
#!/bin/sh
exit 99
EOF

cat > "$BIN_DIR/curl" <<'EOF'
#!/bin/sh
state="${DOMESTIC_SOURCE_TEST_STATE:?}"
output=""
url=""
while [ "$#" -gt 0 ]; do
    case "$1" in
        --output)
            shift
            output="$1"
            ;;
        https://*)
            url="$1"
            ;;
    esac
    shift
done
printf '%s\n' "$url" >> "$state/curl-urls"
cat > "$output" <<'REPO'
[Flatpak Repo]
Title=Flathub
Url=https://dl.flathub.org/repo/
GPGKey=test-key
REPO
EOF

cat > "$BIN_DIR/flatpak" <<'EOF'
#!/bin/sh
state="${DOMESTIC_SOURCE_TEST_STATE:?}"
command="${1:-}"
[ "$#" -eq 0 ] || shift
case "$command" in
    remotes)
        case " $* " in
            *' --show-details '*)
                while IFS= read -r remote; do
                    [ -n "$remote" ] && printf '%s\thttps://example.invalid/%s\n' "$remote" "$remote"
                done < "$state/remotes"
                ;;
            *)
                [ ! -f "$state/remotes" ] || cat "$state/remotes"
                ;;
        esac
        ;;
    remote-add)
        case " $* " in
            *' --from '*) ;;
            *' --no-gpg-verify '*) ;;
            *) echo "remote-add missing verified mode" >&2; exit 1 ;;
        esac
        remote=""
        for arg in "$@"; do
            case "$arg" in
                --*) ;;
                *) remote="$arg"; break ;;
            esac
        done
        printf 'remote-add %s\n' "$*" >> "$state/commands"
        printf '%s\n' "$remote" >> "$state/remotes"
        ;;
    remote-modify)
        printf 'remote-modify %s\n' "$*" >> "$state/commands"
        ;;
    remote-delete)
        remote=""
        for arg in "$@"; do remote="$arg"; done
        printf 'remote-delete %s\n' "$*" >> "$state/commands"
        awk -v remove="$remote" '$0 != remove' "$state/remotes" > "$state/remotes.new"
        mv "$state/remotes.new" "$state/remotes"
        ;;
    remote-ls)
        printf 'remote-ls %s\n' "$*" >> "$state/commands"
        printf 'org.mozilla.firefox\n'
        ;;
    update)
        printf 'update %s\n' "$*" >> "$state/commands"
        ;;
    *)
        echo "unexpected flatpak command: $command" >&2
        exit 1
        ;;
esac
EOF

cat > "$BIN_DIR/sudo" <<'EOF'
#!/bin/sh
printf '%s\n' "$*" >> "${DOMESTIC_SOURCE_TEST_STATE:?}/sudo-calls"
exit 97
EOF

cat > "$BIN_DIR/timeout" <<'EOF'
#!/bin/sh
while [ "$#" -gt 0 ]; do
    case "$1" in
        --foreground|--preserve-status) shift ;;
        [0-9]*) shift ;;
        *) exec "$@" ;;
    esac
done
exit 0
EOF

cat > "$BIN_DIR/install" <<'EOF'
#!/bin/sh
while [ "$#" -gt 2 ]; do shift; done
cp "$1" "$2"
EOF

cat > "$BIN_DIR/locale-gen" <<'EOF'
#!/bin/sh
printf 'locale-gen\n' >> "${DOMESTIC_SOURCE_TEST_STATE:?}/commands"
EOF

cat > "$BIN_DIR/pacman" <<'EOF'
#!/bin/sh
state="${DOMESTIC_SOURCE_TEST_STATE:?}"
case "${1:-}" in
    -Q)
        shift
        for package_name in "$@"; do
            [ -f "$state/installed.$package_name" ] || exit 1
        done
        exit 0
        ;;
    -Qu)
        found_upgrade=0
        for upgrade_file in "$state"/upgrade.*; do
            [ -e "$upgrade_file" ] || continue
            package_name="${upgrade_file##*.}"
            printf '%s test-version\n' "$package_name"
            found_upgrade=1
        done
        [ "$found_upgrade" -eq 1 ] || exit 1
        exit 0
        ;;
esac
printf 'pacman %s\n' "$*" >> "$state/commands"
case " $* " in
    *' archlinuxcn-keyring '*)
        [ "${DOMESTIC_SOURCE_FAIL_PACMAN_INSTALL:-0}" != "1" ] || exit 1
        touch "$state/installed.archlinuxcn-keyring"
        ;;
esac
EOF

cat > "$BIN_DIR/pacman-key" <<'EOF'
#!/bin/sh
printf 'pacman-key %s\n' "$*" >> "${DOMESTIC_SOURCE_TEST_STATE:?}/commands"
[ "${DOMESTIC_SOURCE_FAIL_PACMAN_KEY:-0}" != "1" ]
EOF

chmod +x "$BIN_DIR"/* "$STEAMOS_BIN_DIR"/*
: > "$STATE_DIR/remotes"
: > "$STATE_DIR/commands"

run_enable() {
    PATH="$STEAMOS_BIN_DIR:$BIN_DIR:$PATH" \
        HOME="$HOME_DIR" \
        DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR" \
        ZHOUKEER_AUTO_CONFIRM=1 \
        ZHOUKEER_TEST_MODE=1 \
        ZHOUKEER_FLATHUB_CN_URL="https://mirror.test.invalid/flathub" \
        ZHOUKEER_FLATHUB_CN_FALLBACK_URL="https://fallback.test.invalid/flathub" \
        bash "$PROJECT_ROOT/modules/domestic_source.sh" enable
}

run_restore() {
    PATH="$STEAMOS_BIN_DIR:$BIN_DIR:$PATH" \
        HOME="$HOME_DIR" \
        DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR" \
        ZHOUKEER_AUTO_CONFIRM=1 \
        bash "$PROJECT_ROOT/modules/domestic_source.sh" restore
}

if PATH="$BIN_DIR:$PATH" HOME="$HOME_DIR" DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR" \
    bash "$PROJECT_ROOT/modules/domestic_source.sh" enable </dev/null >/dev/null 2>&1; then
    fail "非 SteamOS Linux 不应允许配置国内源"
fi
if PATH="$STEAMOS_BIN_DIR:$BIN_DIR:$PATH" HOME="$HOME_DIR" DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR" \
    bash "$PROJECT_ROOT/modules/domestic_source.sh" enable </dev/null >/dev/null 2>&1; then
    fail "直接调用国内源且未明确确认时不应继续"
fi
[ ! -s "$STATE_DIR/commands" ] || fail "平台或确认检查失败后仍修改了 Flatpak 源"

output="$(run_enable)"
printf '%s\n' "$output" | grep -Fq '国内下载源配置完成：flathub-cn、flathub-ustc' || \
    fail "成功输出缺少两个国内源名称"
if grep -Eq '^(update|remote-ls) ' "$STATE_DIR/commands"; then
    fail "国内源配置不应刷新或验证 Discover 应用索引"
fi
grep -Fxq 'flathub-cn' "$STATE_DIR/remotes" || fail "未添加国内缓存源"
grep -Fxq 'flathub-ustc' "$STATE_DIR/remotes" || fail "未添加国内备用缓存源"
grep -Fq 'remote-modify --user flathub-cn --url=https://mirror.test.invalid/flathub' \
    "$STATE_DIR/commands" || fail "国内缓存地址配置错误"
grep -Fq 'remote-modify --user flathub-ustc --url=https://fallback.test.invalid/flathub' \
    "$STATE_DIR/commands" || fail "国内备用缓存地址配置错误"
grep -Fq 'remote-add --user --if-not-exists --no-gpg-verify flathub-cn https://mirror.test.invalid/flathub' \
    "$STATE_DIR/commands" || fail "上海交大用户级远程没有直接使用已确认的国内地址"
grep -Fq 'remote-add --user --if-not-exists --no-gpg-verify flathub-ustc https://fallback.test.invalid/flathub' \
    "$STATE_DIR/commands" || fail "中科大用户级远程没有直接使用已确认的国内地址"
[ ! -e "$STATE_DIR/sudo-calls" ] || fail "用户级国内源配置不应调用 sudo"
grep -Fq -- '--appstream' "$PROJECT_ROOT/modules/domestic_source.sh" && \
    fail "国内源模块不应包含 AppStream 强制刷新"
grep -Fq 'verify_domestic_flatpak_remote' "$PROJECT_ROOT/modules/domestic_source.sh" && \
    fail "国内源模块不应保留应用索引验证"
for command_text in 'packages_installed_without_known_upgrades' 'base_system_components_ready' 'archlinuxcn_keyring_ready' 'configure_archlinuxcn_with_fallback' 'pacman-key --init' 'pacman-key --populate archlinux' 'pacman -Syu --needed --noconfirm git flatpak' 'pacman -S --needed --noconfirm archlinux-keyring' 'pacman -Syu --needed --noconfirm archlinuxcn-keyring' 'pacman-key --populate archlinuxcn' 'locale-gen' 'steamos-readonly disable' 'steamos-readonly enable'; do
    grep -Fq "$command_text" "$PROJECT_ROOT/modules/domestic_source.sh" || \
        fail "完整国内源初始化缺少：$command_text"
done
(
    PATH="$BIN_DIR:$PATH"
    HOME="$HOME_DIR"
    DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR"
    export PATH HOME DOMESTIC_SOURCE_TEST_STATE
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/domestic_source.sh"

    touch "$STATE_DIR/installed.git" "$STATE_DIR/installed.flatpak" \
        "$STATE_DIR/installed.archlinuxcn-keyring"
    base_system_components_ready || fail "已安装基础组件未被识别"
    [ ! -e "$STATE_DIR/installed.archlinux-keyring" ] || \
        fail "基础组件模拟不应依赖 archlinux-keyring 包名"
    archlinuxcn_keyring_ready || fail "已安装 archlinuxcn 密钥环未被识别"

    touch "$STATE_DIR/upgrade.git"
    if base_system_components_ready; then
        fail "git 存在待更新版本时仍被识别为无需更新"
    fi
    rm -f "$STATE_DIR/upgrade.git"

    rm -f "$STATE_DIR/installed.flatpak"
    if base_system_components_ready; then
        fail "缺少 Flatpak 时仍被识别为基础组件完整"
    fi
)
for repo_url in \
    'https://mirror.sjtu.edu.cn/archlinux-cn/\$arch' \
    'https://mirrors.ustc.edu.cn/archlinuxcn/\$arch' \
    'https://repo.archlinuxcn.org/\$arch'; do
    grep -Fq "$repo_url" "$PROJECT_ROOT/modules/domestic_source.sh" || \
        fail "缺少 archlinuxcn 镜像回退：$repo_url"
done
grep -Fq '初始化国内源并检测系统组件' "$PROJECT_ROOT/modules/new_machine.sh" || \
    fail "新机初始化没有运行国内源与系统组件检测"

# 配置文件测试只操作临时目录，toolbox_sudo 被替换为直接调用假 install/locale-gen。
SYSTEM_DIR="$TMP_ROOT/system"
mkdir -p "$SYSTEM_DIR"
cat > "$SYSTEM_DIR/pacman.conf" <<'EOF'
[options]
Architecture = auto
EOF
cat > "$SYSTEM_DIR/locale.gen" <<'EOF'
#en_US.UTF-8 UTF-8
#zh_CN.UTF-8 UTF-8
EOF
(
    PATH="$STEAMOS_BIN_DIR:$BIN_DIR:$PATH"
    HOME="$HOME_DIR"
    DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR"
    export PATH HOME DOMESTIC_SOURCE_TEST_STATE
    # shellcheck disable=SC1090
    source "$PROJECT_ROOT/modules/domestic_source.sh"
    toolbox_sudo() { "$@"; }

    write_managed_archlinuxcn_repo "$SYSTEM_DIR/pacman.conf"
    write_managed_archlinuxcn_repo "$SYSTEM_DIR/pacman.conf"
    [ "$(grep -c '^\[archlinuxcn\]$' "$SYSTEM_DIR/pacman.conf")" -eq 1 ] || \
        fail "重复执行后 archlinuxcn 仓库不唯一"
    for repo_line in \
        'Server = https://mirror.sjtu.edu.cn/archlinux-cn/$arch' \
        'Server = https://mirrors.ustc.edu.cn/archlinuxcn/$arch' \
        'Server = https://repo.archlinuxcn.org/$arch'; do
        grep -Fq "$repo_line" "$SYSTEM_DIR/pacman.conf" || \
            fail "archlinuxcn 仓库回退地址错误：$repo_line"
    done

    configure_archlinuxcn_with_fallback "$SYSTEM_DIR/pacman.conf"
    grep -Fq 'pacman-key --populate archlinuxcn' "$STATE_DIR/commands" || \
        fail "已有可用 archlinuxcn 密钥环时未加载密钥"

    rm -f "$STATE_DIR/installed.archlinuxcn-keyring"
    configure_archlinuxcn_with_fallback "$SYSTEM_DIR/pacman.conf"
    grep -Fq 'pacman -Syu --needed --noconfirm archlinuxcn-keyring' "$STATE_DIR/commands" || \
        fail "缺少密钥环时未执行 archlinuxcn 安装"
    grep -Fq '[archlinuxcn]' "$SYSTEM_DIR/pacman.conf" || \
        fail "密钥环安装成功后未保留 archlinuxcn 配置"

    rm -f "$STATE_DIR/installed.archlinuxcn-keyring"
    DOMESTIC_SOURCE_FAIL_PACMAN_INSTALL=1
    export DOMESTIC_SOURCE_FAIL_PACMAN_INSTALL
    failure_output="$(configure_archlinuxcn_with_fallback "$SYSTEM_DIR/pacman.conf")"
    printf '%s\n' "$failure_output" | grep -Fq '将继续配置 Flatpak 国内缓存' || \
        fail "archlinuxcn 安装失败时未说明继续配置 Flatpak"
    ! grep -Fq '[archlinuxcn]' "$SYSTEM_DIR/pacman.conf" || \
        fail "archlinuxcn 安装失败后仍保留工具箱仓库配置"
    unset DOMESTIC_SOURCE_FAIL_PACMAN_INSTALL

    configure_chinese_locales "$SYSTEM_DIR/locale.gen"
    [ "$(grep -c '^en_US.UTF-8 UTF-8$' "$SYSTEM_DIR/locale.gen")" -eq 1 ] || \
        fail "英文 locale 未幂等启用"
    [ "$(grep -c '^zh_CN.UTF-8 UTF-8$' "$SYSTEM_DIR/locale.gen")" -eq 1 ] || \
        fail "中文 locale 未幂等启用"
    grep -Fxq 'locale-gen' "$STATE_DIR/commands" || fail "未运行 locale-gen"

    remove_managed_archlinuxcn_repo "$SYSTEM_DIR/pacman.conf"
    ! grep -Fq '[archlinuxcn]' "$SYSTEM_DIR/pacman.conf" || \
        fail "恢复后仍保留工具箱管理的 archlinuxcn"
)

# 重复启用只更新镜像地址，不应重复添加两个远程源。
run_enable >/dev/null
[ "$(grep -c '^remote-add .* flathub-cn ' "$STATE_DIR/commands")" -eq 1 ] || \
    fail "重复启用时再次添加了国内源"
[ "$(grep -c '^remote-add .* flathub-ustc ' "$STATE_DIR/commands")" -eq 1 ] || \
    fail "重复启用时再次添加了国内备用源"

status_output="$(
    PATH="$BIN_DIR:$PATH" \
        HOME="$HOME_DIR" \
        DOMESTIC_SOURCE_TEST_STATE="$STATE_DIR" \
        bash "$PROJECT_ROOT/modules/domestic_source.sh" status
)"
printf '%s\n' "$status_output" | grep -Fq 'flathub-cn' || fail "状态输出缺少国内源"
printf '%s\n' "$status_output" | grep -Fq 'flathub-ustc' || fail "状态输出缺少国内备用源"

restore_output="$(run_restore)"
printf '%s\n' "$restore_output" | grep -Fq '已恢复 Flathub 官方源并启用 GPG 验证，同时移除工具箱管理的 archlinuxcn 配置' || \
    fail "恢复官方源缺少成功提示"
grep -Fxq 'flathub' "$STATE_DIR/remotes" || fail "恢复时未添加官方 Flathub"
if grep -Eq '^flathub-(cn|ustc)$' "$STATE_DIR/remotes"; then
    fail "恢复后仍保留国内缓存源"
fi
grep -Fq 'remote-modify --user --gpg-verify --url=https://dl.flathub.org/repo/ flathub' \
    "$STATE_DIR/commands" || fail "恢复官方源时没有重新启用 GPG 验证"
grep -Fxq 'https://dl.flathub.org/repo/flathub.flatpakrepo' \
    "$STATE_DIR/curl-urls" || fail "恢复官方源时未获取官方签名配置"

echo "PASS: archlinuxcn、locale、国内双缓存、恢复官方源、幂等性、状态和无sudo测试通过"
