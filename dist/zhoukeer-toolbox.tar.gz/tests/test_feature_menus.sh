#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN_FILE="$PROJECT_ROOT/main.sh"
GUI_FILE="$PROJECT_ROOT/core/gui.sh"
UI_FILE="$PROJECT_ROOT/core/ui.sh"

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

function_source() {
    local file="$1"
    local name="$2"
    sed -n "/^${name}()/,/^}/p" "$file"
}

assert_contains() {
    local text="$1"
    local expected="$2"
    local label="$3"
    grep -Fq -- "$expected" <<< "$text" || fail "$label"
}

assert_not_contains() {
    local text="$1"
    local unexpected="$2"
    local label="$3"
    if grep -Fq -- "$unexpected" <<< "$text"; then
        fail "$label"
    fi
}

for public_file in "$MAIN_FILE" "$GUI_FILE" "$PROJECT_ROOT/README.md" "$PROJECT_ROOT/CHANGELOG.md"; do
    if grep -Fq 'Gitee' "$public_file"; then
        fail "用户可见内容仍显示内部镜像平台名称：$public_file"
    fi
done

touch_home="$(function_source "$MAIN_FILE" home_menu)"
gui_home="$(function_source "$GUI_FILE" main_gui_menu)"
sidebar="$(function_source "$UI_FILE" draw_category_frame)"

for item in \
    '新机器设置｜第一次使用从这里开始' \
    '安装常用软件｜聊天、浏览器和远程工具' \
    '游戏与插件｜浏览插件商城和游戏组件' \
    '模拟器｜Switch、Wii U、PS1 至 3DS 模拟器' \
    '帮助｜扫码联系、查看资讯与使用指南' \
    '检查与维护｜检查网络、常见问题并生成诊断包' \
    '更多设置｜国内下载、内存、密码和掌机适配' \
    '双系统用户专用｜互通盘、Windows 与 Clover 设置' \
    '免责声明与使用须知｜查看完整图文说明'; do
    assert_contains "$touch_home" "$item" "触控首页缺少：$item"
    assert_contains "$gui_home" "$item" "GUI 首页缺少：$item"
done

assert_contains "$sidebar" 'ui_sidebar_item 20 help "? 帮助"' "SteamOS 触控侧栏缺少帮助"
assert_contains "$sidebar" 'ui_sidebar_item 14 dual "◇ 双系统用户专用"' "SteamOS 触控侧栏缺少双系统用户专用"
assert_contains "$sidebar" 'RENKIT_STEAMOS_DUAL_NAV' "SteamOS 双系统侧栏缺少平台隔离"

sidebar_item="$(function_source "$UI_FILE" ui_sidebar_item)"
assert_contains "$sidebar_item" '[ "$value" = "help" ]' "帮助主菜单缺少独立红字样式"
assert_contains "$sidebar_item" "label='帮　助'" "帮助主菜单没有使用加宽文字"
assert_contains "$sidebar_item" "foreground='\\033[1;38;5;196m'" "帮助主菜单没有使用高亮粗体红字"

help_image_renderer="$(function_source "$UI_FILE" ui_help_image)"
assert_contains "$help_image_renderer" 'ZHOUKEER_FONT_SIZE' "帮助图片未按终端字号估算实际空间"
assert_contains "$help_image_renderer" 'available_width' "帮助图片没有检查左右列宽度"
assert_contains "$help_image_renderer" 'available_height' "帮助图片没有为说明和返回按钮预留高度"
assert_contains "$help_image_renderer" "'4k:779:779:1064'" "帮助图片缺少 4K 放大档位"

help_captions="$(function_source "$UI_FILE" ui_help_captions)"
assert_not_contains "$help_captions" 'ui_move ' "帮助页图片说明仍使用固定行号留白"
assert_not_contains "$help_captions" 'xianyu_caption' "二维码说明仍跟随较矮的闲鱼图绘制"
help_replay="$(function_source "$UI_FILE" ui_replay_frame)"
assert_contains "$help_replay" 'ui_help_right_caption' "窗口缩放重绘遗漏闲鱼图说明"

help_page="$(cat "$PROJECT_ROOT/help.html")"
assert_contains "$help_page" '一起为Linux游戏社区贡献一份力，帮助到你了欢迎来闲鱼支持我' "帮助页顶部标语不正确"
assert_contains "$help_page" '闲鱼账号：<strong>RenAmamiya</strong>' "帮助页缺少闲鱼账号"
assert_contains "$help_page" 'https://link3.cc/renamamiya</a></figcaption>' "帮助页二维码下方缺少联系链接"
assert_contains "$help_page" '闲鱼关注我了解更多资讯' "帮助页缺少闲鱼说明"

touch_contact="$(function_source "$MAIN_FILE" help_contact_menu)"
assert_contains "$touch_contact" 'draw_category_frame help "" "" 0' "帮助页没有释放右侧图片排版空间"
assert_contains "$touch_contact" 'ui_help_image 6 left' "帮助页左侧缺少内嵌二维码"
assert_contains "$touch_contact" 'ui_help_image 6 right' "帮助页右侧缺少内嵌闲鱼图片"
assert_contains "$touch_contact" 'ui_help_captions "如果二维码扫不出来" "请在浏览器浏览以下网址"' "帮助页扫码失败说明没有收回二维码下方"
assert_contains "$touch_contact" 'ui_help_right_caption "闲鱼关注我了解更多资讯"' "闲鱼说明没有紧跟右图"
case "$touch_contact" in
    *'ui_help_image 6 right'*'ui_help_right_caption "闲鱼关注我了解更多资讯"'*'ui_help_image 6 left'*'ui_help_captions "如果二维码扫不出来"'*) ;;
    *) fail "帮助页两栏说明没有分别跟在各自图片下方" ;;
esac
assert_contains "$touch_contact" 'right:22-24:home' "帮助页底部缺少返回首页"
assert_not_contains "$touch_contact" '打开帮助页面' "帮助页仍要求打开外部页面"
assert_not_contains "$touch_contact" '联系网址：' "二维码下方仍错误标注为联系网址"
for image in \
    "$PROJECT_ROOT/assets/help/renamamiya-qr.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-compact.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-deck.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-large.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-wide.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-full.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-2k.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr-4k.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-compact.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-compact-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-deck.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-deck-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-large.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-large-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-wide.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-wide-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-full.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-full-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-2k.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-2k-safe.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-4k.sixel" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya-4k-safe.sixel" \
    "$PROJECT_ROOT/assets/help/renamamiya-qr.ansi" \
    "$PROJECT_ROOT/assets/help/xianyu-renamamiya.ansi"; do
    [ -s "$image" ] || fail "帮助页内嵌图片缺失：$image"
done

touch_software="$(function_source "$MAIN_FILE" common_software_menu)"
gui_software="$(function_source "$GUI_FILE" software_menu)"
touch_software_more="$(function_source "$MAIN_FILE" common_software_more_menu)"
for menu in "$touch_software" "$gui_software"; do
    for item in '微信' 'QQ' 'Firefox 浏览器' 'Chrome 浏览器' 'Edge 浏览器' 'RustDesk 远程协助' 'AnyDesk 远程协助' 'ToDesk 远程协助' 'Windows 软件工具' '游戏兼容设置'; do
        assert_contains "$menu" "$item" "常用软件缺少：$item"
    done
done
assert_not_contains "$touch_software" '网易云音乐' "常用软件第一页不应显示：网易云音乐"
for menu in "$touch_software" "$gui_software"; do
    assert_not_contains "$menu" '战网' "常用软件不应显示：战网"
done

for menu in "$touch_software_more" "$gui_software"; do
    for item in 'LibreOffice 办公套件' 'VLC 播放器' 'OBS Studio' 'LocalSend 局域网传文件' 'PeaZip 压缩工具' 'WiliWili' '中文输入法' 'Xbox 云游戏' 'QQ音乐' '网易云音乐' 'YesPlayMusic' 'qBittorrent' 'Motrix 下载器' 'Free Download Manager' 'Media Downloader' 'Flameshot 截图' 'OnlyOffice 办公套件' 'Joplin 笔记' 'Heroic 游戏启动器' 'Lutris' 'Chiaki4Deck（PS5串流）' 'Parsec' 'Sunshine 游戏画面共享'; do
        assert_contains "$menu" "$item" "更多常用软件缺少：$item"
    done
done

touch_remote="$(function_source "$MAIN_FILE" remote_assistance_menu)"
gui_remote="$(function_source "$GUI_FILE" remote_menu)"
for menu in "$touch_remote" "$gui_remote"; do
    assert_not_contains "$menu" 'AnyDesk' "AnyDesk 不应重复显示在远程协助"
done

touch_plugin_page_2="$(function_source "$MAIN_FILE" plugin_page_2_menu)"
touch_feature_singles="$(function_source "$MAIN_FILE" feature_plugin_singles_menu)"
touch_launcher_tools="$(function_source "$MAIN_FILE" launcher_tools_menu)"
gui_games="$(function_source "$GUI_FILE" game_environment_gui_menu)"
touch_freedeck="$(function_source "$MAIN_FILE" freedeck_versions_menu)"
touch_handheld_plugins="$(function_source "$MAIN_FILE" handheld_plugins_menu)"
touch_onexplayer_tools="$(function_source "$MAIN_FILE" onexplayer_tools_menu)"
assert_contains "$touch_plugin_page_2" '启动器与封面' "插件第二页缺少启动器与封面子菜单"
assert_contains "$touch_launcher_tools" '战网与黑盒工坊' "启动器与封面子菜单缺少战网入口"
assert_contains "$gui_games" '战网启动器' "GUI 游戏与插件缺少战网启动器"
assert_contains "$touch_plugin_page_2" 'ToMoon' "插件第二页缺少 ToMoon"
assert_contains "$gui_games" 'ToMoon' "GUI 游戏与插件缺少 ToMoon"
for menu in "$touch_feature_singles" "$gui_games"; do
    for item in '游戏封面更换' '主题美化' '文件传输助手' '音乐播放器' 'Fantastic 风扇控制'; do
        assert_contains "$menu" "$item" "其余常用插件缺少独立入口：$item"
    done
    for action in steamgriddb cssloader friendeck deckymusic fantastic; do
        assert_contains "$menu" "modules/plugin_store.sh\" $action" "其余常用插件动作错误：$action"
    done
    assert_contains "$menu" '支持 QQ 音乐和网易云音乐' "音乐播放器入口未说明支持的音乐平台"
done
assert_not_contains "$touch_feature_singles" 'Switch to Windows' "Switch to Windows 不应继续显示在其余常用插件"
assert_not_contains "$touch_plugin_page_2" '安装模拟器' "插件第二页仍显示模拟器入口"
assert_not_contains "$gui_games" '安装模拟器' "GUI 游戏与插件仍显示模拟器入口"
assert_contains "$touch_launcher_tools" 'right:11-12:repair' "启动器与封面子菜单缺少修复封面坐标"
assert_contains "$touch_plugin_page_2" 'right:21-22:previous' "插件第二页缺少调整后的上一页坐标"
assert_contains "$touch_plugin_page_2" 'right:23-24:home' "插件第二页缺少调整后的返回首页坐标"
assert_contains "$touch_plugin_page_2" 'modules/plugin_store.sh" tomoon' "触控 ToMoon 未使用独立安装器"
assert_contains "$gui_games" 'modules/plugin_store.sh" tomoon' "GUI ToMoon 未使用独立安装器"
assert_contains "$touch_plugin_page_2" 'right:9-10:handheld-plugins' "插件第二页缺少掌机控制插件子菜单"
for menu in "$touch_handheld_plugins" "$gui_games"; do
    assert_contains "$menu" 'PowerControl 功耗控制' "掌机控制插件菜单缺少 PowerControl"
    assert_contains "$menu" '调节性能、耗电和风扇转速' "PowerControl 入口缺少功能说明"
    assert_contains "$menu" 'modules/plugin_store.sh" powercontrol' "PowerControl 未调用独立插件安装动作"
    assert_contains "$menu" '管理员权限' "PowerControl 入口缺少 root 权限风险说明"
    assert_contains "$menu" '不要与其他功耗或风扇插件同时启用' "PowerControl 入口缺少同类插件冲突提示"
    assert_contains "$menu" 'Ally 控制中心' "掌机控制插件菜单缺少中文名称"
    assert_contains "$menu" 'ROG Ally / Ally X' "Ally Center 入口缺少适用机型"
    assert_contains "$menu" '灯光' "Ally Center 入口缺少 RGB 功能说明"
    assert_contains "$menu" 'modules/plugin_store.sh" allycenter' "Ally Center 未调用独立插件安装动作"
    for item in '通用掌机灯光' 'Legion Go 控制中心' 'GPD 控制中心' \
        'Legion Go 震动控制' 'Legion Go 2 风扇控制'; do
        assert_contains "$menu" "$item" "掌机控制插件菜单缺少：$item"
    done
    for action in huesync legiongo-remapper gpd-control lego-vibe lego2-fan; do
        assert_contains "$menu" "modules/plugin_store.sh\" $action" "掌机控制插件缺少动作：$action"
    done
done
assert_contains "$touch_handheld_plugins" 'OneXPlayer 机型工具' "掌机控制插件菜单缺少 OneXPlayer 机型工具"
assert_contains "$touch_handheld_plugins" 'X2 Mini Pro 亮度修复（已实测）' "掌机控制插件菜单缺少 X2 Mini Pro 实测标注"
assert_contains "$touch_onexplayer_tools" 'X2 Mini Pro 亮度修复' "OneXPlayer 子菜单缺少 X2 Mini Pro 亮度修复"
assert_contains "$touch_onexplayer_tools" 'ONEXPLAYER X2 Mini Pro' "X2 Mini Pro 亮度修复缺少实测机型"
assert_contains "$touch_onexplayer_tools" 'modules/plugin_store.sh" lego2-brightness-fix' "X2 Mini Pro 亮度修复未调用独立安装动作"
assert_contains "$touch_onexplayer_tools" 'OneXPlayer Apex 工具' "OneXPlayer 子菜单缺少 Apex 工具"
assert_contains "$touch_onexplayer_tools" 'modules/plugin_store.sh" onexplayer-apex' "OneXPlayer Apex 工具未调用独立安装动作"
assert_contains "$touch_onexplayer_tools" '原版 SteamOS' "OneXPlayer Apex 工具缺少 SteamOS 适用范围提示"
assert_contains "$gui_games" 'X2 Mini Pro 亮度修复' "GUI 缺少 X2 Mini Pro 亮度修复"
assert_contains "$gui_games" 'modules/plugin_store.sh" lego2-brightness-fix' "GUI X2 Mini Pro 亮度修复未调用独立安装动作"
for menu in "$touch_freedeck" "$gui_games"; do
    assert_contains "$menu" 'Freedeck 0.6 稳定版' "Freedeck 版本菜单缺少稳定版"
    assert_contains "$menu" 'NewFreedeck' "Freedeck 版本菜单缺少重构版"
    assert_contains "$menu" '自动更新到最新版' "NewFreedeck 入口缺少自动更新说明"
    assert_contains "$menu" '部分模拟器暂时无法使用' "NewFreedeck 入口缺少上游状态提示"
done
for menu in "$touch_feature_singles" "$gui_games"; do
    assert_contains "$menu" 'Fantastic 风扇控制' "其余常用插件缺少 Fantastic"
    assert_contains "$menu" '完整汉化版' "Fantastic 入口缺少完整汉化包说明"
    assert_contains "$menu" '汉化：RenAmamiya' "Fantastic 入口缺少汉化署名"
    assert_contains "$menu" '过低转速可能导致设备过热' "Fantastic 入口缺少风扇风险确认"
    assert_not_contains "$menu" 'Gitee汉化版' "Fantastic 入口仍显示 Gitee 来源"
    assert_not_contains "$menu" '从 Gitee mirror-3 安装带 RenAmamiya' "Fantastic 确认框仍显示镜像名称"
done
for menu in "$MAIN_FILE" "$GUI_FILE"; do
    selected_names="$(sed -n '/^DECKY_OFFICIAL_PLUGIN_NAMES=(/,/^)/p' "$menu")"
    assert_not_contains "$selected_names" 'Fantastic' "Fantastic 仍错误显示在精选插件列表"
done
touch_lsfg="$(function_source "$MAIN_FILE" lsfg_versions_menu)"
for menu in "$touch_lsfg" "$gui_games"; do
    assert_contains "$menu" '小黄鸭 1.0' "小黄鸭版本菜单缺少 1.0"
    assert_contains "$menu" '小黄鸭 2.0' "小黄鸭版本菜单缺少 2.0"
    assert_contains "$menu" '仅正版小黄鸭用户用' "小黄鸭 2.0 缺少正版使用说明"
    assert_contains "$menu" '覆盖 1.0 小黄鸭' "小黄鸭 2.0 缺少替代 1.0 说明"
    assert_contains "$menu" '可与 MAKO 共存' "小黄鸭 2.0 缺少与 MAKO 共存说明"
    assert_contains "$menu" 'MAKO 小黄鸭' "小黄鸭版本菜单缺少 MAKO"
    assert_contains "$menu" '自动检查新版本' "MAKO 入口缺少自动跟随上游说明"
    assert_contains "$menu" '中文界面' "MAKO 入口缺少上游中文说明"
done
assert_not_contains "$touch_lsfg" 'MAKO 小黄鸭" "实验仓库尝鲜版·Renkit 汉化' "MAKO 触控入口仍标注 Renkit 汉化"
assert_not_contains "$gui_games" 'MAKO 小黄鸭｜实验仓库尝鲜版·Renkit 汉化' "MAKO GUI 入口仍标注 Renkit 汉化"
touch_software_buttons="$(printf '%s\n' "$touch_software" | grep 'ui_touch_button')"
gui_software_entries="$(printf '%s\n' "$gui_software" | sed -n '/choice="$(gui_dialog --menu/,/)" || return 0/p')"
for obsolete_hint in '安装适合 SteamOS 的微信' '安装适合 SteamOS 的 QQ' \
    '安装 Firefox 浏览器' '安装 Chrome 浏览器' '安装 Edge 浏览器'; do
    assert_not_contains "$touch_software_buttons" "$obsolete_hint" "触控常用软件仍显示多余说明：$obsolete_hint"
    assert_not_contains "$gui_software_entries" "$obsolete_hint" "GUI 常用软件仍显示多余说明：$obsolete_hint"
done

touch_games="$(function_source "$MAIN_FILE" game_environment_menu)
$(function_source "$MAIN_FILE" feature_plugin_singles_menu)
$(function_source "$MAIN_FILE" decky_loader_menu)
$(function_source "$MAIN_FILE" plugin_page_2_menu)
$(function_source "$MAIN_FILE" launcher_tools_menu)
$(function_source "$MAIN_FILE" handheld_plugins_menu)
$(function_source "$MAIN_FILE" battlenet_submenu)"
gui_games="$(function_source "$GUI_FILE" game_environment_gui_menu)"
for menu in "$touch_games" "$gui_games"; do
    assert_contains "$menu" '游戏与插件｜插件商城' "插件商城页面标题不统一"
    assert_not_contains "$menu" '游戏与插件｜Decky 插件商城' "插件商城页面仍显示英文标题"
    for item in '常用插件组合' '浏览官方插件' 'Epic 游戏启动器' '安装插件商城' 'HMCL 启动器'; do
        assert_contains "$menu" "$item" "游戏环境缺少：$item"
    done
    assert_contains "$menu" '黑盒工坊' "战网子菜单缺少黑盒工坊"
    assert_contains "$menu" '添加到 Steam' "战网子菜单缺少使用入口提示"
    assert_contains "$gui_games" '常用插件加精选插件' "GUI 缺少常用加精选插件入口"
    assert_contains "$menu" '让游戏画面更流畅' "小黄鸭缺少功能说明"
    assert_contains "$menu" '请先阅读使用说明' "FSR4 缺少功能说明"
    assert_contains "$menu" '安装和启动 Minecraft' "HMCL 启动器入口缺少 安装和启动 Minecraft说明"
    assert_not_contains "$menu" '国内镜像' "插件菜单仍显示安装来源"
    assert_not_contains "$menu" 'Gitee' "插件菜单仍显示内部镜像平台名称"
    assert_contains "$menu" '汉化：RenAmamiya' "小黄鸭/FSR4 缺少最终汉化署名"
    assert_not_contains "$menu" 'v0.12.8 汉化版；国内源优先，失败自动改用 GitHub Release' "小黄鸭仍显示 GitHub 回退"
    assert_not_contains "$menu" '请先阅读使用说明·国内源优先，失败自动改用 GitHub Release' "FSR4 仍显示 GitHub 回退"
    assert_contains "$menu" '给游戏模式增加插件功能' "插件商城缺少用途说明"
    assert_contains "$menu" '需要管理员权限' "插件商城缺少权限说明"
    assert_contains "$menu" '安装测试版插件商城' "Decky Loader 缺少测试版入口"
    assert_contains "$menu" '测试版或预览版' "Decky 测试版入口缺少系统通道说明"
    assert_contains "$menu" 'ROG White 白色主题' "Decky Loader 子菜单缺少 ROG White 白色主题"
    assert_contains "$menu" '掌机 Pink 粉色主题' "Decky Loader 子菜单缺少 掌机 Pink 粉色主题"
    assert_not_contains "$menu" '25 个精选插件' "plugin_store all 仍被错误描述为 25 个精选插件"
    assert_not_contains "$menu" '兼容层管理' "不存在的兼容层管理仍可见"
done
assert_contains "$touch_games" '根据系统版本安装' "Decky Loader 子菜单缺少自动安装入口"
assert_contains "$gui_games" '根据系统版本安装' "GUI 插件商城缺少自动安装入口"
assert_contains "$touch_games" 'right:12-13:rog-white-install' "Decky Loader 子菜单缺少 ROG White 安装坐标"
assert_contains "$touch_games" 'right:14-15:handheld-pink-install' "Decky Loader 子菜单缺少 掌机 Pink 安装坐标"
assert_contains "$gui_games" 'rog-white-install' "GUI 插件商城缺少 ROG White 白色主题入口"
assert_contains "$gui_games" 'handheld-pink-install' "GUI 插件商城缺少 掌机 Pink 粉色主题入口"
assert_contains "$gui_games" 'modules/rog_white_theme.sh" install' "GUI ROG White 白色主题动作错误"
assert_contains "$gui_games" 'modules/handheld_pink_theme.sh" install' "GUI 掌机 Pink 粉色主题动作错误"

touch_maintenance="$(function_source "$MAIN_FILE" maintenance_menu)"
gui_maintenance="$(function_source "$GUI_FILE" maintenance_gui_menu)"
for menu in "$touch_maintenance" "$gui_maintenance"; do
    for item in '系统健康检查' '游戏启动检查' '清理下载残留' '清理着色器缓存' '清理用户缓存' '查看性能建议' '常见问题处理'; do
        assert_contains "$menu" "$item" "系统维护缺少：$item"
    done
    [ "$(printf '%s\n' "$menu" | grep -o '会删除缓存' | wc -l | tr -d ' ')" -ge 4 ] || fail "缓存删除风险说明不足"
    assert_not_contains "$menu" '权限修复' "不存在的权限修复仍可见"
    assert_not_contains "$menu" '一键修复模式' "旧的一键修复名称仍可见"
done

touch_help="$(function_source "$MAIN_FILE" help_menu)"
gui_help="$(function_source "$GUI_FILE" help_gui_menu)"
for menu in "$touch_help" "$gui_help"; do
    for item in '查看系统信息' '生成诊断包' '备份Renkit设置' '恢复Renkit设置' '查看详细网络信息' '导出旧版文字报告' '新手使用指南' '游戏兼容指南' '掌机常用快捷键' '外接设备检查' '操作记录' '更新日志' '检查并更新Renkit'; do
        assert_contains "$menu" "$item" "检测与帮助缺少：$item"
    done
    assert_contains "$menu" '会联网并更新' "Renkit更新缺少联网更新说明"
done

touch_support="$(function_source "$MAIN_FILE" support_menu)"
gui_support="$(function_source "$GUI_FILE" support_gui_menu)"
for menu in "$touch_support" "$gui_support"; do
    for item in '一键检查网络' '检查常见问题' '查看下载状态' '发给维护人员' '使用帮助与设置' '更多设置'; do
        assert_contains "$menu" "$item" "检查与维护缺少：$item"
    done
    for hidden in '网络修复' 'Discover 应用商店修复' '恢复官方源'; do
        assert_not_contains "$menu" "$hidden" "检查与维护页不应显示：$hidden"
    done
    assert_not_contains "$menu" 'domestic_source.sh" init' "检查与维护页不应直接执行国内源初始化"
    assert_contains "$menu" '发给维护人员' "检查问题页缺少面向新手的诊断包入口"
    assert_contains "$menu" '不包含密码和隐私信息' "诊断包入口缺少隐私说明"
    assert_contains "$menu" 'modules/diagnostics.sh" bundle' "诊断包入口映射错误"
done

touch_advanced="$(function_source "$MAIN_FILE" advanced_tools_menu)"
gui_advanced="$(function_source "$GUI_FILE" advanced_tools_gui_menu)"
for menu in "$touch_advanced" "$gui_advanced"; do
    assert_contains "$menu" '国内下载、网络加速、内存、密码与掌机适配' "更多设置缺少功能概览"
    for item in '软件下载加速' 'Steamcommunity 302' '虚拟内存' '修改管理员密码' '掌机适配'; do
        assert_contains "$menu" "$item" "系统设置缺少：$item"
    done
    assert_not_contains "$menu" '双系统与互通盘' "双系统入口仍嵌套在更多设置"
    for removed in '设置管理员密码' '安装插件商城' '安装 ToDesk'; do
        assert_not_contains "$menu" "$removed" "系统设置仍显示重复入口：$removed"
    done
    for risk_text in '风险说明' '修改 DNS' '虚拟内存' '管理密码' '无需管理员权限'; do
        assert_contains "$menu" "$risk_text" "系统设置缺少风险说明：$risk_text"
    done
done

touch_memory="$(function_source "$MAIN_FILE" memory_touch_menu)"
gui_memory="$(function_source "$GUI_FILE" memory_gui_menu)"
for menu in "$touch_memory" "$gui_memory"; do
    for item in '一键优化' '查看状态' '撤销Renkit优化' '系统原有虚拟内存'; do
        assert_contains "$menu" "$item" "虚拟内存子菜单缺少：$item"
    done
    assert_contains "$menu" 'modules/memory_tuning.sh" restore' "虚拟内存子菜单未调用安全撤销动作"
done

touch_f1="$(function_source "$MAIN_FILE" f1_handheld_menu)"
gui_f1="$(function_source "$GUI_FILE" f1_screen_fix_gui_menu)"
for menu in "$touch_f1" "$gui_f1"; do
    for item in '安装屏幕修复' '屏幕修复状态' '卸载屏幕修复' '安装特殊按键修复' '特殊按键修复状态' '恢复特殊按键修复' '更新 InputPlumber' '系统软件源' '准备 V1.14 BIOS' '立即重启 SteamOS' 'F1L 仅限 F1 8840U' '5秒自动重启' 'ONEXPLAYER F1' '无需管理员权限'; do
        assert_contains "$menu" "$item" "飞行家 F1 子菜单缺少：$item"
    done
    assert_contains "$touch_f1" 'right:2-3:install' "飞行家 F1 屏幕修复安装坐标错误"
    assert_contains "$touch_f1" 'right:8-9:button-install' "壹号掌机按键修复安装坐标错误"
    assert_contains "$touch_f1" 'right:10-11:button-status' "壹号掌机按键状态坐标错误"
    assert_contains "$touch_f1" 'right:12-13:button-restore' "壹号掌机按键恢复坐标错误"
    assert_contains "$touch_f1" 'right:14-15:inputplumber-update' "InputPlumber 更新坐标错误"
    assert_contains "$touch_f1" 'right:16-17:bios' "飞行家 F1 BIOS 坐标错误"
    assert_contains "$touch_f1" 'right:18-19:reboot' "飞行家 F1 重启坐标错误"
    assert_contains "$menu" 'modules/f1_bios_prepare.sh" prepare' "飞行家 F1 BIOS 准备动作错误"
    assert_contains "$menu" 'modules/onexplayer_button_fix.sh" install' "壹号掌机按键安装动作错误"
    assert_contains "$menu" 'modules/onexplayer_button_fix.sh" status' "壹号掌机按键状态动作错误"
    assert_contains "$menu" 'modules/onexplayer_button_fix.sh" restore' "壹号掌机按键恢复动作错误"
    assert_contains "$menu" 'modules/inputplumber_update.sh" update' "InputPlumber 更新动作错误"
done
assert_contains "$touch_f1" 'confirm_and_run "更新 InputPlumber"' "触控菜单的 InputPlumber 更新缺少单次确认"
assert_contains "$touch_f1" 'confirm_and_run "壹号掌机 SteamOS 特殊按键修复"' "触控菜单的特殊按键安装缺少单次确认"
assert_contains "$touch_f1" '等待5秒自动重启SteamOS' "触控菜单没有提前说明自动重启"
assert_contains "$touch_f1" 'confirm_and_run "恢复壹号掌机 SteamOS 特殊按键修复"' "触控菜单的特殊按键恢复缺少单次确认"
assert_contains "$touch_f1" '完成后5秒自动重启' "触控菜单的特殊按键恢复没有自动重启说明"
assert_contains "$gui_f1" 'modules/onexplayer_button_fix.sh" plan-install' "GUI 缺少特殊按键安装预览"
assert_contains "$gui_f1" 'modules/onexplayer_button_fix.sh" plan-restore' "GUI 缺少特殊按键恢复预览"
assert_contains "$gui_f1" 'modules/inputplumber_update.sh" plan' "GUI 缺少 InputPlumber 更新预览"
assert_contains "$gui_f1" 'ZHOUKEER_AUTO_CONFIRM=1' "GUI 确认后未向模块传递授权"

touch_uninstall="$(function_source "$MAIN_FILE" uninstall_software_menu)"
gui_uninstall="$(function_source "$GUI_FILE" uninstall_software_gui_menu)"
for menu in "$touch_uninstall" "$gui_uninstall"; do
    for item in '卸载微信' '卸载 QQ' '卸载 Firefox' '卸载 Chrome' '卸载 Edge' '卸载 RustDesk' '卸载 ToDesk' '卸载百度网盘' '卸载 AnyDesk' '卸载 WiliWili' '卸载 Xbox 云游戏' '卸载 LibreOffice' '卸载 VLC' '卸载 OBS Studio' '卸载 LocalSend' '卸载 PeaZip' '卸载中文输入法' '卸载 Protontricks' '卸载 Bottles' '卸载 QQ音乐' '卸载网易云音乐' '卸载 YesPlayMusic' '卸载 qBittorrent' '卸载 Motrix' '卸载 Free Download Manager' '卸载 Media Downloader' '卸载 Flameshot 截图' '卸载 OnlyOffice' '卸载 Joplin 笔记' '卸载 Heroic' '卸载 Lutris' '卸载 Chiaki4Deck' '卸载 Parsec' '卸载战网启动器' '卸载 Epic' '卸载育碧' '卸载黑盒工坊' '卸载 Yuzu' '卸载 Cemu' '卸载 DuckStation' '卸载 PCSX2' '卸载 RPCS3' '卸载 ShadPS4' '卸载 PPSSPP' '卸载 mGBA' '卸载 Azahar' '卸载 Steam302' '卸载 GE-Proton' '卸载 Decky Loader' '清空全部 Decky 插件'; do
        assert_contains "$menu" "$item" "卸载已安装缺少：$item"
    done
    for page in 1 2 3 4 5 6 7; do
        assert_contains "$menu" "第 $page/7 页" "卸载菜单缺少第 $page 页"
    done
done

touch_games_page_1="$(function_source "$MAIN_FILE" game_environment_menu)"
gui_games_page_1="$(function_source "$GUI_FILE" game_environment_gui_menu)"
for menu in "$touch_games_page_1" "$gui_games_page_1"; do
    assert_contains "$menu" 'Steam 键 → 设置 → 启用开发者模式' "插件商城或插件组合缺少开发者模式开启路径"
    assert_contains "$menu" '设置左侧出现“开发者”后 → 开发者 → 杂项' "插件商城或插件组合缺少 CEF 菜单路径"
    assert_contains "$menu" 'CEF 远程调试' "插件商城或插件组合缺少 CEF 远程调试提示"
done
touch_games_page_2="$(function_source "$MAIN_FILE" plugin_page_2_menu)"
touch_launcher_tools="$(function_source "$MAIN_FILE" launcher_tools_menu)"
touch_emulators="$(function_source "$MAIN_FILE" emulator_menu)"
gui_emulators="$(function_source "$GUI_FILE" emulator_gui_menu)"
assert_contains "$touch_games_page_1" 'right:11-12:cheatdeck' "CheatDeck 未放在插件第一页"
assert_contains "$touch_games_page_2" 'right:9-10:handheld-plugins' "掌机控制插件子菜单未放在插件第二页"
touch_handheld_plugins="$(function_source "$MAIN_FILE" handheld_plugins_menu)"
touch_onexplayer_tools="$(function_source "$MAIN_FILE" onexplayer_tools_menu)"
assert_contains "$touch_handheld_plugins" 'right:5-6:simpledeckytdp' "掌机控制插件子菜单缺少 SimpleDeckyTDP"
assert_contains "$touch_handheld_plugins" 'right:7-8:allycenter' "掌机控制插件子菜单缺少 Ally Center"
assert_contains "$touch_handheld_plugins" 'right:3-4:powercontrol' "掌机控制插件子菜单缺少 PowerControl"
assert_contains "$touch_handheld_plugins" 'right:19-20:onexplayer-tools' "掌机控制插件子菜单缺少 OneXPlayer 机型工具"
assert_contains "$touch_onexplayer_tools" 'right:7-8:x2-mini-pro-brightness' "OneXPlayer 子菜单缺少 X2 Mini Pro 亮度修复"
assert_contains "$touch_games_page_2" 'right:13-14:tomoon' "ToMoon 未紧挨 Unifideck 排列"
assert_contains "$touch_launcher_tools" 'right:9-10:ubisoft' "Ubisoft Connect 未加入启动器子菜单"
assert_contains "$touch_launcher_tools" '"育碧"' "育碧菜单仍显示旧名称"
for menu in "$touch_emulators" "$gui_emulators"; do
    for item in 'Yuzu' 'Cemu' 'DuckStation' 'PCSX2' 'RPCS3' 'ShadPS4' 'PPSSPP' 'mGBA' 'Azahar'; do
        assert_contains "$menu" "$item" "模拟器菜单缺少：$item"
    done
    assert_contains "$menu" '桌面图标' "模拟器菜单未说明桌面入口"
    assert_contains "$menu" 'Steam 库' "模拟器菜单未说明 Steam 入库"
    assert_contains "$menu" '一键安装 6 款' "模拟器菜单缺少一键安装入口"
    assert_contains "$menu" 'modules/emulators.sh" install-all' "模拟器菜单一键安装动作错误"
    assert_not_contains "$menu" 'EmuDeck' "模拟器菜单不应包含 EmuDeck"
    assert_not_contains "$menu" '返回游戏与插件' "模拟器独立入口仍返回游戏与插件"
done

touch_dual="$(function_source "$MAIN_FILE" dual_system_menu)"
touch_dual_more="$(function_source "$MAIN_FILE" dual_system_more_menu)"
gui_dual="$(function_source "$GUI_FILE" dual_system_menu)"
gui_dual_more="$(function_source "$GUI_FILE" dual_system_more_menu)"
touch_dual_all="${touch_dual}${touch_dual_more}"
gui_dual_all="${gui_dual}${gui_dual_more}"
for menu in "$touch_dual_all" "$gui_dual_all"; do
    for item in '挂载双系统互通盘' '初始化并挂载 TF 卡' '修复 Steam 磁盘写入错误' '双系统互通盘保护' '双系统健康检查' '恢复互通盘写入' '清理第三方引导项' '修复双系统引导' 'Switch to Windows' '隐藏 Clover 菜单' '重新显示 Clover 菜单' '默认进入 Windows' '默认进入 SteamOS'; do
        assert_contains "$menu" "$item" "双系统与互通盘缺少：$item"
    done
    assert_contains "$menu" 'modules/plugin_store.sh" switch-to-windows' "双系统菜单缺少 Switch to Windows 安装动作"
    assert_contains "$menu" '下载失败和更新失败' "Steam 磁盘修复入口缺少故障范围说明"
    assert_contains "$menu" '游戏启动设置' "Steam 磁盘修复入口缺少 compatdata 说明"
    assert_contains "$menu" 'modules/clover_boot.sh" hide-menu' "双系统菜单缺少隐藏 Clover 菜单动作"
    assert_contains "$menu" 'modules/clover_boot.sh" show-menu' "双系统菜单缺少恢复 Clover 菜单动作"
    assert_contains "$menu" 'modules/clover_boot.sh" default-windows' "双系统菜单缺少默认 Windows 动作"
    assert_contains "$menu" 'modules/clover_boot.sh" default-steamos' "双系统菜单缺少默认 SteamOS 动作"
    assert_not_contains "$menu" 'modules/clover_boot.sh" autoboot-windows' "双系统菜单仍暴露绑定隐藏菜单与默认 Windows 的旧动作"
    for removed_item in '安装或修复 Clover' '查看 Clover 状态' '删除 Clover 双系统引导'; do
        assert_not_contains "$menu" "$removed_item" "已移除的 Clover 功能仍显示：$removed_item"
    done
    for marker in 'B1 ' 'B2 ' 'B3 ' 'B4 ' 'B5 ' 'B6 '; do
        assert_not_contains "$menu" "$marker" "双系统菜单仍显示参考序号：$marker"
    done
    assert_not_contains "$menu" 'modules/dual_system.sh" add' "双系统菜单仍可执行旧 systemd-boot 显示动作"
    assert_not_contains "$menu" 'modules/dual_system.sh" remove' "双系统菜单仍可执行旧 systemd-boot 隐藏动作"
done
assert_contains "$touch_dual_all" '第 1/2 页' "双系统触控菜单缺少第一页标识"
assert_contains "$touch_dual_all" '第 2/2 页' "双系统触控菜单缺少第二页标识"
assert_contains "$gui_dual_all" '第 1/2 页' "双系统 GUI 菜单缺少第一页标识"
assert_contains "$gui_dual_all" '第 2/2 页' "双系统 GUI 菜单缺少第二页标识"

for gui_menu_name in software_menu game_environment_gui_menu emulator_gui_menu support_gui_menu plugin_official_gui_pages dual_system_menu dual_system_more_menu steam_accelerator_gui_menu console_accelerator_gui_menu maintenance_gui_menu help_gui_menu new_machine_gui_menu advanced_tools_gui_menu memory_gui_menu f1_screen_fix_gui_menu; do
    gui_menu="$(function_source "$GUI_FILE" "$gui_menu_name")"
    assert_contains "$gui_menu" 'home "返回首页"' "GUI 页面缺少返回首页：$gui_menu_name"
    assert_contains "$gui_menu" 'nav-exit "退出Renkit"' "GUI 页面缺少退出Renkit：$gui_menu_name"
done

touch_accelerator="$(function_source "$MAIN_FILE" steam_accelerator_touch_menu)"
gui_accelerator="$(function_source "$GUI_FILE" steam_accelerator_gui_menu)"
for menu in "$touch_accelerator" "$gui_accelerator"; do
    assert_contains "$menu" '重置加速' "Steamcommunity 302 菜单缺少重置入口"
    assert_contains "$menu" '打开官方配置界面' "Steamcommunity 302 菜单缺少配置界面入口"
    assert_not_contains "$menu" '自动启动 Steam' "Steamcommunity 302 菜单仍提示自动启动 Steam"
    assert_contains "$menu" '奇游' "Steamcommunity 302 菜单缺少奇游主机加速入口"
    assert_contains "$menu" '迅游' "Steamcommunity 302 菜单缺少迅游主机加速入口"
    assert_contains "$menu" 'UU' "Steamcommunity 302 菜单缺少UU主机加速入口"
done

touch_ge_proton="$(function_source "$MAIN_FILE" ge_proton_menu)"
gui_ge_proton="$(function_source "$GUI_FILE" ge_proton_gui_menu)"
for menu in "$touch_ge_proton" "$gui_ge_proton"; do
    assert_contains "$menu" '安装最新 GE 兼容层' "GE 兼容层子菜单缺少最新版入口"
    assert_contains "$menu" '安装修改器常用运行工具' "GE 兼容层子菜单缺少修改器常用入口"
    assert_contains "$menu" '1.72GB' "GE 兼容层子菜单缺少下载体积提示"
done

touch_source="$(function_source "$MAIN_FILE" domestic_source_preflight)"
gui_source="$(function_source "$GUI_FILE" domestic_source_gui_preflight)"
for menu in "$touch_source" "$gui_source"; do
    for detail in 'flathub-cn' 'https://mirror.sjtu.edu.cn/flathub' 'flathub-ustc' 'https://mirrors.ustc.edu.cn/flathub' 'archlinux' '签名检查' '系统组件' '系统保护' '恢复'; do
        assert_contains "$menu" "$detail" "国内源风险页缺少：$detail"
    done
done
assert_contains "$touch_source" 'https://mirror.sjtu.edu.cn/archlinux-cn/' "触控风险页缺少系统组件下载地址"
for repo_url in 'https://mirror.sjtu.edu.cn/archlinux-cn/' 'https://mirrors.ustc.edu.cn/archlinuxcn/' 'https://repo.archlinuxcn.org/'; do
    assert_contains "$gui_source" "$repo_url" "GUI 国内源页缺少 archlinuxcn 回退地址：$repo_url"
done

for visible in "$MAIN_FILE" "$GUI_FILE"; do
    if grep -Eq 'modules/dual_system\.sh" refind-(install|hide|show|remove)' "$visible"; then
        fail "可见菜单仍可执行已停用的 rEFInd 动作：$visible"
    fi
    if grep -Eq '\[(只读|只读检查|会安装软件|会安装插件|会安装组件|会创建文件|普通|普通检查|引导|只读为主|部分会删除缓存)\]' "$visible"; then
        fail "普通菜单仍包含冗余状态标签：$visible"
    fi
    if grep -Eq '\[(会删除缓存|会联网并更新|实验功能|高级操作|高风险|安装软件/修改软件源|会修改软件源|会修改网络设置|会修改系统密码|会修改只读系统|会使用管理员权限|磁盘/启动高级操作)\]' "$visible"; then
        fail "菜单风险说明仍使用方括号：$visible"
    fi
done

echo "PASS: 触控与 GUI 的名称、说明、风险标签和功能集合一致"
