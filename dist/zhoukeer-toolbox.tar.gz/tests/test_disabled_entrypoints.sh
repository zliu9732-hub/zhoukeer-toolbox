#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DUAL_FILE="$PROJECT_ROOT/modules/dual_system.sh"

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

contains_text() {
    grep -Fq -- "$2" <<< "$1"
}

for action in refind-install refind-hide refind-show refind-remove; do
    grep -Fq "$action" "$DUAL_FILE" || fail "停用兼容动作缺失：$action"
done
grep -Fq '该功能当前已停用。' "$DUAL_FILE" || fail "rEFInd 停用动作没有明确阻断"

touch_dual="$(sed -n '/^dual_system_menu()/,/^}/p' "$PROJECT_ROOT/main.sh")
$(sed -n '/^dual_system_more_menu()/,/^}/p' "$PROJECT_ROOT/main.sh")"
gui_dual="$(sed -n '/^dual_system_menu()/,/^}/p' "$PROJECT_ROOT/core/gui.sh")
$(sed -n '/^dual_system_more_menu()/,/^}/p' "$PROJECT_ROOT/core/gui.sh")"
for menu in "$touch_dual" "$gui_dual"; do
    for action in mount protect unprotect; do
        contains_text "$menu" "modules/dual_system.sh\" $action" || fail "互通盘菜单动作缺失：$action"
    done
    contains_text "$menu" 'modules/clover_boot.sh" install' || \
        fail "Clover 安装/修复菜单动作缺失"
    contains_text "$menu" 'modules/clover_boot.sh" hide-menu' || \
        fail "Clover 隐藏菜单动作缺失"
    contains_text "$menu" 'modules/clover_boot.sh" show-menu' || \
        fail "Clover 菜单恢复动作缺失"
    contains_text "$menu" 'modules/clover_boot.sh" default-windows' || \
        fail "Clover 默认 Windows 动作缺失"
    contains_text "$menu" 'modules/clover_boot.sh" default-steamos' || \
        fail "Clover 默认 SteamOS 动作缺失"
    if contains_text "$menu" 'modules/clover_boot.sh" autoboot-windows'; then
        fail "Clover 菜单仍暴露绑定隐藏菜单与默认 Windows 的旧动作"
    fi
    if contains_text "$menu" 'modules/clover_boot.sh" delete'; then
        fail "Clover 删除动作不应直接暴露在双系统菜单"
    fi
    for action in tf-format-mount repair-drive health cleanup-boot windows-shortcut; do
        contains_text "$menu" "modules/dual_system_tools.sh\" $action" || fail "双系统扩展动作缺失：$action"
    done
    for removed_action in switch-to-windows windows-next; do
        if contains_text "$menu" "modules/dual_system_tools.sh\" $removed_action"; then
            fail "双系统菜单仍可执行已移除动作：$removed_action"
        fi
    done
    for legacy_action in refind-install refind-hide refind-show refind-remove; do
        if contains_text "$menu" "modules/dual_system.sh\" $legacy_action"; then
            fail "双系统菜单仍可执行旧 rEFInd 动作：$legacy_action"
        fi
    done
done

for action in add remove; do
    if bash "$DUAL_FILE" "$action" >/dev/null 2>&1; then
        fail "旧 systemd-boot 动作仍可执行：$action"
    fi
done

echo "PASS: rEFInd、旧 systemd-boot 不可达，Clover 安装/修复和双系统扩展菜单已接管"
