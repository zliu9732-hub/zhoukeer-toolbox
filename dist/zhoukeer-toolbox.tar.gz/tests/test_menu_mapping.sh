#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN_FILE="$PROJECT_ROOT/main.sh"
GUI_FILE="$PROJECT_ROOT/core/gui.sh"
UI_FILE="$PROJECT_ROOT/core/ui.sh"

[ -s "$PROJECT_ROOT/assets/disclaimer-usage.jpg" ] || {
    echo "FAIL: 免责声明图片资源缺失" >&2
    exit 1
}

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

function_source() {
    local file="$1"
    local name="$2"
    sed -n "/^${name}()/,/^}/p" "$file"
}

assert_contains() {
    local text="$1"
    local expected="$2"
    local label="$3"
    grep -Fq -- "$expected" <<< "$text" || fail "$label"
}

assert_not_contains() {
    local text="$1"
    local unexpected="$2"
    local label="$3"
    if grep -Fq -- "$unexpected" <<< "$text"; then
        fail "$label"
    fi
}

touch_nav="$(function_source "$MAIN_FILE" read_touch_menu)"
gui_home="$(function_source "$GUI_FILE" main_gui_menu)"
sidebar="$(function_source "$UI_FILE" draw_category_frame)"

for mapping in \
    'left:2-3:nav-init' \
    'left:4-5:nav-software' \
    'left:6-7:nav-games' \
    'left:8-9:nav-network' \
    'left:10-11:nav-help' \
    'left:12-13:nav-advanced' \
    'left:14-15:nav-uninstall' \
    'left:16-17:nav-notice' \
    'left:18-19:nav-exit'; do
    assert_contains "$touch_nav" "$mapping" "触控首页映射缺失：$mapping"
done

for action in nav-init nav-software nav-games nav-network nav-help nav-advanced nav-uninstall nav-notice nav-exit; do
    assert_contains "$gui_home" "$action" "GUI 首页映射缺失：$action"
done

for old_action in nav-remote nav-plugins nav-settings nav-dual nav-optimize nav-guides nav-changelog nav-update; do
    assert_not_contains "$touch_nav" "$old_action" "旧导航仍显示在触控首页：$old_action"
    assert_not_contains "$gui_home" "$old_action" "旧导航仍显示在 GUI 首页：$old_action"
done

for selected in init software games network support advanced uninstall notice exit; do
    assert_contains "$sidebar" " $selected \"" "侧栏缺少分类：$selected"
done

touch_software="$(function_source "$MAIN_FILE" common_software_menu)"
touch_games="$(function_source "$MAIN_FILE" game_environment_menu)"
touch_network="$(function_source "$MAIN_FILE" network_store_menu)"
touch_maintenance="$(function_source "$MAIN_FILE" maintenance_menu)"
touch_advanced="$(function_source "$MAIN_FILE" advanced_tools_menu)"
touch_accelerator="$(function_source "$MAIN_FILE" steam_accelerator_touch_menu)"
touch_notice="$(function_source "$MAIN_FILE" usage_notice_menu)"

assert_contains "$touch_software" 'right:14-15:todesk' "常用软件 ToDesk 坐标错误"
assert_contains "$touch_software" 'right:20-21:anydesk' "常用软件 AnyDesk 坐标错误"
assert_contains "$touch_software" 'right:22-23:more' "常用软件更多页坐标错误"
assert_contains "$touch_games" 'right:23-24:home' "游戏环境缺少返回首页"
touch_plugin_page_2="$(function_source "$MAIN_FILE" plugin_page_2_menu)"
assert_contains "$touch_plugin_page_2" 'right:9-10:tomoon' "插件第二页 ToMoon 坐标错误"
assert_contains "$touch_plugin_page_2" 'right:19-20:emulators' "插件第二页缺少可见区内的模拟器入口"
touch_emulators="$(function_source "$MAIN_FILE" emulator_menu)"
for mapping in 'right:5-6:yuzu' 'right:8-9:cemu' 'right:11-12:duckstation' 'right:14-15:pcsx2' 'right:17-18:rpcs3' 'right:20-21:shadps4' 'right:23-24:back'; do
    assert_contains "$touch_emulators" "$mapping" "模拟器触控坐标错误：$mapping"
done
assert_contains "$touch_network" 'right:20-21:home' "网络与应用商店缺少返回首页"
assert_contains "$touch_maintenance" 'right:22-23:home' "系统维护缺少返回首页"
assert_contains "$touch_advanced" 'right:11-12:memory-optimize' "系统设置缺少虚拟内存动作"
assert_contains "$touch_advanced" 'right:22-23:home' "系统设置缺少返回首页"
assert_not_contains "$touch_advanced" 'set-password' "系统设置仍显示首次设置密码入口"
assert_not_contains "$touch_advanced" 'decky-install' "系统设置仍显示插件商城入口"
touch_uninstall="$(function_source "$MAIN_FILE" uninstall_software_menu)"
assert_contains "$touch_uninstall" 'right:19-20:next' "卸载第一页缺少下一页"
assert_contains "$touch_uninstall" 'right:21-22:next' "卸载第二页缺少下一页"
assert_contains "$touch_uninstall" 'right:20-21:previous' "卸载第三页缺少上一页"
assert_contains "$touch_accelerator" 'right:22-23:home' "Steamcommunity 302 缺少返回首页"
assert_contains "$touch_notice" 'disclaimer-usage.jpg' "免责声明图片入口缺失"
assert_contains "$touch_notice" 'right:20-21:home' "免责声明图片页缺少返回首页"

for file in "$MAIN_FILE" "$GUI_FILE"; do
    source_text="$(cat "$file")"
    assert_contains "$source_text" 'modules/password.sh" set' "设置管理员密码动作错误：$file"
    assert_contains "$source_text" 'modules/password.sh" change' "修改管理员密码动作错误：$file"
    assert_contains "$source_text" 'modules/memory_tuning.sh" optimize' "虚拟内存优化动作错误：$file"
    assert_contains "$source_text" 'modules/domestic_source.sh" init' "国内软件源动作错误：$file"
    assert_contains "$source_text" 'modules/domestic_source.sh" restore' "恢复官方源动作错误：$file"
    assert_contains "$source_text" 'core/detect.sh" --health' "系统健康检查动作错误：$file"
    assert_contains "$source_text" 'modules/ge_proton.sh" install' "安装 GE 兼容层动作错误：$file"
    assert_contains "$source_text" 'modules/game_launchers.sh" epic' "Epic 动作错误：$file"
    assert_contains "$source_text" 'modules/game_launchers.sh" ubisoft' "Ubisoft Connect 动作错误：$file"
    assert_contains "$source_text" 'modules/emulators.sh"' "模拟器动作错误：$file"
    assert_contains "$source_text" 'modules/plugin_store.sh" tomoon' "ToMoon GitHub Release 动作错误：$file"
    assert_contains "$source_text" 'modules/plugin_store.sh" lsfg-zh-gitee' "小黄鸭 Gitee 动作错误：$file"
    assert_contains "$source_text" 'modules/plugin_store.sh" fsr4-zh-gitee' "FSR4 Gitee 动作错误：$file"
    assert_contains "$source_text" 'modules/steam_accelerator.sh" enable' "Steamcommunity 302 开启动作错误：$file"
    assert_not_contains "$source_text" 'modules/clover_boot.sh" install' "已移除的 Clover 安装动作仍可执行：$file"
    assert_not_contains "$source_text" 'modules/clover_boot.sh" delete' "已移除的 Clover 删除动作仍可执行：$file"
    assert_contains "$source_text" 'modules/dual_system_tools.sh" health' "双系统健康检查动作错误：$file"
    assert_not_contains "$source_text" 'modules/dual_system_tools.sh" windows-shortcut' "已移除的 Windows 一键切换仍可从菜单执行：$file"
    assert_not_contains "$source_text" 'modules/dual_system_tools.sh" windows-next' "已移除的 Windows 立即切换仍可从菜单执行：$file"
done

echo "PASS: 九分类导航、关键动作和返回坐标映射一致"
