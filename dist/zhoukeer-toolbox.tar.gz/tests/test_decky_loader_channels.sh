#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_ROOT="$(mktemp -d)"
trap 'rm -rf -- "$TMP_ROOT"' EXIT

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

HOME_DIR="$TMP_ROOT/home"
HOMEBREW_DIR="$HOME_DIR/homebrew"
SERVICES_DIR="$HOMEBREW_DIR/services"
PLUGIN_DIR="$HOMEBREW_DIR/plugins"
SETTINGS_DIR="$HOMEBREW_DIR/settings"
UNIT_PATH="$TMP_ROOT/system/plugin_loader.service"
USER_UNIT_PATH="$HOME_DIR/.config/systemd/user/plugin_loader.service"
CALLS="$TMP_ROOT/calls"
SYSTEM_ACTIVE="$TMP_ROOT/system-active"
SYSTEM_ENABLED="$TMP_ROOT/system-enabled"
USER_ACTIVE="$TMP_ROOT/user-active"
USER_ENABLED="$TMP_ROOT/user-enabled"
SYSTEM_RESTART_FAIL="$TMP_ROOT/system-restart-fail"
SYSTEM_UNINSTALL_FAIL="$TMP_ROOT/system-uninstall-fail"
SYSTEM_BACKUP_FAIL="$TMP_ROOT/system-backup-fail"

mkdir -p "$SERVICES_DIR" "$PLUGIN_DIR/KeepMe" "$SETTINGS_DIR" \
    "$(dirname "$UNIT_PATH")" "$(dirname "$USER_UNIT_PATH")"
printf 'plugin-data\n' > "$PLUGIN_DIR/KeepMe/data"

HOME="$HOME_DIR"
ZHOUKEER_DECKY_HOMEBREW_DIR="$HOMEBREW_DIR"
ZHOUKEER_DECKY_UNIT_PATH="$UNIT_PATH"
ZHOUKEER_TEST_MODE=1
ZHOUKEER_AUTO_CONFIRM=1
export HOME ZHOUKEER_DECKY_HOMEBREW_DIR ZHOUKEER_DECKY_UNIT_PATH
export ZHOUKEER_TEST_MODE ZHOUKEER_AUTO_CONFIRM

# shellcheck disable=SC1091
source "$PROJECT_ROOT/modules/plugin_store.sh"

detect_platform() { IS_STEAMOS=1; }
id() {
    case "${1:-}" in
        -u) printf '1000\n' ;;
        -g) printf '1000\n' ;;
        *) command id "$@" ;;
    esac
}
require_command() { return 0; }
MOCK_ATOMUPD_BRANCH=""
MOCK_LEGACY_BRANCH=""
atomupd-manager() {
    [ "${1:-}" = tracked-branch ] && [ -n "$MOCK_ATOMUPD_BRANCH" ] || return 1
    printf '%s\n' "$MOCK_ATOMUPD_BRANCH"
}
steamos-select-branch() {
    [ "${1:-}" = -c ] && [ -n "$MOCK_LEGACY_BRANCH" ] || return 1
    printf '%s\n' "$MOCK_LEGACY_BRANCH"
}

printf '%s\n' \
    'PRETTY_NAME="SteamOS (holo)"' \
    'VERSION_ID="3.6.20"' \
    'VERSION_CODENAME=holo' > "$TMP_ROOT/os-release-stable"
printf '%s\n' \
    'PRETTY_NAME="SteamOS (holo_preview)"' \
    'VERSION_ID="3.6.19"' \
    'VERSION_CODENAME=holo_preview' > "$TMP_ROOT/os-release-preview"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-stable" detect_steamos_channel)"
[ "$detected_channel" = "stable" ] || fail "正式版系统未检测为稳定通道"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-preview" detect_steamos_channel)"
[ "$detected_channel" = "prerelease" ] || fail "预览版系统未检测为测试通道"
MOCK_ATOMUPD_BRANCH="beta"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-stable" detect_steamos_channel)"
[ "$detected_channel" = "prerelease" ] || fail "atomupd beta 分支未检测为测试通道"
MOCK_ATOMUPD_BRANCH="main"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-stable" detect_steamos_channel)"
[ "$detected_channel" = "prerelease" ] || fail "atomupd main 分支未检测为测试通道"
auto_output="$(
    install_plugin_store() { printf 'SELECTED:%s\n' "$1"; }
    install_plugin_store_auto
)"
printf '%s\n' "$auto_output" | grep -Fq 'SELECTED:prerelease' || \
    fail "自动安装未把 atomupd main 分支传给测试版安装流程"
MOCK_ATOMUPD_BRANCH="rel"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-preview" detect_steamos_channel)"
[ "$detected_channel" = "stable" ] || fail "atomupd rel 分支未优先检测为稳定通道"
auto_output="$(
    install_plugin_store() { printf 'SELECTED:%s\n' "$1"; }
    install_plugin_store_auto
)"
printf '%s\n' "$auto_output" | grep -Fq 'SELECTED:stable' || \
    fail "自动安装未把 atomupd rel 分支传给稳定版安装流程"
MOCK_ATOMUPD_BRANCH=""
MOCK_LEGACY_BRANCH="beta"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-stable" detect_steamos_channel)"
[ "$detected_channel" = "prerelease" ] || fail "旧版 beta 分支未检测为测试通道"
MOCK_LEGACY_BRANCH="stable"
detected_channel="$(ZHOUKEER_OS_RELEASE_FILE="$TMP_ROOT/os-release-preview" detect_steamos_channel)"
[ "$detected_channel" = "stable" ] || fail "旧版 stable 分支未优先检测为稳定通道"
MOCK_LEGACY_BRANCH=""

ready_output="$({
    detect_platform() { IS_STEAMOS=1; IS_BAZZITE=0; IS_CHIMERAOS=0; }
    decky_plugin_store_is_installed() { return 0; }
    install_plugin_store_auto() { printf 'TEST_VERSION_CHECK:%s\n' "$1"; }
    ensure_plugin_store_ready
})"
printf '%s\n' "$ready_output" | grep -Fq 'TEST_VERSION_CHECK:if-needed' || \
    fail "插件组合检测到已有商城后没有继续检查版本"

mock_systemctl() {
    local scope="$1"
    shift
    local active_file enabled_file

    if [ "$scope" = user ]; then
        active_file="$USER_ACTIVE"
        enabled_file="$USER_ENABLED"
    else
        active_file="$SYSTEM_ACTIVE"
        enabled_file="$SYSTEM_ENABLED"
    fi
    printf '%s %s\n' "$scope" "$*" >> "$CALLS"
    case "${1:-}" in
        is-active) [ -f "$active_file" ] ;;
        is-enabled) [ -f "$enabled_file" ] ;;
        stop) rm -f -- "$active_file" ;;
        start|restart)
            if [ "$scope" = system ] && [ "${1:-}" = restart ] && \
               [ -f "$SYSTEM_RESTART_FAIL" ]; then
                rm -f -- "$SYSTEM_RESTART_FAIL"
                return 1
            fi
            : > "$active_file"
            ;;
        enable) : > "$enabled_file" ;;
        disable)
            rm -f -- "$enabled_file"
            [ "${2:-}" != "--now" ] || rm -f -- "$active_file"
            ;;
        daemon-reload)
            if [ "$scope" = system ] && [ -f "$SYSTEM_UNINSTALL_FAIL" ] && \
               [ ! -e "$UNIT_PATH" ]; then
                rm -f -- "$SYSTEM_UNINSTALL_FAIL"
                return 1
            fi
            return 0
            ;;
        *) return 0 ;;
    esac
}

systemctl() {
    [ "${1:-}" = "--user" ] || return 1
    shift
    mock_systemctl user "$@"
}

toolbox_sudo() {
    if [ "${1:-}" = systemctl ]; then
        shift
        mock_systemctl system "$@"
    else
        printf 'sudo %s\n' "$*" >> "$CALLS"
        "$@"
    fi
}

install() {
    printf 'install %s\n' "$*" >> "$CALLS"
    command install "$@"
}

cp() {
    if [ -f "$SYSTEM_BACKUP_FAIL" ] && [[ "${*: -1}" == "$UNIT_PATH.backup."* ]]; then
        printf 'partial backup\n' > "${*: -1}"
        rm -f -- "$SYSTEM_BACKUP_FAIL"
        return 1
    fi
    command cp "$@"
}

mv() {
    # 激活新本体时，旧本体、版本标记、两类服务和历史模板都必须已卸载。
    if [[ " $* " == *"/.PluginLoader.new."* ]]; then
        for old_path in "$SERVICES_DIR/PluginLoader" "$SERVICES_DIR/.loader.version" \
            "$UNIT_PATH" "$USER_UNIT_PATH" \
            "$SERVICES_DIR/.systemd/plugin_loader.service" \
            "$SERVICES_DIR/.systemd/plugin_loader-release.service" \
            "$SERVICES_DIR/.systemd/plugin_loader-prerelease.service"; do
            [ ! -e "$old_path" ] && [ ! -L "$old_path" ] || \
                fail "新商城写入前未卸载旧文件：$old_path"
        done
        for old_state in "$SYSTEM_ACTIVE" "$SYSTEM_ENABLED" "$USER_ACTIVE" "$USER_ENABLED"; do
            [ ! -e "$old_state" ] || fail "新商城写入前未停用旧服务：$old_state"
        done
        printf 'publish-loader\n' >> "$CALLS"
    fi
    command mv "$@"
}

write_mock_decky_component() {
    local name="$1"
    local source_url="$2"
    local output="$3"

    case "$name" in
        'Decky PluginLoader') printf '#!/bin/sh\nexit 0\n' > "$output" ;;
        'Decky systemd服务模板')
            cat > "$output" <<'SERVICE'
[Unit]
Description=SteamDeck Plugin Loader
After=network.target
[Service]
Type=simple
User=root
Restart=always
ExecStart=${HOMEBREW_FOLDER}/services/PluginLoader
WorkingDirectory=${HOMEBREW_FOLDER}/services
Environment=UNPRIVILEGED_PATH=${HOMEBREW_FOLDER}
Environment=PRIVILEGED_PATH=${HOMEBREW_FOLDER}
Environment=LOG_LEVEL=INFO
[Install]
WantedBy=multi-user.target
SERVICE
            if [[ "$source_url" == *prerelease* ]]; then
                sed -i.bak 's/LOG_LEVEL=INFO/LOG_LEVEL=DEBUG/' "$output"
            fi
            ;;
        *) return 1 ;;
    esac
}

GITEE_FAIL=0
printf '#!/bin/sh\nexit 0\n' > "$TMP_ROOT/mock-loader"
MOCK_LOADER_SHA="$(calculate_decky_sha256 "$TMP_ROOT/mock-loader")"
cat > "$TMP_ROOT/mock-release.service" <<'SERVICE'
[Unit]
Description=SteamDeck Plugin Loader
After=network.target
[Service]
Type=simple
User=root
Restart=always
ExecStart=${HOMEBREW_FOLDER}/services/PluginLoader
WorkingDirectory=${HOMEBREW_FOLDER}/services
Environment=UNPRIVILEGED_PATH=${HOMEBREW_FOLDER}
Environment=PRIVILEGED_PATH=${HOMEBREW_FOLDER}
Environment=LOG_LEVEL=INFO
[Install]
WantedBy=multi-user.target
SERVICE
cat > "$TMP_ROOT/mock-prerelease.service" <<'SERVICE'
[Unit]
Description=SteamDeck Plugin Loader
After=network.target
[Service]
Type=simple
User=root
Restart=always
ExecStart=${HOMEBREW_FOLDER}/services/PluginLoader
WorkingDirectory=${HOMEBREW_FOLDER}/services
Environment=UNPRIVILEGED_PATH=${HOMEBREW_FOLDER}
Environment=PRIVILEGED_PATH=${HOMEBREW_FOLDER}
Environment=LOG_LEVEL=DEBUG
[Install]
WantedBy=multi-user.target
SERVICE
MOCK_RELEASE_SERVICE_SHA="$(calculate_decky_sha256 "$TMP_ROOT/mock-release.service")"
MOCK_PRERELEASE_SERVICE_SHA="$(calculate_decky_sha256 "$TMP_ROOT/mock-prerelease.service")"
cat > "$TMP_ROOT/gitee-latest.txt" <<EOF
stable_version=v3.2.8
stable_parts=1
stable_sha256=$MOCK_LOADER_SHA
stable_part_sha256=$MOCK_LOADER_SHA
stable_service_sha256=$MOCK_RELEASE_SERVICE_SHA
prerelease_version=v3.2.8-pre1
prerelease_parts=1
prerelease_sha256=$MOCK_LOADER_SHA
prerelease_part_sha256=$MOCK_LOADER_SHA
prerelease_service_sha256=$MOCK_PRERELEASE_SERVICE_SHA
EOF

download_decky_component_with_fallback() {
    local name="$1"
    local primary_url="$2"
    local official_url="$3"
    local expected_sha256="$4"
    local output="$5"

    printf 'download %s|%s|%s|%s\n' \
        "$name" "$primary_url" "$official_url" "$expected_sha256" >> "$CALLS"
    write_mock_decky_component "$name" "$primary_url" "$output"
}

download_github_file() {
    local url="$1"
    local output="$2"
    local expected_sha256="$3"
    local name="$4"

    printf 'github %s|%s|%s\n' \
        "$name" "$url" "$expected_sha256" >> "$CALLS"
    case "$name" in
        'Decky PluginLoader分块'*) echo "正在下载 $name..." ;;
    esac
    case "$url" in
        */decky-installer-cn/latest.txt)
            [ "$GITEE_FAIL" -eq 0 ] || return 1
            cp "$TMP_ROOT/gitee-latest.txt" "$output"
            ;;
        */decky-installer-cn/PluginLoader.part.00|*/decky-installer-cn/PluginLoader-pre.part.00)
            [ "$GITEE_FAIL" -eq 0 ] || return 1
            printf '#!/bin/sh\nexit 0\n' > "$output"
            ;;
        */decky-installer-cn/plugin_loader-release.service)
            [ "$GITEE_FAIL" -eq 0 ] || return 1
            cp "$TMP_ROOT/mock-release.service" "$output"
            ;;
        */decky-installer-cn/plugin_loader-prerelease.service)
            [ "$GITEE_FAIL" -eq 0 ] || return 1
            cp "$TMP_ROOT/mock-prerelease.service" "$output"
            ;;
        *)
            write_mock_decky_component "$name" "$url" "$output"
            ;;
    esac
}

download_decky_gitee_part() {
    local name="$1"
    local url="$2"
    local expected_sha256="$3"
    local output="$4"
    local progress_index="${5:-0}"
    local progress_total="${6:-1}"

    printf 'gitee-part %s|%s|%s|%s|%s\n' \
        "$name" "$url" "$expected_sha256" "$progress_index" "$progress_total" >> "$CALLS"
    [ "$GITEE_FAIL" -eq 0 ] || return 1
    case "$url" in
        */decky-installer-cn/PluginLoader.part.00|*/decky-installer-cn/PluginLoader-pre.part.00)
            printf '#!/bin/sh\nexit 0\n' > "$output"
            ;;
        *) return 1 ;;
    esac
}

prepare_old_testing_install() {
    printf '#!/bin/sh\nexit 0\n' > "$SERVICES_DIR/PluginLoader"
    chmod +x "$SERVICES_DIR/PluginLoader"
    printf 'PR-123\n' > "$SERVICES_DIR/.loader.version"
    printf '{"branch": 2, "keep": "yes"}\n' > "$SETTINGS_DIR/loader.json"
    printf '[Service]\n' > "$UNIT_PATH"
    printf '[Service]\n' > "$USER_UNIT_PATH"
    mkdir -p "$SERVICES_DIR/.systemd"
    for service_file in plugin_loader.service plugin_loader-release.service \
        plugin_loader-prerelease.service; do
        printf 'legacy %s\n' "$service_file" > "$SERVICES_DIR/.systemd/$service_file"
    done
    : > "$SYSTEM_ACTIVE"
    : > "$SYSTEM_ENABLED"
    : > "$USER_ACTIVE"
    : > "$USER_ENABLED"
}

prepare_old_testing_install
install_plugin_store stable > "$TMP_ROOT/stable.output" || \
    fail "旧测试版无法切换到稳定版"
if grep -Eq '分块|卸载' "$TMP_ROOT/stable.output"; then
    fail "稳定版插件商城显示了内部下载或卸载步骤"
fi
grep -Fxq 'v3.2.8' "$SERVICES_DIR/.loader.version" || \
    fail "稳定版安装未更新版本标记"
grep -Eq '"branch"[[:space:]]*:[[:space:]]*0' "$SETTINGS_DIR/loader.json" || \
    fail "稳定版安装未切换到稳定分支"
grep -Fq '"keep": "yes"' "$SETTINGS_DIR/loader.json" || \
    fail "稳定版切换覆盖了其他 Decky 设置"
[ ! -e "$USER_UNIT_PATH" ] || fail "稳定版安装未清理旧用户服务文件"
[ -f "$PLUGIN_DIR/KeepMe/data" ] || fail "稳定版安装删除了现有插件"
[ ! -e "$SERVICES_DIR/.systemd" ] || fail "重新安装后仍留下旧服务模板"
grep -Fxq 'publish-loader' "$CALLS" || fail "未验证先卸载再安装的执行顺序"
grep -Fq 'user disable --now plugin_loader.service' "$CALLS" || \
    fail "稳定版安装未停用旧测试版用户服务"
grep -Fq 'gitee-part Decky PluginLoader|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/decky-installer-cn/PluginLoader.part.00|' \
    "$CALLS" || fail "稳定版未优先使用 Gitee 国内镜像"
grep -Fq '|0|1' "$CALLS" || fail "稳定版 Gitee 下载没有传递总体进度"
grep -Fq 'github Decky systemd服务模板|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/decky-installer-cn/plugin_loader-release.service|' \
    "$CALLS" || fail "稳定版服务模板未使用 Gitee 镜像"
if grep -Fq "download Decky PluginLoader|$DECKY_LOADER_URL|$DECKY_LOADER_OFFICIAL_URL" "$CALLS"; then
    fail "Gitee 镜像成功时稳定版仍回退到国内/官方线路"
fi
stable_stop_line="$(grep -n 'system stop plugin_loader.service' "$CALLS" | head -n 1 | cut -d: -f1)"
stable_user_stop_line="$(grep -n 'user disable --now plugin_loader.service' "$CALLS" | head -n 1 | cut -d: -f1)"
stable_install_line="$(grep -n '^install -m 0755 .*PluginLoader.new' "$CALLS" | head -n 1 | cut -d: -f1)"
[ -n "$stable_stop_line" ] && [ -n "$stable_user_stop_line" ] && \
    [ -n "$stable_install_line" ] && [ "$stable_stop_line" -lt "$stable_install_line" ] && \
    [ "$stable_user_stop_line" -lt "$stable_install_line" ] || \
    fail "稳定版未在写入新文件前停用系统级和用户级旧服务"

# 明确点击安装时，即使版本相同也要先卸载旧本体再安装。
: > "$CALLS"
printf '#!/bin/sh\n# stale loader\n' > "$SERVICES_DIR/PluginLoader"
install_plugin_store stable > "$TMP_ROOT/stable-current.output" || \
    fail "当前稳定版无法重新安装"
grep -Fxq 'publish-loader' "$CALLS" || fail "当前版本仍跳过重新安装"
if grep -Fq 'stale loader' "$SERVICES_DIR/PluginLoader"; then
    fail "当前版本重新安装后保留了旧本体"
fi

# 安装普通插件时沿用已有的当前商城，避免每个插件都重装商城。
: > "$CALLS"
install_plugin_store stable if-needed > "$TMP_ROOT/stable-check.output" || \
    fail "当前稳定版的版本检查失败"
grep -Fq '当前已是该系统通道的最新版本' "$TMP_ROOT/stable-check.output" || \
    fail "当前稳定版未报告已经是最新版本"
if grep -Eq 'gitee-part|system restart|^install ' "$CALLS"; then
    fail "当前稳定版仍重复下载或重启服务"
fi

# 新文件下载失败时不应先卸载旧商城。
: > "$CALLS"
if (
    load_decky_gitee_mirror_meta() { return 1; }
    download_decky_component_with_fallback() { return 1; }
    install_plugin_store stable
) > "$TMP_ROOT/download-failed.output" 2>&1; then
    fail "下载失败仍报告安装成功"
fi
grep -Fxq 'v3.2.8' "$SERVICES_DIR/.loader.version" || fail "下载失败删除了旧版本标记"
[ -x "$SERVICES_DIR/PluginLoader" ] && [ -f "$UNIT_PATH" ] || fail "下载失败卸载了旧商城"
if grep -Eq 'system (stop|disable|restart)|publish-loader' "$CALLS"; then
    fail "新文件下载完成前已改动旧服务"
fi

# 备份写入失败时不卸载旧商城，也不能留下阻止再次安装的残片。
prepare_old_testing_install
: > "$CALLS"
: > "$SYSTEM_BACKUP_FAIL"
if install_plugin_store stable > "$TMP_ROOT/backup-failed.output" 2>&1; then
    fail "备份写入失败仍继续安装"
fi
grep -Fxq 'PR-123' "$SERVICES_DIR/.loader.version" || fail "备份失败改动了旧版本标记"
grep -Fxq '[Service]' "$UNIT_PATH" || fail "备份失败破坏了旧服务文件"
for old_state in "$SYSTEM_ACTIVE" "$SYSTEM_ENABLED" "$USER_ACTIVE" "$USER_ENABLED"; do
    [ -f "$old_state" ] || fail "备份失败未恢复旧服务状态：$old_state"
done
if grep -Fq 'publish-loader' "$CALLS"; then
    fail "备份失败仍写入了新商城"
fi
install_plugin_store stable >/dev/null || fail "备份失败清理后无法重新安装"

# 卸载过程中失败时恢复全部原文件和服务状态。
prepare_old_testing_install
: > "$SYSTEM_UNINSTALL_FAIL"
if install_plugin_store stable > "$TMP_ROOT/uninstall-failed.output" 2>&1; then
    fail "旧商城卸载失败仍继续安装"
fi
grep -Fxq 'PR-123' "$SERVICES_DIR/.loader.version" || fail "卸载失败未恢复旧版本标记"
[ -f "$UNIT_PATH" ] && [ -f "$USER_UNIT_PATH" ] || fail "卸载失败未恢复旧服务文件"
for service_file in plugin_loader.service plugin_loader-release.service plugin_loader-prerelease.service; do
    grep -Fxq "legacy $service_file" "$SERVICES_DIR/.systemd/$service_file" || \
        fail "卸载失败未恢复旧模板：$service_file"
done
for old_state in "$SYSTEM_ACTIVE" "$SYSTEM_ENABLED" "$USER_ACTIVE" "$USER_ENABLED"; do
    [ -f "$old_state" ] || fail "卸载失败未恢复旧服务状态：$old_state"
done
install_plugin_store stable >/dev/null || fail "卸载失败恢复后无法重试安装"

# 新服务启动失败时，必须恢复稳定版文件、通道和旧用户服务状态。
: > "$SYSTEM_RESTART_FAIL"
printf '[Service]\n' > "$USER_UNIT_PATH"
: > "$USER_ACTIVE"
: > "$USER_ENABLED"
mkdir -p "$SERVICES_DIR/.systemd"
printf 'old template\n' > "$SERVICES_DIR/.systemd/plugin_loader-release.service"
if install_plugin_store prerelease > "$TMP_ROOT/rollback.output" 2>&1; then
    fail "测试版启动失败时仍报告安装成功"
fi
grep -Fxq 'v3.2.8' "$SERVICES_DIR/.loader.version" || \
    fail "测试版启动失败后未恢复稳定版版本标记"
grep -Eq '"branch"[[:space:]]*:[[:space:]]*0' "$SETTINGS_DIR/loader.json" || \
    fail "测试版启动失败后未恢复稳定分支"
[ -f "$USER_ACTIVE" ] && [ -f "$USER_ENABLED" ] || \
    fail "测试版启动失败后未恢复旧用户服务状态"
[ -f "$USER_UNIT_PATH" ] || fail "测试版启动失败后未恢复旧用户服务文件"
grep -Fxq 'old template' "$SERVICES_DIR/.systemd/plugin_loader-release.service" || \
    fail "测试版启动失败后未恢复旧服务模板"
[ -f "$SYSTEM_ACTIVE" ] && [ -f "$SYSTEM_ENABLED" ] || \
    fail "测试版启动失败后未恢复系统服务状态"
rm -f -- "$SYSTEM_RESTART_FAIL"

: > "$CALLS"
printf '[Service]\n' > "$USER_UNIT_PATH"
: > "$SYSTEM_ACTIVE"
: > "$USER_ACTIVE"
: > "$USER_ENABLED"
install_plugin_store prerelease > "$TMP_ROOT/prerelease.output" || \
    fail "Decky 官方测试版安装失败"
if grep -Eq '分块|卸载' "$TMP_ROOT/prerelease.output"; then
    fail "测试版插件商城显示了内部下载或卸载步骤"
fi
grep -Fxq 'v3.2.8-pre1' "$SERVICES_DIR/.loader.version" || \
    fail "测试版安装未更新版本标记"
grep -Eq '"branch"[[:space:]]*:[[:space:]]*1' "$SETTINGS_DIR/loader.json" || \
    fail "测试版安装未切换到预发布分支"
grep -Fq 'gitee-part Decky PluginLoader|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/decky-installer-cn/PluginLoader-pre.part.00|' \
    "$CALLS" || fail "测试版未优先使用 Gitee 国内镜像"
grep -Fq '|0|1' "$CALLS" || fail "测试版 Gitee 下载没有传递总体进度"
grep -Fq 'github Decky systemd服务模板|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/decky-installer-cn/plugin_loader-prerelease.service|' \
    "$CALLS" || fail "测试版服务模板未使用 Gitee 镜像"
if grep -Fq "$DECKY_PRERELEASE_LOADER_URL" "$CALLS"; then
    fail "Gitee 镜像成功时测试版仍回退到官方 GitHub"
fi
if grep -Fq 'www.mhhf.com' "$CALLS"; then
    fail "测试版安装错误使用了国内源"
fi
prerelease_stop_line="$(grep -n 'system stop plugin_loader.service' "$CALLS" | head -n 1 | cut -d: -f1)"
prerelease_user_stop_line="$(grep -n 'user disable --now plugin_loader.service' "$CALLS" | head -n 1 | cut -d: -f1)"
prerelease_install_line="$(grep -n '^install -m 0755 .*PluginLoader.new' "$CALLS" | head -n 1 | cut -d: -f1)"
[ -n "$prerelease_stop_line" ] && [ -n "$prerelease_user_stop_line" ] && \
    [ -n "$prerelease_install_line" ] && \
    [ "$prerelease_stop_line" -lt "$prerelease_install_line" ] && \
    [ "$prerelease_user_stop_line" -lt "$prerelease_install_line" ] || \
    fail "测试版未在写入新文件前停用系统级和用户级旧服务"
grep -Fq 'LOG_LEVEL=DEBUG' "$UNIT_PATH" || fail "测试版未安装官方预发布服务模板"

# GitHub 与 Gitee 使用独立发布历史；自动镜像必须在 Gitee v2 当前历史上提交，
# 不能再把 GitHub main 直接推到旧仓库，否则会因 non-fast-forward 永久失败。
SYNC_WORKFLOW="$PROJECT_ROOT/.github/workflows/sync-decky-gitee.yml"
grep -Fq 'zhoukeer-toolbox-v2.git' "$SYNC_WORKFLOW" || \
    fail "Decky 自动镜像未指向当前 Gitee v2 仓库"
grep -Fq 'git clone --depth 1 --filter=blob:none --sparse' "$SYNC_WORKFLOW" || \
    fail "Decky 自动镜像未基于 Gitee 当前历史创建普通提交"
grep -Fq 'sparse-checkout set decky-installer-cn' "$SYNC_WORKFLOW" || \
    fail "Decky 自动镜像未限制为 Decky 目录"
grep -Fq 'GITHUB_TOKEN: ${{ github.token }}' "$SYNC_WORKFLOW" || \
    fail "Decky 自动镜像未使用 GitHub Actions 令牌降低 API 限流"
grep -Fq -- '--retry "$CURL_RETRIES"' "$PROJECT_ROOT/scripts/sync_decky_gitee.sh" || \
    fail "Decky 自动镜像未对上游临时 5xx 执行重试"
grep -Fq 'keep_existing_mirror' "$PROJECT_ROOT/scripts/sync_decky_gitee.sh" || \
    fail "Decky 上游暂时不可用时不会保留现有镜像"
grep -Fq 'STAGED_DECKY_DIR' "$PROJECT_ROOT/scripts/sync_decky_gitee.sh" || \
    fail "Decky 自动镜像没有先完成双通道暂存校验"
grep -Fq 'decky-loader-stable|Decky Loader 稳定版|v3.2.8|PluginLoader|' \
    "$PROJECT_ROOT/scripts/mirror_gitee_assets.sh" || \
    fail "开发镜像清单仍指向旧版 Decky 稳定版"
grep -Fq 'VERSION="v3.2.8"' "$PROJECT_ROOT/decky-installer-cn/install_release.sh" || \
    fail "旧稳定版安装入口仍指向 v3.2.6"
grep -Fq '当前已是所选通道的最新版本' \
    "$PROJECT_ROOT/decky-installer-cn/install_latest.sh" || \
    fail "独立最新版安装器缺少当前版本检测"
if grep -Fq 'zhoukeer-toolbox.git"' "$SYNC_WORKFLOW" || \
   grep -Fq 'git push gitee main' "$SYNC_WORKFLOW"; then
    fail "Decky 自动镜像仍直接推送旧 Gitee 仓库或分叉历史"
fi

# 上游持续 5xx 时工作流应成功保留现有镜像，不得清空或改写已有文件。
SYNC_FAIL_BIN="$TMP_ROOT/sync-fail-bin"
SYNC_FAIL_DIR="$TMP_ROOT/sync-existing"
SYNC_FAIL_LOG="$TMP_ROOT/sync-fail.output"
mkdir -p "$SYNC_FAIL_BIN" "$SYNC_FAIL_DIR"
cat > "$SYNC_FAIL_BIN/curl" <<'SCRIPT'
#!/bin/bash
exit 22
SCRIPT
chmod +x "$SYNC_FAIL_BIN/curl"
printf 'existing verified mirror\n' > "$SYNC_FAIL_DIR/latest.txt"
PATH="$SYNC_FAIL_BIN:$PATH" \
ZHOUKEER_DECKY_SYNC_DIR="$SYNC_FAIL_DIR" \
ZHOUKEER_DECKY_SYNC_CURL_RETRIES=1 \
ZHOUKEER_DECKY_SYNC_CURL_RETRY_DELAY=0 \
    bash "$PROJECT_ROOT/scripts/sync_decky_gitee.sh" > "$SYNC_FAIL_LOG" 2>&1 || \
    fail "Decky 上游持续 5xx 时工作流仍返回失败"
grep -Fq '保留现有已校验 Decky 镜像' "$SYNC_FAIL_LOG" || \
    fail "Decky 上游持续 5xx 时未明确说明保留现有镜像"
grep -Fxq 'existing verified mirror' "$SYNC_FAIL_DIR/latest.txt" || \
    fail "Decky 上游持续 5xx 时破坏了现有镜像"

# Gitee 镜像不可用时，必须回退到原有国内/官方线路。
: > "$CALLS"
GITEE_FAIL=1
install_plugin_store stable >/dev/null || \
    fail "Gitee 镜像失败后稳定版未回退既有线路"
grep -Fq "download Decky PluginLoader|$DECKY_LOADER_URL|$DECKY_LOADER_OFFICIAL_URL" \
    "$CALLS" || fail "Gitee 镜像失败后稳定版未使用国内到官方的回退顺序"
: > "$CALLS"
install_plugin_store prerelease >/dev/null || \
    fail "Gitee 镜像失败后测试版未回退官方 Release"
grep -Fq "github Decky PluginLoader|$DECKY_PRERELEASE_LOADER_URL|$DECKY_PRERELEASE_LOADER_SHA256" \
    "$CALLS" || fail "Gitee 镜像失败后测试版未使用统一 GitHub Release 下载流程"
GITEE_FAIL=0

mkdir -p "$SERVICES_DIR/.systemd"
for service_file in plugin_loader.service plugin_loader-release.service \
    plugin_loader-prerelease.service; do
    printf '[Service]\n' > "$SERVICES_DIR/.systemd/$service_file"
done
printf '[Service]\n' > "$USER_UNIT_PATH"
: > "$SYSTEM_ACTIVE"
: > "$SYSTEM_ENABLED"
: > "$USER_ACTIVE"
: > "$USER_ENABLED"
uninstall_plugin_store > "$TMP_ROOT/uninstall.output" || \
    fail "稳定版与测试版统一卸载失败"
for removed in \
    "$SERVICES_DIR/PluginLoader" \
    "$SERVICES_DIR/.loader.version" \
    "$UNIT_PATH" \
    "$USER_UNIT_PATH" \
    "$SERVICES_DIR/.systemd/plugin_loader.service" \
    "$SERVICES_DIR/.systemd/plugin_loader-release.service" \
    "$SERVICES_DIR/.systemd/plugin_loader-prerelease.service"; do
    [ ! -e "$removed" ] || fail "卸载后仍残留：$removed"
done
[ ! -e "$SERVICES_DIR/.systemd" ] || fail "卸载后仍残留 .systemd 目录"
[ ! -e "$SERVICES_DIR" ] || fail "卸载后仍残留 services 目录"
[ -f "$PLUGIN_DIR/KeepMe/data" ] || fail "卸载 Decky Loader 删除了插件"
[ -f "$SETTINGS_DIR/loader.json" ] || fail "卸载 Decky Loader 删除了设置"

install_plugin_store stable > "$TMP_ROOT/fresh.output" || fail "首次安装商城失败"
[ -x "$SERVICES_DIR/PluginLoader" ] && [ -f "$UNIT_PATH" ] || fail "首次安装未写入商城"
grep -Fxq 'plugin-data' "$PLUGIN_DIR/KeepMe/data" || fail "首次安装改动了插件数据"

UNIFIDECK_SOURCE="$TMP_ROOT/unifideck-source"
UNIFIDECK_ARCHIVE="$TMP_ROOT/unifideck.zip"
UNIFIDECK_PLUGIN_ROOT="$TMP_ROOT/unifideck-plugins"
mkdir -p "$UNIFIDECK_SOURCE/Unifideck/dist" "$UNIFIDECK_PLUGIN_ROOT"
printf '{"name":"Unifideck"}\n' > "$UNIFIDECK_SOURCE/Unifideck/plugin.json"
printf 'bundle\n' > "$UNIFIDECK_SOURCE/Unifideck/dist/index.js"
(cd "$UNIFIDECK_SOURCE" && zip -qr "$UNIFIDECK_ARCHIVE" Unifideck)
download_verified_package() { cp -- "$UNIFIDECK_ARCHIVE" "$4"; }
DECKY_PLUGIN_DIR="$UNIFIDECK_PLUGIN_ROOT"
export DECKY_PLUGIN_DIR
(install_decky_zip "Unifideck" "https://example.invalid/unifideck.zip" \
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" \
    "Unifideck" 0) || fail "Unifideck 官方大写目录结构仍无法安装"
[ -s "$UNIFIDECK_PLUGIN_ROOT/Unifideck/dist/index.js" ] || \
    fail "Unifideck 未写入正确的大写目录"

echo "PASS: Decky 先卸载再安装、同版重装、失败恢复、插件保留和下载回退模拟通过"
