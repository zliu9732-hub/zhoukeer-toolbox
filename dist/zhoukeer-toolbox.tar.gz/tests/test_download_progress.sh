#!/bin/bash

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

fail() {
    echo "FAIL: $1" >&2
    exit 1
}

function_section() {
    local file="$1"
    local start="$2"
    local end="$3"

    sed -n "/^${start}()/,/^${end}()/p" "$PROJECT_ROOT/$file"
}

assert_payload_progress() {
    local file="$1"
    local start="$2"
    local end="$3"
    local allow_conditional_silent="${4:-0}"
    local body

    body="$(function_section "$file" "$start" "$end")"
    [ -n "$body" ] || fail "没有找到下载函数：$file $start"
    grep -Fq -- '--progress-meter' <<< "$body" || \
        fail "$file 的 $start 没有显示实时下载速度"
    if grep -Fq -- '--silent' <<< "$body"; then
        if [ "$allow_conditional_silent" = "1" ]; then
            grep -Fq 'if [ "$quiet" = "1" ]; then' <<< "$body" || \
                fail "$file 的 $start 的静默开关未限制在 quiet 分支"
        else
            fail "$file 的 $start 仍用静默模式隐藏下载进度"
        fi
    fi
}

assert_payload_progress utils/github_download.sh download_github_file _parse_latest_github_release 1
assert_payload_progress modules/software.sh install_official_qq_appimage install_official_wechat_appimage
assert_payload_progress modules/software.sh install_official_wechat_appimage install_rustdesk_appimage
assert_payload_progress modules/software.sh install_firefox_archive software_is_installed
assert_payload_progress modules/game_launchers.sh download_launcher_installer find_steam_root
assert_payload_progress utils/gitee_download.sh _gitee_mirror_download_one download_gitee_mirror_file 1
assert_payload_progress modules/todesk.sh download_todesk_package has_trusted_ca_bundle
assert_payload_progress modules/plugin_store.sh download_decky_component download_decky_component_with_fallback
assert_payload_progress update.sh download_one download_version_one
assert_payload_progress bootstrap.sh download_one valid_sha256
grep -Eq '^download_progress_filter\(\)' "$PROJECT_ROOT/bootstrap.sh" || \
    fail "bootstrap.sh 缺少独立 download_progress_filter 定义"
if grep -Fq 'GITEE_MIRROR_QUIET=1' "$PROJECT_ROOT/utils/gitee_download.sh"; then
    fail "国内镜像实际文件下载仍然隐藏进度"
fi
gitee_progress="$(function_section utils/gitee_download.sh download_gitee_mirror_file resolve_latest_gitee_mirror)"
grep -Fq '"$((index - 1))"' <<< "$gitee_progress" || \
    fail "国内镜像没有换算连续总进度"
launcher_progress="$(function_section modules/game_launchers.sh download_preinstalled_launcher_parts \
    verify_preinstalled_launcher_parts)"
grep -Fq '"$((index - 1))"' <<< "$launcher_progress" || \
    fail "预装启动器下载没有换算连续总进度"
plugin_archive_progress="$(function_section modules/plugin_store.sh install_decky_zip_from_mirror \
    reload_decky_plugins)"
if grep -Fq '"$display_name" >/dev/null 2>&1' <<< "$plugin_archive_progress"; then
    fail "FSR4 等完整插件包仍然隐藏下载进度"
fi
launcher_cover_progress="$(function_section modules/game_launchers.sh ensure_launcher_covers_cached \
    launcher_cover_path)"
if grep -Fq '"$LAUNCHER_COVER_BUNDLE_NAME" >/dev/null 2>&1' <<< "$launcher_cover_progress"; then
    fail "游戏启动器封面资源仍然隐藏下载进度"
fi

# curl --progress-meter 自带的英文表头、警告和错误不能漏到终端。
# shellcheck disable=SC1090
source "$PROJECT_ROOT/core/download_policy.sh"
filtered="$(
    printf '%s\n' \
        '  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current' \
        '                                 Dload  Upload   Total   Spent    Left  Speed' \
        '  100  1234  100  1234    0     0   5678      0 --:--:-- --:--:-- --:--:--  5678' \
        'curl: (28) Operation timed out' \
        'warning: some proxy warning' |
        download_progress_filter "测试下载"
)"
grep -Fq '正在下载 测试下载' <<< "$filtered" || \
    fail "实时下载速度被过滤掉了"
grep -Fq '[####################] 100%（5678 B/s）' <<< "$filtered" || \
    fail "下载没有同时显示完整进度条、百分比和实时速度"
if grep -Eq 'Dload|% Total|curl: \(|warning:' <<< "$filtered"; then
    fail "curl 英文表头/警告/错误泄漏到终端"
fi

multi_segment="$({
    printf '%s\n' \
        '  100  1234  100  1234    0     0   1500k      0 --:--:-- --:--:-- --:--:-- 1500k' |
        download_progress_filter "多文件测试" 0 2
    printf '%s\n' \
        '  100  1234  100  1234    0     0   1600k      0 --:--:-- --:--:-- --:--:-- 1600k' |
        download_progress_filter "多文件测试" 1 2
})"
case "$multi_segment" in
    *$'\n'*) fail "多文件下载在中间文件完成后仍然换行" ;;
esac
grep -Fq '] 50%（1500 KB/s）' <<< "$multi_segment" || \
    fail "多文件下载首段总体百分比错误"
grep -Fq '] 100%（1600 KB/s）' <<< "$multi_segment" || \
    fail "多文件下载最终总体百分比错误"
failure_joined="$({
    printf '%s\n' 'curl: (28) Operation timed out' |
        download_progress_filter "失败测试" 0 2
    printf 'ERROR'
})"
[ "$failure_joined" = $'\nERROR' ] || \
    fail "多文件下载失败后没有结束当前进度行"

# GUI 动作会把程序输出接入日志管道；在真实 TTY 中，进度必须绕过该管道
# 直接刷新终端，否则日志层可能把每次回车刷新展开成多行。
if command -v script >/dev/null 2>&1; then
    tty_test_root="$(mktemp -d)"
    tty_runner="$tty_test_root/runner.sh"
    tty_pipe_log="$tty_test_root/pipe.log"
    tty_capture="$tty_test_root/tty.log"
    printf '%s\n' \
        '#!/bin/bash' \
        'source "$PROJECT_ROOT/core/download_policy.sh"' \
        "printf '%s\\n' '  42  1234  42  518    0     0   1531k      0 --:--:-- --:--:-- --:--:-- 1531k' | ZHOUKEER_PROGRESS_DIRECT_TTY=1 download_progress_filter 'TTY测试' | tee \"\$PIPE_CAPTURE\"" \
        > "$tty_runner"
    chmod +x "$tty_runner"
    PROJECT_ROOT="$PROJECT_ROOT" PIPE_CAPTURE="$tty_pipe_log" \
        script -qefc "bash '$tty_runner'" /dev/null > "$tty_capture"
    [ ! -s "$tty_pipe_log" ] || fail "GUI 日志管道仍会收到每一帧下载进度"
    tr '\r' '\n' < "$tty_capture" | \
        grep -Fq '[########------------] 42%（1531 KB/s）' || \
        fail "下载进度没有直接刷新控制终端"
    rm -rf -- "$tty_test_root"
fi

# 版本查询、测速和 API 元数据请求不是安装包下载，必须继续保持静默，
# 否则一次安装会闪出多个没有意义的 100%。
function_section update.sh download_version_one valid_release_version | \
    grep -Fq -- '--silent' || fail "版本查询不应显示伪进度"

if grep -Eq 'flatpak install .*2>/dev/null' "$PROJECT_ROOT/modules/software.sh"; then
    fail "Flatpak 安装仍把原生百分比进度重定向隐藏"
fi

if grep -Eh '^[[:space:]]*(echo|printf|log|ui_touch_button|confirm_and_run|gui_confirm).*分块' \
    "$PROJECT_ROOT/main.sh" \
    "$PROJECT_ROOT/core/gui.sh" \
    "$PROJECT_ROOT/core/download_policy.sh" \
    "$PROJECT_ROOT/modules/plugin_store.sh" \
    "$PROJECT_ROOT/modules/clover_boot.sh" \
    "$PROJECT_ROOT/modules/ge_proton.sh" \
    "$PROJECT_ROOT/decky-installer-cn/install_latest.sh" \
    "$PROJECT_ROOT/decky-installer-cn/install_release.sh" \
    "$PROJECT_ROOT/decky-installer-cn/install_prerelease.sh" >/dev/null; then
    fail "SteamOS 用户界面仍显示内部文件拆分方式"
fi

bootstrap_progress="$(function_section bootstrap.sh download_progress_filter download_one)"
grep -Fq 'bar_width = 20' <<< "$bootstrap_progress" || \
    fail "bootstrap.sh 下载进度缺少 20 格进度条"
grep -Fq 'percent, speed, unit' <<< "$bootstrap_progress" || \
    fail "bootstrap.sh 下载进度没有同时显示百分比和速度"
grep -Fq 'exec 9>/dev/tty' <<< "$bootstrap_progress" || \
    fail "bootstrap.sh 下载进度没有直接刷新控制终端"
grep -Fq 'ZHOUKEER_PROGRESS_DIRECT_TTY=1 "$@"' "$PROJECT_ROOT/core/gui.sh" || \
    fail "GUI 动作没有启用单行终端进度"

echo "PASS: 所有实际下载均以单行进度条显示百分比和实时速度，元数据请求保持静默"
