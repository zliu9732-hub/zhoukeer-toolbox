#!/bin/bash

set -u

DRY_RUN=0
for arg in "$@"; do
    case "$arg" in
        --dry-run)
            DRY_RUN=1
            ;;
        *)
            echo "未知参数: $arg"
            exit 1
            ;;
    esac
done

GITEE_OWNER="${ZHOUKEER_GITEE_OWNER:-zliu9732-hub}"
GITHUB_OWNER="${ZHOUKEER_GITHUB_OWNER:-}"
REPO_NAME="${ZHOUKEER_REPO_NAME:-zhoukeer-toolbox-v2}"
BRANCH="${ZHOUKEER_BRANCH:-main}"
INSTALL_DIR="${ZHOUKEER_INSTALL_DIR:-$HOME/.local/share/zhoukeer-toolbox}"

# 国内 CDN 初次连接可能较慢；保留足够时间和重试后才使用 GitHub 备用源。
CONNECT_TIMEOUT="${ZHOUKEER_CONNECT_TIMEOUT:-20}"
MAX_TIME="${ZHOUKEER_MAX_TIME:-600}"

GITEE_RAW_BASE="${ZHOUKEER_GITEE_RAW_BASE:-https://gitee.com/$GITEE_OWNER/$REPO_NAME/raw/$BRANCH}"
GITHUB_RAW_BASE="${ZHOUKEER_GITHUB_RAW_BASE:-}"
if [ -z "$GITHUB_RAW_BASE" ] && [ -n "$GITHUB_OWNER" ]; then
    GITHUB_RAW_BASE="https://raw.githubusercontent.com/$GITHUB_OWNER/$REPO_NAME/$BRANCH"
fi
DOMAIN_RAW_BASE="${ZHOUKEER_DOMAIN_RAW_BASE:-https://jktool.icu}"
PACKAGE_NAME="${ZHOUKEER_PACKAGE_NAME:-renkit.tar.gz}"
GITEE_PACKAGE_URL="${ZHOUKEER_GITEE_PACKAGE_URL:-$GITEE_RAW_BASE/dist/$PACKAGE_NAME}"
GITHUB_PACKAGE_URL="${ZHOUKEER_GITHUB_PACKAGE_URL:-$GITHUB_RAW_BASE/dist/$PACKAGE_NAME}"
GITEE_VERSION_URL="${ZHOUKEER_GITEE_VERSION_URL:-$GITEE_RAW_BASE/VERSION}"
GITHUB_VERSION_URL="${ZHOUKEER_GITHUB_VERSION_URL:-$GITHUB_RAW_BASE/VERSION}"
GITEE_CHECKSUM_URL="${ZHOUKEER_GITEE_CHECKSUM_URL:-$GITEE_RAW_BASE/dist/SHA256SUMS}"
GITHUB_CHECKSUM_URL="${ZHOUKEER_GITHUB_CHECKSUM_URL:-$GITHUB_RAW_BASE/dist/SHA256SUMS}"
DOMAIN_VERSION_URL="${ZHOUKEER_DOMAIN_VERSION_URL:-$DOMAIN_RAW_BASE/VERSION}"
DOMAIN_PACKAGE_URL="${ZHOUKEER_DOMAIN_PACKAGE_URL:-$DOMAIN_RAW_BASE/dist/$PACKAGE_NAME}"
DOMAIN_CHECKSUM_URL="${ZHOUKEER_DOMAIN_CHECKSUM_URL:-$DOMAIN_RAW_BASE/dist/SHA256SUMS}"

need_command() {
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "缺少命令: $1"
        exit 1
    fi
}

# bootstrap.sh 必须能在Renkit尚未安装时独立运行，因此这里保留受控清单的
# 最小自包含副本；安装完成后的全部下载统一使用 core/download_policy.sh。
bootstrap_url_allowed() {
    case "$1" in
        https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/VERSION|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/dist/SHA256SUMS|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/dist/renkit.tar.gz|https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/VERSION|https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/dist/SHA256SUMS|https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/dist/renkit.tar.gz|https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/main/VERSION|https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/main/dist/SHA256SUMS|https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/main/dist/renkit.tar.gz|https://jktool.icu/VERSION|https://jktool.icu/dist/SHA256SUMS|https://jktool.icu/dist/renkit.tar.gz|https://gitee.com/zliu9732-hub/zhoukeer-toolbox-v2/raw/main/dist/zhoukeer-toolbox.tar.gz|https://gitee.com/zliu9732-hub/zhoukeer-toolbox/raw/main/dist/zhoukeer-toolbox.tar.gz|https://raw.githubusercontent.com/zliu9732-hub/zhoukeer-toolbox/main/dist/zhoukeer-toolbox.tar.gz|https://jktool.icu/dist/zhoukeer-toolbox.tar.gz) return 0 ;;
        https://*) [ "${ZHOUKEER_TEST_MODE:-0}" = "1" ] ;;
        *) return 1 ;;
    esac
}

bootstrap_response_safe() {
    local url="$1" file="$2" size magic
    [ -f "$file" ] && [ ! -L "$file" ] && [ -s "$file" ] || return 1
    size="$(wc -c < "$file" | tr -d ' ')"
    case "$size" in ''|*[!0-9]*) return 1 ;; esac
    [ "$size" -le 9437184 ] || return 1
    if LC_ALL=C head -c 512 "$file" | grep -Eiq '<(!doctype[[:space:]]+html|html[[:space:]>])|access[[:space:]]+denied|error[[:space:]]+403'; then
        return 1
    fi
    case "${url%%\?*}" in
        *.tar.gz)
            magic="$(LC_ALL=C od -An -tx1 -N2 "$file" 2>/dev/null | tr -d ' \n')"
            [ "$magic" = "1f8b" ] || return 1
            ;;
    esac
}

sha256_file() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then
        shasum -a 256 "$1" | awk '{print $1}'
    else
        echo "缺少文件安全检查信息 校验命令: sha256sum 或 shasum"
        exit 1
    fi
}

# 安装完成前 core/download_policy.sh 尚不存在，这里保留独立副本供 bootstrap 使用。
download_progress_filter() {
    local label="${1:-下载}"
    local segment_index="${2:-0}"
    local segment_total="${3:-1}"
    local progress_fd=1
    local progress_chunk=""

    # 有控制终端时绕过外层日志管道直接刷新同一行；无终端时保留 stdout，
    # 便于安装脚本重定向输出和自动测试。
    if [ "${ZHOUKEER_PROGRESS_DIRECT_TTY:-0}" = "1" ] && [ ! -t 1 ] && \
        [ -c /dev/tty ] && exec 9>/dev/tty 2>/dev/null; then
        progress_fd=9
    fi

    # curl 用回车符刷新进度。tr 的块缓冲会把这些刷新积压到下载结束；
    # Bash read 每收到一个回车就立即输出一帧，让后面的 awk 实时渲染。
    while IFS= read -r -d $'\r' progress_chunk || [ -n "$progress_chunk" ]; do
        printf '%s\n' "$progress_chunk"
        progress_chunk=""
    done | awk -v label="$label" \
        -v segment_index="$segment_index" -v segment_total="$segment_total" '
        BEGIN {
            if (segment_index !~ /^[0-9]+$/) segment_index = 0
            if (segment_total !~ /^[1-9][0-9]*$/) segment_total = 1
            if (segment_index >= segment_total) segment_index = 0
            bar_width = 20
        }
        function progress_line(line) {
            return line ~ /^[ ]*[0-9]+[ ]+[0-9]+/ && NF >= 8
        }
        function progress_bar(percent,    filled, result, i) {
            filled = int(percent * bar_width / 100)
            result = ""
            for (i = 0; i < filled; i++) result = result "#"
            for (i = filled; i < bar_width; i++) result = result "-"
            return result
        }
        function render_progress(raw_percent, raw_speed,    percent, speed, unit) {
            if (raw_percent < 0) raw_percent = 0
            if (raw_percent > 100) raw_percent = 100
            percent = int((segment_index * 100 + raw_percent) / segment_total)
            if (percent < last_percent) percent = last_percent
            last_percent = percent
            speed = raw_speed
            unit = "B/s"
            if (speed ~ /[kK]$/) { unit = "KB/s"; speed = substr(speed, 1, length(speed) - 1) }
            else if (speed ~ /[mM]$/) { unit = "MB/s"; speed = substr(speed, 1, length(speed) - 1) }
            else if (speed ~ /[gG]$/) { unit = "GB/s"; speed = substr(speed, 1, length(speed) - 1) }
            printf "\r\033[2K正在下载 %s... [%s] %d%%（%s %s）", \
                label, progress_bar(percent), percent, speed, unit
            fflush()
        }
        {
            line = $0
            lowered = tolower(line)
            if (lowered ~ /^curl: \(/) {
                failed = 1
                next
            }
            if (lowered ~ /warning:/) {
                next
            }
            if (line ~ /% Total/ || line ~ /Dload/ || line ~ /Upload/) {
                next
            }
            if (progress_line(line)) {
                raw_percent = $1 + 0
                if (raw_percent >= 100) {
                    pending_percent = raw_percent
                    pending_speed = $NF
                    have_pending = 1
                    next
                }
                have_pending = 0
                render_progress(raw_percent, $NF)
                next
            }
            if (line != "") print line
        }
        END {
            if (have_pending) render_progress(pending_percent, pending_speed)
            if (failed || segment_index + 1 >= segment_total) printf "\n"
        }
    ' >&"$progress_fd"
    [ "$progress_fd" -ne 9 ] || exec 9>&-
}

run_curl_with_progress() {
    local label="$1" segment_index="${2:-0}" segment_total="${3:-1}"
    local progress_dir progress_fifo progress_pid curl_status
    shift 3

    progress_dir="$(mktemp -d "${TMPDIR:-/tmp}/renkit-progress.XXXXXX")" || return 1
    progress_fifo="$progress_dir/curl.stderr"
    if ! mkfifo "$progress_fifo"; then
        rmdir "$progress_dir" 2>/dev/null || true
        return 1
    fi
    download_progress_filter "$label" "$segment_index" "$segment_total" \
        < "$progress_fifo" >&2 &
    progress_pid=$!
    curl "$@" 2> "$progress_fifo"
    curl_status=$?
    wait "$progress_pid" 2>/dev/null || true
    rm -f -- "$progress_fifo"
    rmdir "$progress_dir" 2>/dev/null || true
    return "$curl_status"
}

download_one() {
    local url="$1"
    local output="$2"
    local label="$3"

    rm -f -- "$output"
    bootstrap_url_allowed "$url" || {
        echo "$label 地址不在受控来源清单中。"
        return 1
    }
    run_curl_with_progress "$label" 0 1 \
        --fail \
        --location \
        --progress-meter \
        --proto '=https' \
        --proto-redir '=https' \
        --connect-timeout "$CONNECT_TIMEOUT" \
        --max-time "$MAX_TIME" \
        --retry 3 \
        --retry-delay 2 \
        --retry-all-errors \
        --max-filesize 9437184 \
        --output "$output" \
        "$url" && \
        bootstrap_response_safe "$url" "$output"
}

valid_sha256() {
    local value="$1"

    [ "${#value}" -eq 64 ] || return 1
    case "$value" in
        *[!0-9A-Fa-f]*) return 1 ;;
    esac
}

checksum_from_manifest() {
    local manifest="$1"
    local package_name="$2"

    awk -v name="$package_name" '
        NF >= 2 {
            file = $2
            sub(/^\*/, "", file)
            if (file == name) {
                print $1
                exit
            }
        }
    ' "$manifest"
}

verify_package() {
    local package_file="$1"
    local expected="$2"
    local actual

    if ! valid_sha256 "$expected"; then
        echo "安装文件安全检查信息无效，请稍后重试。"
        return 1
    fi

    actual="$(sha256_file "$package_file")"
    expected="$(printf '%s' "$expected" | tr '[:upper:]' '[:lower:]')"
    if [ "$actual" != "$expected" ]; then
        echo "文件检查未通过"
        echo "期望: $expected"
        echo "实际: $actual"
        return 1
    fi

}

remove_appledouble_files() {
    local root="$1"

    # macOS 可能生成 ._* AppleDouble 元数据。其文件名会带 .sh 后缀，
    # 在 SteamOS 上被 bash -n 误当脚本；只清理下载包内的这类元数据文件。
    find "$root" -type f -name '._*' -exec rm -f -- {} +
}

validate_tar_archive() {
    local archive="$1"
    local listing="$2"
    local verbose_listing="$3"
    local entry
    local entry_count=0

    tar -tzf "$archive" > "$listing" || {
        echo "项目包不是有效的 tar.gz 文件。"
        return 1
    }
    while IFS= read -r entry; do
        entry_count=$((entry_count + 1))
        case "$entry" in
            /*|../*|*/../*|*/..)
                echo "项目包包含不安全路径：$entry"
                return 1
                ;;
        esac
    done < "$listing"
    if [ "$entry_count" -eq 0 ] || [ "$entry_count" -gt 5000 ]; then
        echo "项目包文件数量异常：$entry_count"
        return 1
    fi

    tar -tvzf "$archive" > "$verbose_listing" || return 1
    if ! awk '
        function unsafe(target, parts, count, i) {
            if (target ~ /^\//) return 1
            count = split(target, parts, "/")
            for (i = 1; i <= count; i++) if (parts[i] == "..") return 1
            return 0
        }
        /^[lh]/ {
            target = ""
            if (index($0, " -> ")) target = substr($0, index($0, " -> ") + 4)
            else if (index($0, " link to ")) target = substr($0, index($0, " link to ") + 9)
            if (target == "" || unsafe(target)) exit 1
        }
    ' "$verbose_listing"; then
        echo "项目包包含不安全的链接。"
        return 1
    fi
}

download_verified_package_from() {
    local label="$1"
    local package_url="$2"
    local checksum_url="$3"
    local package_file="$4"
    local checksum_file="$5"
    local expected="${ZHOUKEER_SHA256:-}"

    download_one "$package_url" "$package_file" "${label}更新包" || return 1

    if [ -z "$expected" ]; then
        download_one "$checksum_url" "$checksum_file" "${label}校验文件" || return 1
        expected="$(checksum_from_manifest "$checksum_file" "$PACKAGE_NAME")"
    fi

    verify_package "$package_file" "$expected"
}

download_verified_package() {
    local package_file="$1"
    local checksum_file="$2"

    if download_verified_package_from \
        "国内镜像" "$GITEE_PACKAGE_URL" "$GITEE_CHECKSUM_URL" \
        "$package_file" "$checksum_file"; then
        DOWNLOAD_SOURCE="国内镜像"
        return 0
    fi

    echo "下载暂时不可用，正在重新尝试。"
    if download_verified_package_from \
        "GitHub" "$GITHUB_PACKAGE_URL" "$GITHUB_CHECKSUM_URL" \
        "$package_file" "$checksum_file"; then
        DOWNLOAD_SOURCE="GitHub"
        return 0
    fi

    echo "下载暂时不可用，正在重新尝试。"
    if download_verified_package_from \
        "域名" "$DOMAIN_PACKAGE_URL" "$DOMAIN_CHECKSUM_URL" \
        "$package_file" "$checksum_file"; then
        DOWNLOAD_SOURCE="域名"
        return 0
    fi

    echo "安装包验证失败。"
    return 1
}

download_with_fallback() {
    local output="$1"
    local label="$2"
    local domain_url="$3"
    local gitee_url="$4"
    local github_url="$5"

    if download_one "$gitee_url" "$output" "国内镜像"; then
        DOWNLOAD_SOURCE="国内镜像"
        return 0
    fi

    echo "下载暂时不可用，正在重新尝试。"
    if download_one "$github_url" "$output" "GitHub"; then
        DOWNLOAD_SOURCE="GitHub"
        return 0
    fi

    echo "下载暂时不可用，正在重新尝试。"
    if download_one "$domain_url" "$output" "域名"; then
        DOWNLOAD_SOURCE="域名"
        return 0
    fi

    echo "$label 下载失败。"
    return 1
}

SYSTEM="$(uname -s 2>/dev/null || echo unknown)"

if [ "$SYSTEM" = "Darwin" ]; then
    echo "检测到 macOS。仅允许语法测试，不执行 SteamOS 安装。"
    exit 0
fi

if [ "$SYSTEM" != "Linux" ]; then
    echo "不支持的系统: $SYSTEM"
    exit 1
fi

need_command curl
need_command tar

if [ "$DRY_RUN" -eq 1 ]; then
    echo "[dry-run] 将优先从域名获取版本: $DOMAIN_VERSION_URL"
    echo "[dry-run] 国内镜像发布包：已配置（地址已隐藏）"
    echo "[dry-run] GitHub备用包: $GITHUB_PACKAGE_URL"
    echo "[dry-run] 将安装到: $INSTALL_DIR"
    echo "[dry-run] 不会创建目录、下载文件或调用安装器。"
    exit 0
fi

TMP_DIR="$(mktemp -d)"
PACKAGE_FILE="$TMP_DIR/renkit.tar.gz"
VERSION_FILE="$TMP_DIR/VERSION"
CHECKSUM_FILE="$TMP_DIR/SHA256SUMS"

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

if download_with_fallback "$VERSION_FILE" "版本信息" "$DOMAIN_VERSION_URL" "$GITEE_VERSION_URL" "$GITHUB_VERSION_URL"; then
    VERSION="$(tr -d '\r\n' < "$VERSION_FILE")"
else
    VERSION="unknown"
fi
echo "正在安装Renkit..."
download_verified_package "$PACKAGE_FILE" "$CHECKSUM_FILE" || exit 1

validate_tar_archive "$PACKAGE_FILE" "$TMP_DIR/archive.list" "$TMP_DIR/archive.verbose" || exit 1
tar --no-xattrs --no-same-owner --no-same-permissions -xzf "$PACKAGE_FILE" -C "$TMP_DIR" || exit 1
remove_appledouble_files "$TMP_DIR" || {
    echo "无法清理项目包中的 macOS 元数据文件。"
    exit 1
}
INSTALLER_PATH="$(find "$TMP_DIR" -mindepth 1 -maxdepth 2 -type f -name install.sh -print | head -n 1)"

if [ -z "$INSTALLER_PATH" ] || [ ! -f "$INSTALLER_PATH" ]; then
    echo "项目包不完整：未找到 install.sh"
    exit 1
fi
PACKAGE_DIR="$(dirname "$INSTALLER_PATH")"

if [ ! -f "$PACKAGE_DIR/main.sh" ] || [ ! -d "$PACKAGE_DIR/modules" ] || [ ! -d "$PACKAGE_DIR/core" ]; then
    echo "项目包不完整：缺少 main.sh、modules 或 core"
    exit 1
fi

if ! find "$PACKAGE_DIR" -type f -name '*.sh' ! -name '._*' -exec bash -n {} \;; then
    echo "项目包包含Shell语法错误，已停止安装。"
    exit 1
fi

if ! ZHOUKEER_INSTALL_DIR="$INSTALL_DIR" bash "$INSTALLER_PATH" >"$TMP_DIR/install.log" 2>&1; then
    echo "Renkit安装未完成，以下是最后的错误提示："
    tail -n 20 "$TMP_DIR/install.log"
    exit 1
fi
echo "✓ Renkit安装完成"
