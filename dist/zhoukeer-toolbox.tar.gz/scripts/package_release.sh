#!/bin/bash

set -u

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="$(tr -d '\r\n' < "$PROJECT_ROOT/VERSION")"
# 版本号规则：补丁位只允许 0 到 9；x.y.9 之后必须为 x.(y+1).0。
DIST_DIR="$PROJECT_ROOT/dist"
PACKAGE_NAME="renkit.tar.gz"
PACKAGE_PATH="$DIST_DIR/$PACKAGE_NAME"
VERSIONED_PACKAGE_NAME="renkit-$VERSION.tar.gz"
VERSIONED_PACKAGE_PATH="$DIST_DIR/$VERSIONED_PACKAGE_NAME"
SHA256SUMS_PATH="$DIST_DIR/SHA256SUMS"
MAX_GITEE_RAW_PACKAGE_BYTES=9437184
VERIFY_FILES="core/terminal_brand.sh scripts/terminal_brand.py modules/sdweak.sh scripts/prepare_sdweak.py VERSION LICENSE THIRD_PARTY_LICENSES.md main.sh launch.sh install.sh update.sh bootstrap.sh modules/software.sh modules/domestic_source.sh modules/new_machine.sh modules/network.sh modules/diagnostics.sh modules/preflight.sh modules/settings_backup.sh modules/steam_accelerator.sh modules/steam302_root_start.sh modules/console_accelerators.sh modules/plugin_store.sh modules/game_launchers.sh modules/emulators.sh modules/ge_proton.sh modules/proton_cachyos.sh modules/todesk.sh modules/memory_tuning.sh modules/f1_screen_fix.sh modules/f1l_button_fix.sh modules/onexplayer_button_fix.sh modules/f1_bios_prepare.sh modules/dual_system.sh modules/dual_system_tools.sh modules/clover_boot.sh modules/rog_white_theme.sh modules/handheld_pink_theme.sh modules/pink_white_gradient_theme.sh scripts/steam_shortcut.py scripts/steam_compat.py scripts/install-decky-plugin.sh scripts/apply_steam_artwork.sh scripts/build_steam_artwork_payload.py scripts/decky_ws_call.py scripts/decky_probe.py scripts/open_steam_internal_browser.sh scripts/mirror_gitee_assets.sh core/gui.sh core/platform.sh core/download_policy.sh core/source_status.sh data/fsr4_optiscaler_tested_games_2026-08-07.txt data/mako_zh.json data/mako_zh_en.json assets/icon.png assets/icon-round.png assets/icon-toolbox-deck.png assets/windows-switch.png assets/background.jpg assets/software/wechat.png assets/emulators/yuzu.png assets/emulators/cemu.png assets/emulators/duckstation.png assets/emulators/pcsx2.png assets/emulators/rpcs3.png assets/emulators/shadps4.png assets/cssloader/rog-white/theme.json assets/cssloader/rog-white/shared.css assets/cssloader/handheld-pink/theme.json assets/cssloader/handheld-pink/shared.css assets/cssloader/pink-white-gradient/theme.json assets/cssloader/pink-white-gradient/shared.css assets/clover/config.plist assets/clover/zhoukeer-phantom/background.png assets/clover/zhoukeer-phantom/theme.plist assets/clover/devices/SD-config.plist assets/clover/drivers/asusrogally.efi assets/clover/bootmanager/clover-bootmanager.sh third_party/cssloader-zh-v2.1.2/dist/index.js third_party/cssloader-zh-v2.1.2/plugin.json third_party/cssloader-zh-v2.1.2/package.json third_party/cssloader-zh-v2.1.2/LICENSE third_party/decky-simpledeckytdp-zh-v1.0.7/dist/index.js third_party/decky-simpledeckytdp-zh-v1.0.7/plugin.json third_party/decky-simpledeckytdp-zh-v1.0.7/package.json third_party/allycenter-zh-v1.2.0/dist/index.js third_party/allycenter-zh-v1.2.0/plugin.json third_party/allycenter-zh-v1.2.0/package.json third_party/allycenter-zh-v1.2.0/LICENSE third_party/huesync-cn-v3.9.0/dist/index.js third_party/huesync-cn-v3.9.0/plugin.json third_party/huesync-cn-v3.9.0/package.json third_party/huesync-cn-v3.9.0/LICENSE third_party/legion-go-remapper-zh-v0.3.0/dist/index.js third_party/legion-go-remapper-zh-v0.3.0/plugin.json third_party/legion-go-remapper-zh-v0.3.0/package.json third_party/legion-go-remapper-zh-v0.3.0/LICENSE third_party/gpd-control-zh-v0.0.2/dist/index.js third_party/gpd-control-zh-v0.0.2/plugin.json third_party/gpd-control-zh-v0.0.2/package.json third_party/gpd-control-zh-v0.0.2/LICENSE third_party/lego-vibe-control-zh-v1.5.0/dist/index.js third_party/lego-vibe-control-zh-v1.5.0/plugin.json third_party/lego-vibe-control-zh-v1.5.0/package.json third_party/lego-vibe-control-zh-v1.5.0/LICENSE third_party/lego2-fan-control-zh-v0.260430/dist/index.js third_party/lego2-fan-control-zh-v0.260430/plugin.json third_party/lego2-fan-control-zh-v0.260430/package.json third_party/lego2-fan-control-zh-v0.260430/LICENSE utils/github_download.sh utils/gitee_download.sh"
VERIFY_FILES="$VERIFY_FILES scripts/set_user_password_pty.py third_party/allycenter-zh-v1.2.0/main.py third_party/allycenter-zh-v1.2.0/README.md third_party/lego2-brightness-fix-zh-v2.0.0/dist/index.js third_party/lego2-brightness-fix-zh-v2.0.0/plugin.json third_party/lego2-brightness-fix-zh-v2.0.0/package.json third_party/lego2-brightness-fix-zh-v2.0.0/main.py third_party/lego2-brightness-fix-zh-v2.0.0/lego_updater.py third_party/lego2-brightness-fix-zh-v2.0.0/LICENSE third_party/lego2-brightness-fix-zh-v2.0.0/gamescope/lenovo.legiongo2.oled.gamma22.lua third_party/lego2-brightness-fix-zh-v2.0.0/gamescope/lenovo.legiongo2.oled.pq.lua"
VERIFY_FILES="$VERIFY_FILES core/desktop_paths.sh modules/help.sh help.html scripts/build_help_terminal_images.py assets/help/renamamiya-qr.png assets/help/xianyu-renamamiya.jpg assets/help/renamamiya-qr-compact.sixel assets/help/renamamiya-qr.sixel assets/help/renamamiya-qr-deck.sixel assets/help/renamamiya-qr-large.sixel assets/help/renamamiya-qr-wide.sixel assets/help/renamamiya-qr-full.sixel assets/help/renamamiya-qr-2k.sixel assets/help/renamamiya-qr-4k.sixel assets/help/xianyu-renamamiya-compact.sixel assets/help/xianyu-renamamiya-compact-safe.sixel assets/help/xianyu-renamamiya-safe.sixel assets/help/xianyu-renamamiya.sixel assets/help/xianyu-renamamiya-deck.sixel assets/help/xianyu-renamamiya-deck-safe.sixel assets/help/xianyu-renamamiya-large.sixel assets/help/xianyu-renamamiya-large-safe.sixel assets/help/xianyu-renamamiya-wide.sixel assets/help/xianyu-renamamiya-wide-safe.sixel assets/help/xianyu-renamamiya-full.sixel assets/help/xianyu-renamamiya-full-safe.sixel assets/help/xianyu-renamamiya-2k.sixel assets/help/xianyu-renamamiya-2k-safe.sixel assets/help/xianyu-renamamiya-4k.sixel assets/help/xianyu-renamamiya-4k-safe.sixel assets/help/renamamiya-qr.ansi assets/help/xianyu-renamamiya.ansi"
VERIFY_FILES="$VERIFY_FILES tests/test_bazzite_plugins.sh tests/test_bazzite_plugin_pages.py tests/test_desktop_linux.sh tests/test_desktop_linux_installed.py docs/desktop-linux.md core/platform.sh tests/test_canvas_startup.py tests/test_compact_desktop.py docs/startup-canvas.md core/ui.sh modules/inputplumber_update.sh modules/inputplumber_manual.sh scripts/inputplumber_overlay.py scripts/inputplumber_release.py scripts/run_sdweak.sh"
VERIFY_FILES="$VERIFY_FILES modules/claw_g3e_audio.sh scripts/prepare_claw_audio.py"
VERIFY_FILES="$VERIFY_FILES scripts/deckygcm_package.py data/deckygcm_files.json docs/deckygcm.md docs/inputplumber-update.md tests/test_deckygcm.sh tests/test_deckygcm_package.py tests/test_deckygcm_standalone.py tests/fixtures/inputplumber-v0.84.0.json"
VERIFY_FILES="$VERIFY_FILES tests/test_plugin_atomic_install.sh tests/test_feature_bundle_integration.sh"
for claw_file in PKGBUILD Makefile dkms.conf claw_rt721_amp.c claw-rt721-fix.service claw-rt721-fix-sleep README.md TECHNICAL.md LICENSE SHA256SUMS PROVENANCE.md; do
    VERIFY_FILES="$VERIFY_FILES third_party/claw-rt721-fix-v0.1.0/$claw_file"
done
VERIFY_FILES="$VERIFY_FILES third_party/onexplayer-apex-tools-zh-v0.1.0/dist/index.js third_party/onexplayer-apex-tools-zh-v0.1.0/plugin.json third_party/onexplayer-apex-tools-zh-v0.1.0/package.json third_party/onexplayer-apex-tools-zh-v0.1.0/LICENSE"
VERIFY_FILES="$VERIFY_FILES modules/ntfs_mount_repair.sh tests/test_ntfs_mount_repair.sh tests/test_ntfs_partition_picker.sh docs/ntfs-mount-repair.md"
VERIFY_FILES="$VERIFY_FILES config/settings.example.conf tests/test_legacy_auto_update.py tests/test_legacy_update_matrix.py docs/update-compatibility.md"
PACKAGE_SOURCES=()
VERIFY_FILES="$VERIFY_FILES modules/epic_linux.sh"
VERIFY_FILES="$VERIFY_FILES modules/framegen_updates.sh scripts/framegen_package.py scripts/sync_framegen_zh.py scripts/framegen_ui.mjs scripts/vendor/acorn/acorn.mjs scripts/vendor/acorn/LICENSE data/framegen_zh.json data/framegen_auto_baseline.json assets/framegen/zh-runtime.js"

validate_release_version() {
    local major minor patch extra

    IFS='.' read -r major minor patch extra <<< "$VERSION"
    if [ -n "${extra:-}" ] || [ -z "${major:-}" ] || [ -z "${minor:-}" ] || [ -z "${patch:-}" ]; then
        echo "版本号必须是三段纯数字格式（例如 1.4.0）：$VERSION"
        exit 1
    fi
    case "$major:$minor:$patch" in
        *[!0-9:]* )
            echo "版本号必须是三段纯数字格式（例如 1.4.0）：$VERSION"
            exit 1
            ;;
    esac
    if [ "$patch" -gt 9 ]; then
        echo "补丁版本只允许 0 到 9；x.y.9 之后必须发布 x.(y+1).0：$VERSION"
        exit 1
    fi
}

validate_release_version

# Bazzite 与 ChimeraOS 使用独立主程序；发布包必须携带对应入口。
VERIFY_FILES="$VERIFY_FILES main-bazzite.sh main-chimera.sh modules/bazzite_decky.sh assets/clover/bootmanager/clover-bootmanager.service assets/clover/bootmanager/clover-whitelist.conf"
VERIFY_FILES="$VERIFY_FILES decky-plugins/switch-to-windows/plugin.json decky-plugins/switch-to-windows/package.json decky-plugins/switch-to-windows/main.py decky-plugins/switch-to-windows/backend/src/switch_to_windows.py decky-plugins/switch-to-windows/dist/index.js decky-plugins/switch-to-windows/LICENSE"

VERIFY_FILES="$VERIFY_FILES scripts/localize_deckhomethemes.py data/deckhomethemes_zh.json data/deckhomethemes_files.json assets/deckhomethemes/zh-runtime.js"
VERIFY_FILES="$VERIFY_FILES modules/ayaneo3.sh scripts/localize_ayaneo3.py scripts/verify_ayaneo3_ui.mjs data/ayaneo3_zh.json data/ayaneo3_files.json assets/ayaneo3/zh-runtime.js"
VERIFY_FILES="$VERIFY_FILES core/lsfg_choice.sh modules/lsfg_install.sh"
VERIFY_FILES="$VERIFY_FILES core/plugin_cleanup_choice.sh modules/feature_plugins_cleanup.sh"
VERIFY_FILES="$VERIFY_FILES modules/themehub_updates.sh scripts/sync_themehub_zh.py scripts/themehub_package.py scripts/themehub_ui.mjs data/themehub_auto_baseline.json data/themehub_ui_baseline.json data/themehub_zh.json assets/themehub/dynamic-messages.js"
VERIFY_FILES="$VERIFY_FILES modules/quark.sh assets/software/quark.png docs/quark.md scripts/quark_portable.py data/quark_portable_files.json tests/test_quark.sh tests/test_quark_portable.py tests/test_quark_installed.py"
VERIFY_FILES="$VERIFY_FILES scripts/verify_rog_x20_package.py tests/test_rog_x20_installed.py modules/rog_x20_fix.sh tests/test_rog_x20.sh tests/test_rog_x20_package.py tests/test_rog_x20_ui.py docs/rog-x20.md third_party/rc74xa-offline-20261024/manifest.json"
VERIFY_FILES="$VERIFY_FILES tests/test_startup_password.sh docs/startup-password.md tests/test_feature_trainer_choice.sh tests/test_memory_create.sh docs/memory-tuning.md"
VERIFY_FILES="$VERIFY_FILES assets/sdweak/SDWEAK-core-v2.2.0.zip docs/sdweak.md"
VERIFY_FILES="$VERIFY_FILES assets/gfg-extreme/NotoSansSC-OFL.txt assets/gfg-extreme/add_chinese_hud_font.py assets/gfg-extreme/hud_font.py assets/gfg-extreme/source/frontend/build.mjs assets/gfg-extreme/source/frontend/shim.js assets/gfg-extreme/source/frontend/src/app.js assets/gfg-extreme/source/frontend/src/logo.js assets/gfg-extreme/source/frontend/src/theme.js assets/gfg-extreme/source/package-lock.json assets/gfg-extreme/source/tools/make_hud_font.py assets/gfg-extreme/zh-runtime.js data/gfg_extreme_files.json data/gfg_extreme_ui_inventory.json data/gfg_extreme_zh.json docs/gfg-extreme.md modules/gfg_extreme.sh scripts/localize_gfg_extreme.py scripts/localize_gfg_ui.mjs tests/test_gfg_extreme_install.sh tests/test_gfg_extreme_installed.py tests/test_gfg_extreme_package.py tests/test_gfg_extreme_ui.mjs tests/test_plugin_singles_paging.py"

VERIFY_FILES="$VERIFY_FILES modules/steam302_legacy.sh modules/steam302_v15.sh scripts/steam302_control.py docs/steam302.md tests/test_screen_colors_installed.py"
VERIFY_FILES="$VERIFY_FILES modules/screen_colors.sh scripts/localize_screen_colors.py scripts/verify_screen_colors_ui.mjs data/screen_colors_files.json data/screen_colors_zh.json assets/screen-colors/zh-runtime.js assets/screen-colors/RENKIT_ZH.md assets/screen-colors/source/src/i18n.ts assets/screen-colors/source/src/index.tsx assets/screen-colors/source/pnpm-lock.yaml assets/screen-colors/source/rollup.config.js assets/screen-colors/source/tsconfig.json tests/test_screen_colors.py tests/test_screen_colors_install.sh tests/fixtures/screen-colors-v1.0.0.zip docs/screen-colors.md tests/test_steam302_control.py tests/test_steam302_v15.sh"

mkdir -p "$DIST_DIR"

cd "$PROJECT_ROOT" || exit 1

# macOS 打包时排除扩展属性，避免 SteamOS 解压时产生无关警告
# 只打包 Git 已跟踪文件，避免把本机临时文件或未提交资料带入公开包。
while IFS= read -r -d '' source_path; do
    case "$source_path" in
        dist/*|mirrors/*|launcher-covers/*|decky-installer-cn/*|decky-plugins/zhoukeer-localizer/*|assets/background.png|assets/welcome.png|assets/disclaimer-usage.png|assets/game-launchers/*|website/*|index.html|todesk.html) continue ;;
        third_party/steamdb-button-zh-v0.0.1/*|third_party/decky-translator-zh-v0.8.0/*|third_party/decky-translator-zh-v0.9.1/*) continue ;;
        third_party/cssloader-zh-v2.1.2/*)
            case "$source_path" in
                third_party/cssloader-zh-v2.1.2/plugin.json|\
                third_party/cssloader-zh-v2.1.2/package.json|\
                third_party/cssloader-zh-v2.1.2/LICENSE|\
                third_party/cssloader-zh-v2.1.2/dist/index.js) ;;
                *) continue ;;
            esac
            ;;
    esac
    PACKAGE_SOURCES+=("./$source_path")
done < <(git ls-files -z)

if [ "${#PACKAGE_SOURCES[@]}" -eq 0 ]; then
    echo "没有找到可打包的 Git 已跟踪文件。"
    exit 1
fi

# macOS 的 Finder/归档工具可能附加 AppleDouble（._*）元数据文件。
# SteamOS 端会将扩展名为 .sh 的这类二进制元数据误当 Bash 脚本，必须从发布包中彻底排除。
COPYFILE_DISABLE=1 tar \
    --no-xattrs \
    --exclude=".git" \
    --exclude=".DS_Store" \
    --exclude="._*" \
    --exclude="*/._*" \
    --exclude="logs" \
    --exclude="apps" \
    --exclude="decky-plugins/*/node_modules" \
    --exclude="*.save" \
    --exclude="*.bak.*" \
    --exclude="管理员密码.txt" \
    --exclude="config/settings.conf" \
    -czf "$PACKAGE_PATH" "${PACKAGE_SOURCES[@]}"

if PACKAGE_BYTES="$(stat -c '%s' "$PACKAGE_PATH" 2>/dev/null || stat -f '%z' "$PACKAGE_PATH" 2>/dev/null)" && \
    [ "$PACKAGE_BYTES" -le "$MAX_GITEE_RAW_PACKAGE_BYTES" ]; then
    :
else
    echo "发布包超过 Gitee Raw 下载安全上限（9 MiB），已停止发布。"
    rm -f -- "$PACKAGE_PATH" "$SHA256SUMS_PATH"
    exit 1
fi

if tar -tzf "$PACKAGE_PATH" | grep -Eq '(^|/)\._'; then
    echo "发布包包含 macOS AppleDouble 元数据文件，已停止发布。"
    rm -f -- "$PACKAGE_PATH" "$SHA256SUMS_PATH"
    exit 1
fi

for packaged_file in $VERIFY_FILES; do
    if ! tar -xOf "$PACKAGE_PATH" "./$packaged_file" | \
        cmp -s - "$PROJECT_ROOT/$packaged_file"; then
        echo "发布包内容与当前源码不一致：$packaged_file"
        rm -f -- "$PACKAGE_PATH" "$SHA256SUMS_PATH"
        exit 1
    fi
done

cp "$PACKAGE_PATH" "$VERSIONED_PACKAGE_PATH"
# 保留旧发布名作为兼容别名，原有下载链接不会失效。
cp "$PACKAGE_PATH" "$DIST_DIR/zhoukeer-toolbox.tar.gz"

if command -v sha256sum >/dev/null 2>&1; then
    PACKAGE_SHA256="$(sha256sum "$PACKAGE_PATH" | awk '{print $1}')"
elif command -v shasum >/dev/null 2>&1; then
    PACKAGE_SHA256="$(shasum -a 256 "$PACKAGE_PATH" | awk '{print $1}')"
else
    echo "缺少 SHA256 校验命令: sha256sum 或 shasum"
    exit 1
fi

printf '%s  %s\n' "$PACKAGE_SHA256" "$PACKAGE_NAME" > "$SHA256SUMS_PATH"
printf '%s  %s\n' "$PACKAGE_SHA256" "zhoukeer-toolbox.tar.gz" >> "$SHA256SUMS_PATH"
printf '%s  %s\n' "$PACKAGE_SHA256" "$VERSIONED_PACKAGE_NAME" > \
    "$VERSIONED_PACKAGE_PATH.sha256"

# A downloadable archive is not sufficient: an old client must be able to
# finish installing it. This test blocks OS commands and simulates downloads.
if ! RENKIT_TEST_BASH="$BASH" python3 "$PROJECT_ROOT/tests/test_legacy_update_matrix.py" "$PACKAGE_PATH"; then
    echo "历史版本完整升级检查未通过，已停止发布。"
    exit 1
fi

echo "仓库更新包: $PACKAGE_PATH"
echo "旧链接兼容包: $DIST_DIR/zhoukeer-toolbox.tar.gz"
echo "Release发布包: $VERSIONED_PACKAGE_PATH"
echo "Release校验文件: $VERSIONED_PACKAGE_PATH.sha256"
echo "仓库校验文件: $SHA256SUMS_PATH"
