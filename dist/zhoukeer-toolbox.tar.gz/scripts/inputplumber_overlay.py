"""Install only verified InputPlumber files, retaining a reversible root-owned backup."""
import argparse
import re
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import sys
import tarfile
import tempfile
import uuid

EXACT = {
    'usr/bin/inputplumber',
    'usr/lib/systemd/system/inputplumber.service',
    'usr/lib/systemd/system/inputplumber-suspend.service',
    'usr/lib/udev/hwdb.d/59-inputplumber.hwdb',
    'usr/lib/udev/hwdb.d/60-inputplumber-autostart.hwdb',
    'usr/lib/udev/rules.d/99-inputplumber-device-setup.rules',
    'usr/lib/udev/rules.d/50-8bitdo-u2-controller.rules',
    'usr/lib/udev/rules.d/90-inputplumber-autostart.rules',
    'usr/lib/udev/rules.d/60-inputplumber-uaccess.rules',
    'usr/share/dbus-1/system.d/org.shadowblip.InputPlumber.conf',
    'usr/share/polkit-1/rules.d/org.shadowblip.InputPlumber.rules',
    'usr/share/polkit-1/actions/org.shadowblip.InputPlumber.policy',
}
# Upstream renamed the 8BitDo rule from 50 to 55, and newer releases also
# include an IMU timer module configuration. Keep supporting older archives
# without allowing arbitrary rules or modules-load files under /usr.
CONTROLLER_RULES = {
    'usr/lib/udev/rules.d/50-8bitdo-u2-controller.rules',
    'usr/lib/udev/rules.d/55-8bitdo-u2-controller.rules',
}
OPTIONAL_EXACT = {
    'usr/lib/udev/rules.d/55-8bitdo-u2-controller.rules',
    'usr/lib/modules-load.d/inputplumber-hrtimer.conf',
}


def allowed(name):
    path = PurePosixPath(name)
    return (not path.is_absolute() and str(path) == name and '..' not in path.parts
            and (name in EXACT or name in OPTIONAL_EXACT or
                 (name.startswith('usr/share/inputplumber/')
                  and path.suffix in ('.yaml', '.json'))))


def verified_files(archive, expected_sha256):
    if not re.fullmatch(r"[0-9a-fA-F]{64}", expected_sha256):
        raise ValueError("官方校验信息不完整")
    data = Path(archive).read_bytes()
    if hashlib.sha256(data).hexdigest() != expected_sha256.lower():
        raise ValueError('官方文件校验未通过')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tar:
        for member in tar:
            raw = member.name.removeprefix('inputplumber/')
            if member.isdir():
                if member.name == 'inputplumber' or (
                        str(PurePosixPath(raw)) == raw and '..' not in PurePosixPath(raw).parts
                        and not raw.startswith('/') and raw.startswith('usr')):
                    continue
                raise ValueError('压缩包目录不安全')
            if not member.isfile() or not allowed(raw) or raw in result:
                raise ValueError(f'压缩包含有意外文件或链接：{member.name!r}')
            if member.size > 268435456:
                raise ValueError('压缩包文件过大')
            result[raw] = tar.extractfile(member).read()
    if not (EXACT - CONTROLLER_RULES).issubset(result) or not CONTROLLER_RULES.intersection(result):
        raise ValueError('官方文件不完整')
    binary = result['usr/bin/inputplumber']
    if binary[:6] != b'\x7fELF\x02\x01' or binary[18:20] != b'\x3e\x00':
        raise ValueError('程序不适用于这台机器')
    return result


def safe_target(root, name):
    if not allowed(name):
        raise ValueError('安装路径不受支持')
    target = root / name
    for path in [target, *target.parents]:
        if path == root.parent:
            break
        if path.is_symlink():
            raise ValueError(f'目标路径是链接：{name}')
    if target.exists() and not target.is_file():
        raise ValueError(f'目标不是普通文件：{name}')
    return target


def replace(target, data, mode):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.renkit-inputplumber-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as file:
            file.write(data)
            file.flush()
            os.fsync(file.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def backup_base(root):
    return root / 'var/lib/renkit/inputplumber-backups'


def restore(root, backup):
    if backup.is_symlink() or backup.parent != backup_base(root) or not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+-[0-9a-f]{32}', backup.name):
        raise ValueError('备份路径不安全')
    entries = json.loads((backup / 'manifest.json').read_text())
    for entry in entries:
        target = safe_target(root, entry['name'])
        if entry['exists']:
            file = backup / 'files' / entry['name']
            if file.is_symlink() or not file.is_file():
                raise ValueError('备份文件不安全')
            replace(target, file.read_bytes(), entry['mode'])
            os.chown(target, entry['uid'], entry['gid'])
        else:
            target.unlink(missing_ok=True)


def install(root, archive, expected_sha256, version):
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
        raise ValueError("版本号不安全")
    files = verified_files(archive, expected_sha256)
    targets = {name: safe_target(root, name) for name in files}
    base = backup_base(root)
    # Ancestors of the backup directory must not redirect writes outside its scope.
    for path in [base, *base.parents]:
        if path == root.parent:
            break
        if path.is_symlink():
            raise ValueError('备份目录是链接')
    backup = base / ('v' + version + '-' + uuid.uuid4().hex)
    backup.mkdir(parents=True, mode=0o700)
    os.chmod(backup, 0o700)
    entries = []
    for name, target in targets.items():
        entry = {'name': name, 'exists': target.exists()}
        if entry['exists']:
            info = target.stat()
            entry.update(mode=info.st_mode & 0o777, uid=info.st_uid, gid=info.st_gid)
            saved = backup / 'files' / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(target, saved)
        entries.append(entry)
    (backup / 'manifest.json').write_text(json.dumps(entries))
    try:
        for name, target in targets.items():
            replace(target, files[name], 0o755 if name == 'usr/bin/inputplumber' else 0o644)
    except BaseException:
        restore(root, backup)
        raise
    return backup


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('verify', 'install', 'restore'))
    parser.add_argument('argument')
    parser.add_argument('sha256', nargs='?')
    parser.add_argument('version', nargs='?')
    parser.add_argument('--test-root')
    args = parser.parse_args()
    action, argument = args.action, args.argument
    root = Path('/')
    if args.test_root:
        if os.environ.get('ZHOUKEER_TEST_MODE') != '1':
            raise ValueError('测试路径未授权')
        root = Path(args.test_root).resolve()
        if root == Path('/'):
            raise ValueError('测试不得使用真实系统目录')
    elif action != 'verify' and os.geteuid() != 0:
        raise ValueError('需要管理员权限')
    if action != 'restore' and not args.sha256:
        raise ValueError('缺少官方校验信息')
    if action == 'install' and not args.version:
        raise ValueError('缺少版本信息')
    if action == 'verify':
        verified_files(argument, args.sha256)
    elif action == 'install':
        def interrupted(signum, frame):
            raise InterruptedError('更新中断，正在恢复旧文件')
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(signum, interrupted)
        print(install(root, argument, args.sha256, args.version))
    elif action == 'restore':
        restore(root, Path(argument))
    else:
        raise ValueError('不支持的操作')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, tarfile.TarError, IndexError) as error:
        print(f'InputPlumber 文件处理失败：{error}', file=sys.stderr)
        sys.exit(1)
