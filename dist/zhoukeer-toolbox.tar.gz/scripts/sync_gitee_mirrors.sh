#!/bin/bash

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck disable=SC1091
source "$ROOT/core/env.sh"
load_config

OWNER="zliu9732-hub"
TOKEN="${GITEE_TOKEN:-}"
[ -n "$TOKEN" ] || {
    echo "GITEE_TOKEN secret is missing"
    exit 1
}

BASE="https://${OWNER}:${TOKEN}@gitee.com/${OWNER}"
WORK="$(mktemp -d)"
trap 'rm -rf -- "$WORK"' EXIT
MIRROR1="$WORK/mirror1"
MIRROR2="$WORK/mirror2"
MIRROR3="$WORK/mirror3"
git clone -q "$BASE/zhoukeer-toolbox-mirror.git" "$MIRROR1"
git clone -q "$BASE/zhoukeer-toolbox-mirror-2.git" "$MIRROR2"
git clone -q "$BASE/zhoukeer-toolbox-mirror-3.git" "$MIRROR3"

sha_of() {
    sha256sum -- "$1" | awk '{print $1}'
}

write_manifest() {
    local dir="$1" id="$2" name="$3" version="$4" file="$5" url="$6" sha="$7"
    local size="$8" chunks="$9" chunk_size="${10:-0}" repo1="${11:-}" repo2="${12:-}" parts_repo1="${13:-}"

    {
        printf 'id=%s\n' "$id"
        printf 'name=%s\n' "$name"
        printf 'version=%s\n' "$version"
        printf 'file=%s\n' "$file"
        printf 'source_url=%s\n' "$url"
        printf 'sha256=%s\n' "$sha"
        printf 'size=%s\n' "$size"
        printf 'chunks=%s\n' "$chunks"
        printf 'chunk_size=%s\n' "$chunk_size"
        [ -z "$repo1" ] || printf 'repo1=%s\n' "$repo1"
        [ -z "$repo2" ] || printf 'repo2=%s\n' "$repo2"
        [ -z "$parts_repo1" ] || printf 'parts_repo1=%s\n' "$parts_repo1"
    } > "$dir/$id/latest.txt"
}

sync_plugin() {
    local id="$1" repo="$2" pattern="$3" name="$4"
    local pinned_version="${5:-}" pinned_file="${6:-}" pinned_url="${7:-}" pinned_sha="${8:-}"
    local mirror_repo="${9:-$MIRROR1}"
    local version file url sha size chunks target_dir

    if [ -n "$pinned_version" ]; then
        version="$pinned_version"
        file="$pinned_file"
        url="$pinned_url"
        sha="$pinned_sha"
    else
        if ! resolve_latest_github_release "$repo" "$pattern" "$name"; then
            echo "Skip $id: latest release lookup failed"
            return 0
        fi
        version="$_LATEST_RELEASE_TAG"
        file="$_LATEST_RELEASE_ASSET"
        url="$_LATEST_RELEASE_URL"
        sha="$_LATEST_RELEASE_SHA256"
    fi
    [ -n "$version" ] && [ -n "$file" ] && [ -n "$url" ] || return 1

    curl -fsSL --proto '=https' --proto-redir '=https' \
        --connect-timeout 15 --max-time 600 -o "$WORK/$file" "$url"
    [ "$(sha_of "$WORK/$file")" = "$sha" ] || {
        echo "$id SHA256 mismatch"
        exit 1
    }
    size="$(wc -c < "$WORK/$file" | tr -d ' ')"
    target_dir="$mirror_repo/$id/$version"
    mkdir -p "$target_dir"
    rm -f -- "$mirror_repo/$id/$version"/*

    if [ "$size" -le 9437184 ]; then
        cp -- "$WORK/$file" "$target_dir/$file"
        chunks=0
    else
        split -b 8388608 --numeric-suffixes=1 -a 4 \
            "$WORK/$file" "$target_dir/part."
        chunks="$(find "$target_dir" -maxdepth 1 -name 'part.*' | wc -l | tr -d ' ')"
    fi
    write_manifest "$mirror_repo" "$id" "$name" "$version" "$file" \
        "$url" "$sha" "$size" "$chunks" 8388608
    echo "Synced $id $version"
}

sync_ge_proton() {
    local version file url sha size chunks target1 target2 i part

    if ! resolve_latest_github_release "GloriousEggroll/proton-ge-custom" \
        '^GE-Proton[0-9]+-[0-9]+[.]tar[.]gz$' "GE-Proton"; then
        echo "Skip GE-Proton: latest release lookup failed"
        return 0
    fi
    version="$_LATEST_RELEASE_TAG"
    file="$_LATEST_RELEASE_ASSET"
    url="$_LATEST_RELEASE_URL"
    sha="$_LATEST_RELEASE_SHA256"

    curl -fsSL --proto '=https' --proto-redir '=https' \
        --connect-timeout 15 --max-time 1800 -o "$WORK/$file" "$url"
    [ "$(sha_of "$WORK/$file")" = "$sha" ] || {
        echo "GE-Proton SHA256 mismatch"
        exit 1
    }
    size="$(wc -c < "$WORK/$file" | tr -d ' ')"
    chunks=$(( (size + 8388607) / 8388608 ))
    target1="$MIRROR1/ge-proton/$version"
    target2="$MIRROR2/ge-proton/$version"
    mkdir -p "$target1" "$target2"
    rm -f -- "$MIRROR1/ge-proton"/*/part.* "$MIRROR2/ge-proton"/*/part.*

    split -b 8388608 --numeric-suffixes=1 -a 4 \
        "$WORK/$file" "$WORK/ge-proton.part."
    i=1
    while [ "$i" -le 8 ]; do
        part="$(printf 'part.%04d' "$i")"
        cp -- "$WORK/ge-proton.$part" "$target1/$part"
        i=$((i + 1))
    done
    while [ "$i" -le "$chunks" ]; do
        part="$(printf 'part.%04d' "$i")"
        cp -- "$WORK/ge-proton.$part" "$target2/$part"
        i=$((i + 1))
    done

    write_manifest "$MIRROR1" "ge-proton" "GE-Proton" "$version" "$file" \
        "$url" "$sha" "$size" "$chunks" 8388608 \
        "zhoukeer-toolbox-mirror" "zhoukeer-toolbox-mirror-2" 8
    echo "Synced GE-Proton $version"
}

# 小黄鸭汉化叠加固定 v0.12.8，镜像必须与Renkit内置版本一致，否则 SHA 校验会拒绝。
sync_plugin lsfg "xXJSONDeruloXx/decky-lsfg-vk" '^Decky[.]LSFG-VK[.]zip$' "Decky LSFG-VK" \
    "v0.12.8" "Decky.LSFG-VK.zip" \
    "https://github.com/xXJSONDeruloXx/decky-lsfg-vk/releases/download/v0.12.8/Decky.LSFG-VK.zip" \
    "322f6eec21a489ef9f12938ea2ec4e43c234093876f95b7245fbd260f882ce9c" "$MIRROR3"
# Renkit 安装只使用署名完整包；官方原包镜像仅保留给历史兼容流程。
sync_plugin lsfg-zh-signed "zliu9732-hub/decky-lsfg-vk-zh" \
    '^Decky[.]LSFG-VK-zh-signed-v0[.]12[.]8-r2[.]zip$' "Decky LSFG-VK 署名中文插件" \
    "v0.12.8" "Decky.LSFG-VK-zh-signed-v0.12.8-r2.zip" \
    "https://github.com/zliu9732-hub/decky-lsfg-vk-zh/releases/download/v0.12.8/Decky.LSFG-VK-zh-signed-v0.12.8-r2.zip" \
    "04831a87e676606947c09e824a0612a2c792c72cd6b98f918e0b28f5af684aba" "$MIRROR3"
# MAKO 尝鲜版跟随上游最新 Release 同步，上传前必须解析到带 SHA256 digest 的 ZIP。
sync_plugin lsfg-mako "eugeniosegala/MAKO" \
    '^MAKO-Decky-v[0-9.]+[.]zip$' "MAKO LSFG-VK" "" "" "" "" "$MIRROR3"
# FSR4 汉化叠加固定 v0.17，镜像必须与Renkit内置版本一致，否则 SHA 校验会拒绝。
sync_plugin fsr4 "xXJSONDeruloXx/Decky-Framegen" '^Decky-Framegen[.]zip$' "Decky-Framegen" \
    "v0.17" "Decky-Framegen.zip" \
    "https://github.com/xXJSONDeruloXx/Decky-Framegen/releases/download/v0.17/Decky-Framegen.zip" \
    "3300b617e3d979b483d03f995c75c829d6d54beaa4ac8dfae300c2560e4fc60f"
sync_plugin fsr4-zh-signed "zliu9732-hub/decky-framegen-zh" \
    '^Decky-Framegen-zh-signed-v0[.]17[.]zip$' "Decky-Framegen 署名中文插件" \
    "v0.17" "Decky-Framegen-zh-signed-v0.17.zip" \
    "https://github.com/zliu9732-hub/decky-framegen-zh/releases/download/v0.17/Decky-Framegen-zh-signed-v0.17.zip" \
    "b392ea5c850c76a9b230e0028dd5b37e5a5c38759918beba4a01714735eb0ebf" "$MIRROR3"
sync_plugin cheatdeck "SheffeyG/CheatDeck" '^CheatDeck[.]zip$' "CheatDeck"
sync_plugin steamgriddb "SteamGridDB/decky-steamgriddb" '^$' "SteamGridDB" \
    "v1.7.1" "steamgriddb-v1.7.1.zip" \
    "https://cdn.tzatzikiweeb.moe/file/steam-deck-homebrew/versions/6d6eca184677dc9ff7736439ee7a575ca8ab386c5ffb1627d446bc43dbd1ecf3.zip" \
    "6d6eca184677dc9ff7736439ee7a575ca8ab386c5ffb1627d446bc43dbd1ecf3"
sync_plugin cssloader "DeckThemes/SDH-CssLoader" '^$' "CSS Loader" \
    "v2.1.2" "cssloader-v2.1.2.zip" \
    "https://cdn.tzatzikiweeb.moe/file/steam-deck-homebrew/versions/1a1e8f4dded8494febe56df16429ef5bba1e5b8feb3fd989d5808fbef0d71350.zip" \
    "1a1e8f4dded8494febe56df16429ef5bba1e5b8feb3fd989d5808fbef0d71350"
sync_plugin friendeck "panyiwei-home/Friendeck" '^Friendeck[.]v[.]0[.]7[.]7[.]zip$' "Friendeck" \
    "0.7.7" "Friendeck.v.0.7.7.zip" \
    "https://github.com/panyiwei-home/Friendeck/releases/download/0.7.7/Friendeck.v.0.7.7.zip" \
    "65465ff115e105912adf72b5461e17b697ac07100ce7061de2e962851e41c653"
sync_plugin deckymusic "jinzhongjia/decky-music" '^Decky[.]Music[.]zip$' "Decky Music" \
    "v1.0.0" "Decky.Music.zip" \
    "https://github.com/jinzhongjia/decky-music/releases/download/v1.0.0/Decky.Music.zip" \
    "ec2956bbee1d84b25b7f8749f06794b54014828a04707beccd06feb5d49dfa53"
sync_plugin tomoon "YukiCoco/ToMoon" '^tomoon-v[0-9.]+[.]zip$' "ToMoon"
sync_plugin savepulse "Ren-Amamiya-pixle/SavePulse" '^SavePulse[.]zip$' "SavePulse" \
    "v0.2.0-alpha.1" "SavePulse.zip" \
    "https://github.com/Ren-Amamiya-pixle/SavePulse/releases/download/v0.2.0-alpha.1/SavePulse.zip" \
    "e0680fc3995b8bbb2971673db43d5e9459d8fa8e4a1b431a1f5d4edad19a35ad"
sync_plugin unifideck "mubaraknumann/unifideck" '^unifideck[.]prod[.]v[0-9.]+[.]zip$' "Unifideck"
sync_plugin freedeck "panyiwei-home/Freedeck" '^freedeck[.]v[0-9.]+[.]zip$' "Freedeck"
sync_plugin simpledeckytdp "aarron-lee/SimpleDeckyTDP" '^SimpleDeckyTDP[.]zip$' "SimpleDeckyTDP"
# HMCL 启动器固定版本，镜像必须与Renkit内置版本一致，否则 SHA 校验会拒绝。
sync_plugin hmcl "HMCL-dev/HMCL" '^HMCL-[0-9.]+[.]jar$' "HMCL" \
    "v3.16.3" "HMCL-3.16.3.jar" \
    "https://github.com/HMCL-dev/HMCL/releases/download/v3.16.3/HMCL-3.16.3.jar" \
    "5d02f4d04d9442116354ecfccf679910cca371d00a23cd5d6b16558c20a73dd3"
sync_plugin temurin21-jre "adoptium/temurin21-binaries" \
    '^OpenJDK21U-jre_x64_linux_hotspot_[0-9._]+[.]tar[.]gz$' "Temurin JRE 21" \
    "jdk-21.0.12+8" "OpenJDK21U-jre_x64_linux_hotspot_21.0.12_8.tar.gz" \
    "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.12%2B8/OpenJDK21U-jre_x64_linux_hotspot_21.0.12_8.tar.gz" \
    "8a379a67c91a3ae61ffb33d46e0a40c7ba35e70713c4db31cfca30492f792eff"
sync_ge_proton

for repo in "$MIRROR1" "$MIRROR2" "$MIRROR3"; do
    git -C "$repo" config user.name "zhoukeer-toolbox[bot]"
    git -C "$repo" config user.email "bot@users.noreply.github.com"
    git -C "$repo" add -A
    if git -C "$repo" diff --cached --quiet; then
        echo "No changes in $(basename "$repo")"
    else
        git -C "$repo" -c commit.gpgsign=false commit -q -m "Sync Gitee mirror assets"
        git -C "$repo" push -q origin main
        echo "Pushed $(basename "$repo")"
    fi
done
