# 第三方依赖 License 清单

Renkit自身代码使用仓库根目录 `LICENSE`（个人免费使用，禁止商业使用、销售、转卖或二次盈利发布）；下列第三方组件仍遵循各自原始许可证。

本清单记录Renkit会下载、安装或镜像的第三方项目。进入 Gitee 公开镜像
的项目必须具有明确的再分发许可；没有明确再分发授权的项目只保留官方源或
代理回退，不进入 `mirrors/`。

| 项目 | 用途 | 上游地址 | 许可证 | 进入 Gitee 镜像 | 备注 |
| --- | --- | --- | --- | --- | --- |
| Decky Loader | Decky 插件商城加载器 | https://github.com/SteamDeckHomebrew/decky-loader | GPL-2.0 | 是 | 稳定版与测试版均来自同一上游 |
| InputPlumber | 壹号掌机 SteamOS 输入路由与特殊按键支持更新 | https://github.com/ShadowBlip/InputPlumber | GPL-3.0-or-later | 否（官方 Release） | 固定官方 x86_64 原包与 SHA256；Gitee 分块镜像优先，GitHub Release 仅作校验回退，不修改包内容 |
| OneXPlayer X2 Mini Pro CachyOS 配置 | X2 Mini Pro 的 InputPlumber、QuickAccess 与 SteamOS 设备目标配置 | https://github.com/dahui/onexplayer-x2-mini-pro-cachyos | GPL-2.0 | 否（固定上游提交下载） | 固定提交 `a0b76a1` 的三份配置及 SHA256；Gitee 镜像优先，仅用于精确 DMI `ONEXPLAYER X2Mini PRO` |
| Decky LSFG-VK | 小黄鸭插件 | https://github.com/xXJSONDeruloXx/decky-lsfg-vk | BSD-3-Clause | 是 | 上游 License 明确允许再分发 |
| MAKO（小黄鸭） | MAKO 帧生成插件 | https://github.com/eugeniosegala/MAKO | GPL-3.0-or-later | 是 | 跟随上游最新正式版；使用作者官方原包自带简体中文，保留 Eugenio Segala 与许可证，不叠加 Renkit 汉化或署名 |
| Decky-Framegen | FSR4 插件 | https://github.com/xXJSONDeruloXx/Decky-Framegen | BSD-3-Clause | 是 | 基于 Decky 模板并保留 BSD-3 声明 |
| SteamDB Decky Button | 游戏模式查看 SteamDB 价格史低与在线峰值 | https://github.com/kedMertens/steamdbDeckyButton | BSD-3-Clause | 是 | v0.0.1 源码构建，增加中文双入口并保留上游许可证 |
| Decky Translator | 游戏模式屏幕文字与兼容性评价翻译 | https://github.com/cat-in-a-box/Decky-Translator | GPL-3.0 | 是 | 基于官方 v0.9.1 完整包叠加中文前端与官方依赖，源码随仓库保留 |
| CheatDeck | CheatDeck 插件 | https://github.com/SheffeyG/CheatDeck | GPL-3.0 | 是 | |
| SteamGridDB | Steam 游戏封面管理插件 | https://github.com/SteamGridDB/decky-steamgriddb | GPL-3.0-or-later | 是 | 使用 Decky 官方商店 v1.7.1 原包；安装后仅改 `plugin.json` 显示名称 |
| CSS Loader | Steam CSS 主题插件 | https://github.com/DeckThemes/SDH-CssLoader | GPL-2.0-or-later | 是 | 使用 Decky 官方商店 v2.1.2 原包并叠加中文前端；后端保持原包 |
| Friendeck | 局域网文件传输插件 | https://github.com/panyiwei-home/Friendeck | GPL-3.0 | 是 | Release 0.7.7 原包；安装后仅改 `plugin.json` 显示名称 |
| Decky Music | QQ 音乐与网易云音乐插件 | https://github.com/jinzhongjia/decky-music | MIT | 是 | v1.0.0 原包；安装后仅改 `plugin.json` 显示名称 |
| ToMoon | ToMoon 插件 | https://github.com/YukiCoco/ToMoon | BSD-3-Clause | 是 | |
| DeckRecall | DeckRecall 插件 | https://github.com/Ren-Amamiya-pixle/DeckRecall | 作者授权 Renkit 镜像分发 | 是 | DeckRecall 作者于 2026-08-10 在 Renkit 开发会话中明确授权国内镜像分发 |
| SavePulse | 自动版本存档与加密 WebDAV 换机恢复插件 | https://github.com/Ren-Amamiya-pixle/SavePulse | GPL-3.0-only | 是 | 作者 Release 分块镜像；每位用户绑定自己的坚果云或标准 WebDAV，下载重组后校验作者包 SHA256 |
| Unifideck | Unifideck 插件 | https://github.com/mubaraknumann/unifideck | GPL-3.0 | 是 | |
| Freedeck | Freedeck 插件 | https://github.com/panyiwei-home/Freedeck | BSD-3-Clause | 是 | LICENSE 文件为 BSD-3 文本 |
| Ally Center | ROG Ally / Ally X 硬件控制插件 | https://github.com/PixelAddictUnlocked/allycenter | MIT | 是 | 基于上游 1.2.0；原作者 Keith Baker / Pixel Addict Games；修补、汉化者 RenAmamiya。修正风扇后台及双转速显示，RC71L 增加双风扇 100% 请求与恢复；保留原 MIT 许可 |
| PowerControl | 通用掌机 CPU、GPU、TDP 与风扇控制插件 | https://github.com/mengmeet/PowerControl | BSD-3-Clause | 是 | 使用作者 v3.15.1 Release 原包；保留 yxx、honjow 与上游许可证，不叠加 Renkit 署名 |
| HueSync | 多品牌掌机 RGB 控制插件 | https://github.com/honjow/HueSync | BSD-3-Clause | 是 | 上游已内置简体中文，保留作者原版 |
| LegionGoRemapper | 初代 Legion Go 按键、RGB、充电与风扇控制 | https://github.com/aarron-lee/LegionGoRemapper | BSD-3-Clause | 是 | 上游 Release 原包；不支持 Legion Go S |
| GpdControl | GPD Win 系列 RGB 控制 | https://github.com/aarron-lee/GpdControl | GPL-3.0 | 是 | 上游 Release 原包 |
| LeGo Vibe Control | Legion Go / Go 2 震动与触控板控制 | https://github.com/Rayekkk/LeGo-Vibe-Control | BSD-3-Clause | 是 | 需要 hid-lenovo-go；不支持 Legion Go S |
| LeGo2 Fan Control | Legion Go 2 风扇曲线控制 | https://github.com/Rodpad/LeGo2-Fan-Control | GPL-3.0 | 是 | 仅适用于 Legion Go 2；提供不受限风扇控制 |
| LeGo2 Brightness Fix | HDR/PQ 面板亮度与游戏 EDID 修复 | https://github.com/Rayekkk/LeGo2BrightnessFix | BSD-3-Clause | 否（Renkit 内置组件） | 已实测适配 ONEXPLAYER X2 Mini Pro（Ryzen AI Max+ 388、三星 AMS881KB01-0 OLED）；保留 Rayek 原作者及许可证，中文汉化与非 UTF-8 进程名兼容修正：RenAmamiya |
| Fantastic | Steam Deck 风扇曲线控制 | https://gitlab.com/NGnius/Fantastic | GPL-3.0 | 是 | 基于 Decky 商店 v0.5.1 完整包，仅汉化前端与清单并显示 `RenAmamiya` 署名；完整保留 NGnius、后端和许可证 |
| OneXPlayer Apex Tools | OneXPlayer Apex 的 HHD、睡眠、风扇和按键修复 | https://github.com/srsholmes/onexplayer-apex-bazzite-fixes | MIT | 是 | 仅适用于 OneXPlayer Apex（Strix Halo），包含机型专用内核模块和系统修复 |
| SimpleDeckyTDP | SimpleDeckyTDP 插件 | https://github.com/aarron-lee/SimpleDeckyTDP | BSD-3-Clause | 是 | |
| 小黄鸭署名完整包 | LSFG v0.12.8 完整中文插件 | Gitee mirror-3 分块镜像 | 同 Decky LSFG-VK（BSD-3-Clause） | 否（安装时下载） | 保留官方运行文件，只替换中文前端并显示 `RenAmamiya` 署名 |
| Decky-Framegen 署名完整包 | FSR4 v0.17 完整中文插件 | Gitee mirror-3 分块镜像 | 同 Decky-Framegen（BSD-3-Clause） | 否（安装时下载） | 保留官方运行文件，只替换中文前端并显示 `RenAmamiya` 署名 |
| SimpleDeckyTDP 汉化完整包 | SimpleDeckyTDP 汉化包 | https://github.com/aarron-lee/SimpleDeckyTDP | 同 SimpleDeckyTDP（BSD-3-Clause） | 否（Renkit 内置组件） | 中文组件随 Renkit 内置，下载复用官方 simpledeckytdp 镜像 |
| 掌机插件中文前端组件 | 上述五款掌机插件的中文名称与汉化前端 | https://github.com/zliu9732-hub/zhoukeer-toolbox | 分别沿用各上游许可证 | 否（Renkit 内置组件） | 仅覆盖 plugin.json 与 dist/index.js；HueSync 自带简中，其余四款由 Renkit 汉化并保留原作者署名 |
| CSS Loader 中文前端组件 | CSS Loader v2.1.2 中文界面 | https://github.com/DeckThemes/SDH-CssLoader/tree/v2.1.2 | GPL-2.0-or-later | 否（Renkit 内置组件） | 随附对应源码、上游 LICENSE 与构建产物；安装时仅覆盖前端和 plugin.json |
| ROG White 白色主题 | SteamOS 游戏模式白色主题 | 原创（RenAmamia） | 原创随 Renkit 分发 | 否（Renkit 内置组件） | 仅包含 theme.json 与 shared.css；安装到 CSS Loader themes 目录后由用户在 CSS Loader 中开启 |
| Handheld Pink 粉色主题 | SteamOS 游戏模式粉色主题 | 原创（RenAmamia） | 原创随 Renkit 分发 | 否（Renkit 内置组件） | 基于 ROG White 改色；仅包含 theme.json 与 shared.css |
| Pink White Gradient 粉白渐变主题 | SteamOS 游戏模式浅粉渐变主题 | 原创（RenAmamia） | 原创随 Renkit 分发 | 否（Renkit 内置组件） | 独立保留浅粉白渐变版本 |
| RustDesk | RustDesk AppImage | https://github.com/rustdesk/rustdesk | AGPL-3.0 | 否（官方源） | 官方 AppImage 使用 Gitee 分块镜像优先、作者 GitHub Release 回退并固定 SHA256 |
| GE-Proton | Steam 兼容层 | https://github.com/GloriousEggroll/proton-ge-custom | Proton 顶层 BSD-3-Clause，组件各自许可 | 是 | 镜像包含上游 LICENSE.proton 说明 |
| ToDesk | ToDesk 官方安装包 | https://www.todesk.com/ | 专有软件 | 是 | 维护者确认仅用于非商业装机工具，保持官方包原样并保留官网回退 |
| Epic Games 启动器 | Epic 官方 Windows 安装器 | https://www.epicgames.com/ | 专有软件 | 是 | 维护者要求镜像以解决官方下载失败，保持官方包原样并保留官方源回退 |
| Steamcommunity 302 | Steam/GitHub 加速 | https://www.dogfight360.com/blog/ | 作者公开免费发布，仓库未附带 LICENSE | 是 | Renkit只从自有 Gitee 镜像下载，镜像由维护者从官方源更新 |
| Greenlight | Xbox 云游戏客户端 | https://github.com/unknownskl/greenlight | MIT | 否（Flathub 官方源） | 通过 Flathub 安装，不进入仓库 mirrors |
| Yuzu | Switch 模拟器 | https://github.com/yuzu-emu/yuzu | 上游仓库已下线 | 是（自有 Release 固定包） | Gitee 分块镜像优先，GitHub Release 回退；仅分发自有 Release 中未修改的固定 AppImage |
| Cemu | Wii U 模拟器 | https://github.com/cemu-project/Cemu | MPL-2.0 | 是 | Gitee 分块镜像优先，GitHub Release 回退；镜像为上游未修改的固定 AppImage |
| DuckStation | PS1 模拟器 | https://github.com/stenzek/duckstation | CC BY-NC-ND 4.0 | 是（自有非商业镜像） | 仅分发自有 Release 中未修改的固定 AppImage，保留署名与许可要求；Gitee 分块镜像优先，GitHub Release 回退 |
| PCSX2 | PS2 模拟器 | https://github.com/PCSX2/pcsx2 | GPL-3.0 | 是 | Gitee 分块镜像优先，GitHub Release 回退；镜像为上游未修改的固定 AppImage |
| RPCS3 | PS3 模拟器 | https://github.com/RPCS3/rpcs3 | GPL-2.0 | 是 | Gitee 分块镜像优先，GitHub Release 回退；镜像为上游未修改的固定 AppImage |
| ShadPS4 | PS4 模拟器 | https://github.com/shadps4-emu/shadPS4 | GPL-2.0 | 是 | Gitee 分块镜像优先，GitHub Release 回退；镜像为上游未修改的固定 AppImage |
| 微信 Linux | 微信官方 AppImage 与桌面图标 | https://linux.weixin.qq.com/ / https://github.com/flathub/com.tencent.WeChat | 专有软件；图标为腾讯商标 | 否（Renkit 内置图标） | AppImage 从腾讯官方 CDN 下载；默认图标取自 `flathub/com.tencent.WeChat@f1ca9e7` 的应用清单并随 Renkit 更新包分发 |

### 内置模拟器图标来源

`assets/emulators/` 不使用 AI 生成图。Yuzu 图标取自其已归档的 Flathub
应用清单 `flathub/org.yuzu_emu.yuzu@4abf1d2`；Cemu、DuckStation、PCSX2、
RPCS3、ShadPS4 图标分别取自各自上游官方仓库的应用图标，固定提交为
`daacdda`、`5ee1d25`、`2cf8dab`、`2f40345`、`c5ae3c6`。SVG 来源仅做
PNG 格式转换，不改变图形内容；各图标沿用对应上游项目的许可与商标要求。

## 说明

- “进入 Gitee 镜像”表示该项目的文件会出现在 `mirrors/` 目录并通过
  `latest.txt` 分块清单下载；未进入镜像的项目仍可在Renkit内使用官方源或
  既有代理回退。
- Flatpak 应用依赖（LibreOffice、Firefox、LocalSend 等）由 Flathub 及
  上海交大/中科大镜像提供，不进入本仓库 `mirrors/`。
- 普通镜像压缩包保持上游原始内容；名称中明确标注“署名中文插件”的
  Renkit 汉化包只替换同版本前端与清单，完整保留上游后端、作者和许可证。
  所有镜像下载后均校验固定 SHA256。

### 微星 Claw 8 EX RT721 音频修复

作者：stevedamnvan 及贡献者；许可证：GPL-2.0-only。
来源：https://github.com/lamb2k/msi-claw-8-ex-linux
（原 stevedamnvan 地址重定向至此），固定提交
`11909dbca067cdc8a14d77ec1a80909b1cda14dc`。
原始音频源码、构建文件、服务、睡眠钩子和完整许可证随 Renkit 分发于
`third_party/claw-rt721-fix-v0.1.0/`；未捆绑编译后的内核模块。
SteamOS 的 GCC 与 Launch Pack 型号修改在临时构建副本中完成；保留精确主板和
音频硬件限制，重新计算包内校验值，不跳过完整性检查。
上游验证环境是 CachyOS，Renkit 的 SteamOS 入口为实验性适配。

### InputPlumber 官方更新包

来源：https://github.com/ShadowBlip/InputPlumber/releases/latest
作者：ShadowBlip / William Edwards 及贡献者；许可证：GPL-3.0。
源码和许可证：https://github.com/ShadowBlip/InputPlumber/tree/main
每次查询最新正式版，使用该版本官方发布信息中的 SHA256；缺少校验值时停止。
原包仅在掌机确认更新后下载，不捆绑或修改二进制；安装前检查 SHA256、文件类型、
完整结构与受限安装路径。机型配置沿用上游文件，自定义配置保留；被替换文件备份到
`/var/lib/renkit/inputplumber-backups/`，更新失败时尝试恢复。

### SDWEAK 2.1

作者：Taskerer / @noncatt 及贡献者；许可证：MIT。
来源：https://github.com/Taskerer/SDWEAK/releases/tag/v2.1.0
核验源码提交：`8c32e86fff3c754ac4819524edf7fff4c4e04de3`。
官方 SDWEAK.zip SHA256：`5e91ca94577e3a999b6a8ea1a3e849bb168fedcc5b12b3cc41a00ca355d00d9e`。
仅在用户确认后下载，不捆绑上游二进制；原作者与 LICENSE 留在临时安装包。
优先下载 `zhoukeer-toolbox-mirror` 的 SDWEAK 分块清单与原包分块，每块不超过 8 MiB；
重组文件必须匹配上述固定 SHA256，镜像不可用时回退同版本官方来源。
Renkit 准备副本的改动：中文提示、失败即停止、保留全局软件签名检查、密钥和缓存，
省略实验性显示组件替换、不自动重启；其余性能设置沿用上游。
测试用原始安装器文本与 MIT 许可证保存在 `tests/fixtures/sdweak/`，仅用于模拟测试。
